package pro.babasitaram.vault.presentation.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.setValue
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.DisposableEffect
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import pro.babasitaram.vault.presentation.backup.BackupScreen
import pro.babasitaram.vault.presentation.editor.EntryEditorScreen
import pro.babasitaram.vault.presentation.generator.GeneratorScreen
import pro.babasitaram.vault.presentation.settings.SettingsScreen
import pro.babasitaram.vault.presentation.vault.EntryDetailScreen
import pro.babasitaram.vault.presentation.vault.VaultListScreen
import pro.babasitaram.vault.presentation.totpmanager.TotpManagerScreen
import pro.babasitaram.vault.presentation.vaulthealth.VaultHealthScreen
import pro.babasitaram.vault.presentation.bin.BinScreen
import pro.babasitaram.vault.presentation.notes.NotesScreen
import pro.babasitaram.vault.presentation.files.FilesScreen
import pro.babasitaram.vault.presentation.mobiles.MobilesScreen
import pro.babasitaram.vault.presentation.history.HistoryScreen
import pro.babasitaram.vault.presentation.about.AboutScreen
import pro.babasitaram.vault.presentation.help.HelpScreen
import pro.babasitaram.vault.presentation.sharing.SharingScreen
import pro.babasitaram.vault.presentation.supportdeveloper.SupportDeveloperScreen
import pro.babasitaram.vault.presentation.emergency.EmergencyScreen


object Routes {
    const val LIST = "list"
    const val DETAIL = "detail/{id}"
    const val EDIT = "edit?id={id}"
    const val GENERATOR = "generator"
    const val SETTINGS = "settings"
    const val BACKUP = "backup"
    const val TOTP = "totp"
    const val HEALTH = "health"
    const val BIN = "bin"
    const val NOTES = "notes"
    const val FILES = "files"
    const val MOBILES = "mobiles"
    const val HISTORY = "history"
    const val ABOUT = "about"
    const val HELP = "help"
    const val SHARING = "sharing"
    const val SUPPORT = "support"
    const val EMERGENCY = "emergency"

    fun detail(id: String) = "detail/${Uri.encode(id)}"
    fun edit(id: String? = null) = if (id == null) "edit" else "edit?id=${Uri.encode(id)}"
}

/** Only composed while the vault is unlocked; locking removes it, which drops every decrypted screen. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultNavHost() {
    val nav = rememberNavController()
    val saveRouter: SaveRouterViewModel = hiltViewModel()

    DisposableEffect(nav) {
        onDispose {
            // Best effort: clear the back stack when the vault locks.
            runCatching { nav.popBackStack(Routes.LIST, inclusive = true) }
        }
    }

    LifecycleResumeEffect(Unit) {
        saveRouter.nextRoute()?.let { pendingRoute -> nav.navigate(pendingRoute) }
        onPauseOrDispose { }
    }

    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val current by nav.currentBackStackEntryAsState()
    val route = current?.destination?.route ?: Routes.LIST
    val bottomItems = listOf(
        Routes.LIST to "Vault",
        Routes.TOTP to "TOTP",
        Routes.HEALTH to "Health",
        Routes.SETTINGS to "Settings"
    )
    val drawerItems = listOf(
        Routes.LIST to "Vault",
        Routes.TOTP to "TOTP Manager",
        Routes.HEALTH to "Vault Health",
        Routes.HISTORY to "History",
        Routes.NOTES to "Notes",
        Routes.FILES to "Files",
        Routes.MOBILES to "Mobiles",
        Routes.BIN to "Bin",
        Routes.BACKUP to "Backup",
        Routes.SHARING to "Sharing",
        Routes.EMERGENCY to "Emergency Access",
        Routes.HELP to "Help",
        Routes.SUPPORT to "Support Developer",
        Routes.ABOUT to "About",
        Routes.SETTINGS to "Settings"
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "BSRPRO Vault",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(20.dp)
                )
                drawerItems.forEach { (destination, label) ->
                    NavigationDrawerItem(
                        label = { Text(label) },
                        selected = route == destination,
                        onClick = {
                            scope.launch { drawerState.close() }
                            nav.navigate(destination) { launchSingleTop = true }
                        },
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("BSRPRO Vault") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Text("☰")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    bottomItems.forEach { (destination, label) ->
                        NavigationBarItem(
                            selected = route == destination,
                            onClick = {
                                nav.navigate(destination) {
                                    popUpTo(Routes.LIST) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Text(label.take(1)) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding)) {
                NavHost(
                    navController = nav,
                    startDestination = Routes.LIST
                ) {
                    composable(Routes.LIST) {
                        VaultListScreen(
                            onOpen = { entryId -> nav.navigate(Routes.detail(entryId)) },
                            onAdd = { nav.navigate(Routes.edit()) },
                            onGenerator = { nav.navigate(Routes.GENERATOR) },
                            onSettings = { nav.navigate(Routes.SETTINGS) }
                        )
                    }
                    composable(
                        route = Routes.DETAIL,
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) {
                        EntryDetailScreen(
                            onBack = { nav.popBackStack() },
                            onEdit = { entryId -> nav.navigate(Routes.edit(entryId)) }
                        )
                    }
                    composable(
                        route = Routes.EDIT,
                        arguments = listOf(
                            navArgument("id") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            }
                        )
                    ) {
                        EntryEditorScreen(onDone = { nav.popBackStack() })
                    }
                    composable(Routes.GENERATOR) {
                        GeneratorScreen(onBack = { nav.popBackStack() })
                    }
                    composable(Routes.SETTINGS) {
                        SettingsScreen(
                            onBack = { nav.popBackStack() },
                            onOpenBackup = { nav.navigate(Routes.BACKUP) }
                        )
                    }
                    composable(Routes.BACKUP) {
                        BackupScreen(onBack = { nav.popBackStack() })
                    }
                    composable(Routes.TOTP) { TotpManagerScreen() }
                    composable(Routes.HEALTH) { VaultHealthScreen() }
                    composable(Routes.BIN) { BinScreen() }
                    composable(Routes.NOTES) { NotesScreen() }
                    composable(Routes.FILES) { FilesScreen() }
                    composable(Routes.MOBILES) { MobilesScreen() }
                    composable(Routes.HISTORY) { HistoryScreen() }
                    composable(Routes.ABOUT) { AboutScreen() }
                    composable(Routes.HELP) { HelpScreen() }
                    composable(Routes.SHARING) { SharingScreen() }
                    composable(Routes.SUPPORT) { SupportDeveloperScreen() }
                    composable(Routes.EMERGENCY) { EmergencyScreen() }
                }
            }
        }
    }
}
