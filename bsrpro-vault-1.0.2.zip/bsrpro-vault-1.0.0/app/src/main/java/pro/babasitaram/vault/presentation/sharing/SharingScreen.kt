package pro.babasitaram.vault.presentation.sharing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SharingScreen(onBack: () -> Unit = {}) {
    Scaffold(topBar = { TopAppBar(title = { Text("Sharing") }, navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("Sharing", style = MaterialTheme.typography.headlineSmall) }
            item { Text("Your encrypted vault data remains in the existing vault store.", style = MaterialTheme.typography.bodyMedium) }
            item { OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("No items to display", style = MaterialTheme.typography.titleMedium); Text("Add or import data to see it here.") } } }
        }
    }
}
