package pro.babasitaram.vault.presentation.components
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
@Composable fun SectionHeader(title: String) { Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary) }
