package pro.babasitaram.vault.presentation.components
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun TotpCard(label:String, account:String, code:String, seconds:Int, onCopy:()->Unit={}) { ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { Text(label,style=MaterialTheme.typography.titleMedium); Text(account); Text(code,style=MaterialTheme.typography.headlineMedium); Text("Refresh in ${seconds.coerceIn(0,30)}s"); TextButton(onClick=onCopy){Text("Copy")}} } }
