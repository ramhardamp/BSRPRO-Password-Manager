@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.history

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import pro.babasitaram.vault.core.model.PasswordHistoryItem
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages

@Composable
fun HistoryScreen(onBack: () -> Unit = {}, vm: HistoryViewModel = hiltViewModel()) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    val filter by vm.filterState.collectAsStateWithLifecycle()
    var selected by remember { mutableStateOf<Pair<VaultEntry, PasswordHistoryItem>?>(null) }
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    Scaffold(topBar = { TopAppBar(title = { Text("Password History", style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HistoryViewModel.Filter.values().forEach { item ->
                    FilterChip(selected = filter == item, onClick = { vm.setFilter(item) }, label = { Text(item.name.lowercase().replaceFirstChar { it.uppercase() }) })
                }
            }
            if (entries.isEmpty()) {
                EmptyState("No history yet", "Password changes and entry edits will appear here.", Modifier.fillMaxWidth())
            } else {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(entries, key = { it.id }) { entry ->
                        HistoryItem(entry, onView = { h -> selected = entry to h }, onCopy = { h -> vm.copy(h.pw, "Previous password") })
                    }
                }
            }
        }
    }
    selected?.let { (entry, history) ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("View change") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(entry.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium)
                    Text("Changed: ${DateFormat.getDateTimeInstance().format(Date(history.changedAt))}")
                    Text("Previous password is hidden until you choose to reveal it.")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.restorePassword(entry, history.pw)
                    selected = null
                }) { Text("Restore this password") }
            },
            dismissButton = { TextButton(onClick = { selected = null; vm.copy(history.pw, "Previous password") }) { Text("Copy password") } }
        )
    }
}

@Composable
private fun HistoryItem(entry: VaultEntry, onView: (PasswordHistoryItem) -> Unit, onCopy: (PasswordHistoryItem) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(entry.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium)
            entry.passwordHistory.take(5).forEach { history ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(DateFormat.getDateTimeInstance().format(Date(history.changedAt)), style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton(onClick = { onView(history) }) { Text("View change") }
                        TextButton(onClick = { onCopy(history) }) { Text(stringResource(R.string.p15_copy)) }
                    }
                }
            }
            if (entry.editHistory.isNotEmpty()) Text("${entry.editHistory.size} edit changes recorded", style = MaterialTheme.typography.bodySmall)
        }
    }
}
