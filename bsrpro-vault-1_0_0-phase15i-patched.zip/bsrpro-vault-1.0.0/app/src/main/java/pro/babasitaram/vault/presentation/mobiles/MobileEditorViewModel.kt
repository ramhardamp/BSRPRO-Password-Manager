package pro.babasitaram.vault.presentation.mobiles

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage

val MOBILE_OPERATORS = listOf("Jio", "Airtel", "Vi", "BSNL", "Other")
val MOBILE_CATEGORIES = listOf("personal", "work", "other")
internal const val OPERATOR_FIELD = "operator"

data class MobileEditorState(
    val title: String = "",
    val number: String = "",
    val operator: String = "",
    val category: String = "personal",
    val tags: String = "",
    val starred: Boolean = false,
    val notes: String = "",
    val saving: Boolean = false,
    val saved: Boolean = false,
    val error: String? = null,
    val existing: VaultEntry? = null
)

@HiltViewModel
class MobileEditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase
) : ViewModel() {
    private val existing = savedStateHandle.get<String>("id")?.let(repository::entry)
    private val _state = MutableStateFlow(
        MobileEditorState(
            title = existing?.title.orEmpty(),
            number = existing?.let { e -> e.mobile.ifBlank { e.phone } }.orEmpty(),
            operator = existing?.customFields?.firstOrNull { it.k == OPERATOR_FIELD }?.v.orEmpty(),
            category = existing?.category?.takeIf { it in MOBILE_CATEGORIES } ?: "personal",
            tags = existing?.tags?.joinToString(", ").orEmpty(),
            starred = existing?.starred ?: false,
            notes = existing?.notes.orEmpty(),
            existing = existing
        )
    )
    val state: StateFlow<MobileEditorState> = _state.asStateFlow()

    fun setTitle(v: String) = _state.update { it.copy(title = v, error = null) }
    fun setNumber(v: String) = _state.update { it.copy(number = v, error = null) }
    fun setNotes(v: String) = _state.update { it.copy(notes = v, error = null) }
    fun setOperator(v: String) = _state.update { it.copy(operator = v, error = null) }
    fun setCategory(v: String) = _state.update { it.copy(category = v, error = null) }
    fun setTags(v: String) = _state.update { it.copy(tags = v, error = null) }
    fun setStarred(v: Boolean) = _state.update { it.copy(starred = v, error = null) }

    fun save() {
        val s = _state.value
        if (s.title.isBlank() || s.number.isBlank()) {
            _state.update { it.copy(error = "Enter a title and mobile number") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(saving = true, error = null) }
            val entry = (s.existing ?: VaultEntry()).copy(
                title = s.title.trim(),
                mobile = s.number.trim(),
                phone = s.number.trim(),
                notes = s.notes,
                recordType = "mobile",
                isNote = false,
                category = s.category,
                starred = s.starred,
                tags = s.tags.split(',').map { it.trim() }.filter { it.isNotEmpty() },
                // operator lives in a custom field so the V3 backup format stays unchanged
                customFields = (s.existing?.customFields.orEmpty().filterNot { it.k == OPERATOR_FIELD }) +
                    (if (s.operator.isBlank()) emptyList() else listOf(pro.babasitaram.vault.core.model.CustomField(OPERATOR_FIELD, s.operator)))
            )
            when (val result = saveEntry(entry, s.existing)) {
                is VaultResult.Success -> _state.update { it.copy(saving = false, saved = true) }
                is VaultResult.Failure -> _state.update { it.copy(saving = false, error = result.error.toUserMessage()) }
                VaultResult.Loading -> Unit
            }
        }
    }
}
