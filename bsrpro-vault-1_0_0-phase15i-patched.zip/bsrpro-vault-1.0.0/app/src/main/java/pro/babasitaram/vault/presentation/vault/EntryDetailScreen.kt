@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.vault

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.delay
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.components.StrengthMeter
import pro.babasitaram.vault.presentation.util.CollectMessages
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*

@Composable
fun EntryDetailScreen(onBack: () -> Unit, onEdit: (String) -> Unit, vm: EntryDetailViewModel = hiltViewModel()) {
    val entry by vm.entry.collectAsStateWithLifecycle()
    BackHandler { onBack() }
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    CollectMessages(vm.messages)

    LaunchedEffect(entry == null) { if (entry == null) onBack() }
    val e = entry ?: return

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(e.title.ifEmpty { "(untitled)" }, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = vm::toggleStar) {
                        Icon(if (e.starred) Icons.Default.Star else Icons.Default.StarBorder, "Star")
                    }
                    IconButton(onClick = { onEdit(e.id) }) { Icon(Icons.Default.Edit, "Edit") }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Delete") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DetailField("Username", e.username) { vm.copy("Username", e.username) }
            if (e.password.isNotEmpty()) {
                DetailField("Password", e.password, secret = true) { vm.copy("Password", e.password) }
                StrengthMeter(e.password)
            }
            if (e.appPin.isNotEmpty()) {
                DetailField("App PIN", e.appPin, secret = true) { vm.copy("App PIN", e.appPin) }
            }
            if (e.url.isNotEmpty()) {
                DetailField("Website", e.url, extraIcon = {
                    IconButton(onClick = {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(UrlUtils.toOpenable(e.url))))
                        }
                    }) { Icon(Icons.Default.Link, "Open website") }
                }) { vm.copy("Website", e.url) }
            }
            DetailField("Mobile", e.mobile) { vm.copy("Mobile", e.mobile) }
            DetailField("Email", e.email) { vm.copy("Email", e.email) }
            if (e.totp.isNotBlank()) {
                TotpField(e, vm)
            } else if (!e.isNote && e.recordType.equals("login", ignoreCase = true)) {
                TextButton(onClick = { onEdit(e.id) }) { Text("Add authenticator code (TOTP)") }
            }
            DetailField("Card number", e.cardNumber, secret = true) { vm.copy("Card number", e.cardNumber) }
            DetailField("Cardholder", e.cardholder) { vm.copy("Cardholder", e.cardholder) }
            DetailField("Expiry", e.cardExpiry) { vm.copy("Expiry", e.cardExpiry) }
            DetailField("CVV", e.cardCvv, secret = true) { vm.copy("CVV", e.cardCvv) }
            DetailField("Full name", e.fullName) { vm.copy("Full name", e.fullName) }
            DetailField("Phone", e.phone) { vm.copy("Phone", e.phone) }
            DetailField("Address", e.address) { vm.copy("Address", e.address) }
            DetailField("ID number", e.idNumber, secret = true) { vm.copy("ID number", e.idNumber) }
            DetailField("ID expiry", e.idExpiry) { vm.copy("ID expiry", e.idExpiry) }
            e.customFields.filter { it.k.isNotBlank() }.forEach { f ->
                DetailField(f.k, f.v) { vm.copy(f.k, f.v) }
            }
            DetailField("Notes", e.notes) { vm.copy("Notes", e.notes) }
            DetailField("Category", e.category.replaceFirstChar { it.uppercase() })
            if (e.tags.isNotEmpty()) DetailField("Tags", e.tags.joinToString(", "))
            if (e.appName.isNotEmpty() || e.appPackage.isNotEmpty()) {
                DetailField("Android app", when {
                    e.appName.isNotBlank() && e.appPackage.isNotBlank() -> "${e.appName} (${e.appPackage})"
                    e.appPackage.isNotBlank() -> e.appPackage
                    else -> "${e.appName} · Not linked — edit entry to re-link"
                })
            }
            if (e.passwordHistory.isNotEmpty()) PasswordHistory(e, vm)
            if (e.editHistory.isNotEmpty()) EditHistory(e)
            if (e.updatedAt > 0) {
                Text(
                    "Updated ${DateFormat.getDateTimeInstance().format(Date(e.updatedAt))}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Move entry to Bin?", style = MaterialTheme.typography.titleLarge) },
            text = { Text("\"${e.title}\" will be moved to Bin and can be restored for up to 30 days.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete() }) { Text("Move to Bin") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun DetailField(
    label: String,
    value: String,
    secret: Boolean = false,
    extraIcon: (@Composable () -> Unit)? = null,
    onCopy: (() -> Unit)? = null
) {
    if (value.isEmpty()) return
    var shown by remember { mutableStateOf(!secret) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                if (shown) value else "••••••••••",
                style = MaterialTheme.typography.bodyLarge,
                fontFamily = if (secret) FontFamily.Monospace else FontFamily.Default
            )
        }
        if (secret) {
            IconButton(onClick = { shown = !shown }) {
                Icon(if (shown) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (shown) "Hide" else "Show")
            }
        }
        extraIcon?.invoke()
        if (onCopy != null) IconButton(onClick = onCopy) { Icon(Icons.Default.ContentCopy, "Copy $label") }
    }
}

@Composable
private fun TotpField(entry: VaultEntry, vm: EntryDetailViewModel) {
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(250)
        }
    }
    val code = vm.totp(entry.totp, now)
    if (code == null) {
        Text("Authenticator secret is not valid", color = MaterialTheme.colorScheme.error)
        return
    }
    // fraction of the period left, computed from wall-clock milliseconds so the ring is smooth and flips exactly at the boundary
    val periodMs = code.periodSeconds * 1000L
    val fraction = 1f - ((now % periodMs).toFloat() / periodMs)
    val expiring = code.secondsRemaining <= 5
    Row(
        Modifier.fillMaxWidth().clickable { vm.copy("Code", code.code) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("One-time code · tap to copy", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                code.code.chunked(3).joinToString(" "),
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Monospace,
                color = if (expiring) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
        }
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { fraction },
                modifier = Modifier.size(44.dp),
                strokeWidth = 4.dp,
                color = if (expiring) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
            Text("${code.secondsRemaining}", style = MaterialTheme.typography.labelLarge)
        }
        IconButton(onClick = { vm.copy("Code", code.code) }) { Icon(Icons.Default.ContentCopy, "Copy code") }
    }
}

@Composable
private fun PasswordHistory(entry: VaultEntry, vm: EntryDetailViewModel) {
    var open by remember { mutableStateOf(false) }
    Column {
        TextButton(onClick = { open = !open }) { Text(if (open) "Hide password history" else "Password history (${entry.passwordHistory.size})") }
        if (open) {
            entry.passwordHistory.forEach { h ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("••••••••••", fontFamily = FontFamily.Monospace)
                        if (h.changedAt > 0) {
                            Text(DateFormat.getDateInstance().format(Date(h.changedAt)), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    IconButton(onClick = { vm.copy("Old password", h.pw) }) { Icon(Icons.Default.ContentCopy, "Copy old password") }
                }
            }
        }
    }
}

@Composable
private fun EditHistory(entry: VaultEntry) {
    var open by remember { mutableStateOf(false) }
    Column {
        TextButton(onClick = { open = !open }) { Text(if (open) "Hide edit history" else "Edit history (${entry.editHistory.size})") }
        if (open) {
            entry.editHistory.forEach { h ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(
                        if (h.changedAt > 0) DateFormat.getDateTimeInstance().format(Date(h.changedAt)) else "Unknown time",
                        style = MaterialTheme.typography.labelMedium
                    )
                    val what = h.fields.joinToString(", ").ifEmpty { "details" }
                    Text(
                        "Changed: $what" + if (h.source.isNotEmpty()) " · ${h.source}" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
