package pro.babasitaram.vault.presentation.settings

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import pro.babasitaram.vault.presentation.components.PasswordField
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import pro.babasitaram.vault.R
import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.core.constants.AppLinks
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.foundation.background
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import pro.babasitaram.vault.BuildConfig
import pro.babasitaram.vault.autofill.AutofillStatus
import pro.babasitaram.vault.core.model.AppIconColor
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.findFragmentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*

private val AUTO_LOCK = listOf("Never" to VaultSettings.AUTO_LOCK_NEVER, "30 seconds" to 30, "1 minute" to 60, "5 minutes" to 300, "15 minutes" to 900)
private val LOCKOUT_ATTEMPTS = listOf("3 attempts" to 3, "5 attempts" to 5, "10 attempts" to 10)
private val LOCKOUT_DURATION = listOf("30 seconds" to 30, "1 minute" to 60, "5 minutes" to 300, "15 minutes" to 900)
private val CLIPBOARD = listOf("Never" to 0, "15 seconds" to 15, "30 seconds" to 30, "60 seconds" to 60)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenBackup: () -> Unit, onOpenActivityLog: () -> Unit = {}, onOpenHidden: () -> Unit = {}, vm: SettingsViewModel = hiltViewModel()) {
    var category by remember { mutableStateOf<SettingsCategory?>(null) }
    var query by remember { mutableStateOf("") }
    BackHandler { if (category != null) category = null else onBack() }
    val s by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    CollectMessages(vm.messages)

    var autofillOn by remember { mutableStateOf(AutofillStatus.isEnabled(context)) }
    LifecycleResumeEffect(Unit) {
        autofillOn = AutofillStatus.isEnabled(context)
        onPauseOrDispose { }
    }

    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(category?.title ?: R.string.settings_title), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = { if (category != null) category = null else onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())) {
            val cat = category
            if (cat == null) {
                SettingsHub(query = query, onQuery = { query = it }, onOpen = { category = it; query = "" })
            } else when (cat) {
                SettingsCategory.SECURITY -> {
            ActionRow("Change master password", "Re-encrypts your vault. The old password stops working.") { dialog = SettingsDialog.ChangePassword }
            SwitchRow("Biometric unlock", "Unlock with fingerprint or face", s.biometricEnabled) {
                context.findFragmentActivity()?.let(vm::toggleBiometric)
            }
            ChoiceRow("Auto-lock timeout", AUTO_LOCK, s.autoLockSeconds, vm::setAutoLock)
            SwitchRow("Lock when app goes to background", null, s.lockOnBackground, vm::setLockOnBackground)
            SwitchRow("Block weak passwords", "Prevent weak login passwords from being saved", s.blockWeakPasswords, vm::setBlockWeakPasswords)
            ActionRow("Entry PINs", "Each login can have its own optional 4–6 digit PIN for native Autofill") { }
            ActionRow("Secure sharing PIN", "Optional 4–6 digit PIN used before creating or copying encrypted share links") { dialog = SettingsDialog.SharingPin }
            ActionRow("Recovery key", "View or save the 24-character master-password recovery key") { dialog = SettingsDialog.RecoveryKey }
            ChoiceRow("Clipboard auto-clear", CLIPBOARD, s.clipboardClearSeconds, vm::setClipboardClear)
                    ChoiceRow("Failed attempts before lockout", LOCKOUT_ATTEMPTS, s.lockoutMaxAttempts, vm::setLockoutAttempts)
                    ChoiceRow("Lockout duration", LOCKOUT_DURATION, s.lockoutSeconds, vm::setLockoutSeconds)
            SwitchRow(
                "Allow screenshots",
                if (s.allowScreenshots) "ON — screenshots and screen recording are allowed. Turn off to protect the vault."
                else "OFF (secure) — screenshots and screen recording are blocked",
                s.allowScreenshots,
                vm::setAllowScreenshots
            )
            SwitchRow(
                "Hide sensitive recent-app screenshots",
                "Keeps vault content out of Android's recent-app preview",
                s.hideSensitiveContentInRecents,
                vm::setHideSensitiveRecents
            )
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Current device", style = MaterialTheme.typography.titleMedium)
                    Text("${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                    Text("Android ${android.os.Build.VERSION.RELEASE} · API ${android.os.Build.VERSION.SDK_INT}", style = MaterialTheme.typography.bodySmall)
                    Text("BSRPRO ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall)
                    Text("Device controls are local-only; this screen never uploads device identifiers.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = vm::lockDevice, modifier = Modifier.fillMaxWidth()) { Text("Lock vault now") }
                }
            }
                }
                SettingsCategory.AUTOFILL -> {
            ActionRow(
                "Autofill service",
                if (autofillOn) "BSRPRO Vault is your autofill service" else "Off — tap to choose BSRPRO Vault in Android settings"
            ) {
                val primary = AutofillStatus.enableIntent(context)
                runCatching { context.startActivity(primary) }.onFailure { runCatching { context.startActivity(AutofillStatus.fallbackIntent()) } }
            }
            ActionRow("Autofill diagnostics", "See what happened on the last autofill requests (no passwords are recorded)") {
                dialog = SettingsDialog.AutofillDiagnostics
            }
            SwitchRow("Show suggestions above the keyboard", "Inline suggestions (Android 11+)", s.autofillInline, vm::setAutofillInline)
            SwitchRow("Use Autofill regex rules", "Match an entry custom field named autofillRegex against the current package or domain", s.autofillRegexEnabled, vm::setAutofillRegex)
            ActionRow("Excluded apps", if (s.autofillExcludedPackages.isEmpty()) "None" else "${s.autofillExcludedPackages.size} packages excluded") { dialog = SettingsDialog.ExcludedApps }
                    SwitchRow("Save prompts", "Offer to save a login after you sign in to an app or site", s.autofillSavePrompts, vm::setSavePrompts)
                }
                SettingsCategory.BACKUP -> {
                    SwitchRow("Auto-backup", "Keeps one file: Downloads/BSRPRO_Backups/BSRPRO.Vault", s.autoBackupEnabled, vm::setAutoBackup)
                    ActionRow(
                        "Last backup",
                        if (s.lastAutoBackupAt > 0) java.text.DateFormat.getDateTimeInstance().format(java.util.Date(s.lastAutoBackupAt)) else "No backup yet"
                    ) { }
                    ActionRow("Back up now", "Overwrites BSRPRO.Vault with the current vault") { vm.backupNow() }
            ActionRow("Backup folder location", "Downloads/BSRPRO_Backups · automatic encrypted file: BSRPRO.Vault") { onOpenBackup() }
            ActionRow("Restore from backup folder", "Open backup tools to select BSRPRO.Vault and verify it before import") { onOpenBackup() }
            ActionRow("Export encrypted backup", "Also CSV and JSON exports") { onOpenBackup() }
            ActionRow("Import from backup", ".Vault files") { onOpenBackup() }
            ActionRow("Import from CSV", "Chrome, Bitwarden, LastPass, 1Password and more") { onOpenBackup() }
                    ActionRow("Import from contacts", "Choose phone contacts to save as Mobile entries") { onOpenBackup() }
                }
                SettingsCategory.INTERFACE -> {
            run {
                var language by remember { mutableStateOf(pro.babasitaram.vault.core.util.LocaleHelper.read(context)) }
                ChoiceRow(
                    stringResource(R.string.settings_language),
                    listOf(
                        stringResource(R.string.settings_language_system) to pro.babasitaram.vault.core.util.LocaleHelper.SYSTEM,
                        "English" to pro.babasitaram.vault.core.util.LocaleHelper.ENGLISH,
                        "हिन्दी" to pro.babasitaram.vault.core.util.LocaleHelper.HINDI
                    ),
                    language
                ) { code ->
                    if (code != language) {
                        pro.babasitaram.vault.core.util.LocaleHelper.save(context, code)
                        language = code
                        context.findFragmentActivity()?.recreate()
                    }
                }
            }
            ChoiceRow("Theme", ThemeMode.values().map { it.name.lowercase().replaceFirstChar(Char::uppercase) to it }, s.theme, vm::setTheme)
            ChoiceRow("App icon colour", AppIconColor.values().map { it.label to it }, s.appIcon, vm::setAppIcon)
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("App font size: ${s.fontScalePercent}%", style = MaterialTheme.typography.bodyLarge)
                Slider(
                    value = s.fontScalePercent.toFloat(),
                    onValueChange = { vm.setFontScale(it.toInt()) },
                    valueRange = 80f..200f,
                    steps = 11
                )
            }
                    SwitchRow("Show category chips", "Work / Personal / Banking chips on the Vault screen", s.showCategoryChips, vm::setShowCategoryChips)
                }
                SettingsCategory.GENERATOR -> {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("Default length: ${s.generatorDefaultLength}", style = MaterialTheme.typography.bodyLarge)
                Slider(
                    value = s.generatorDefaultLength.toFloat(),
                    onValueChange = { vm.setGeneratorLength(it.toInt()) },
                    valueRange = 8f..256f
                )
                OutlinedTextField(
                    value = s.generatorKeyword,
                    onValueChange = vm::setGeneratorKeyword,
                    label = { Text("Custom keyword / prefix") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            SwitchRow("Exclude similar characters", "Skips I, l, 1, O, 0, o", s.generatorExcludeSimilar, vm::setExcludeSimilar)
                    SwitchRow("Lowercase (a-z)", null, s.generatorLower) { vm.setGeneratorSets(lower = it) }
                    SwitchRow("Uppercase (A-Z)", null, s.generatorUpper) { vm.setGeneratorSets(upper = it) }
                    SwitchRow("Numbers (0-9)", null, s.generatorDigits) { vm.setGeneratorSets(digits = it) }
                    SwitchRow("Symbols (!@#…)", "At least one character set always stays on", s.generatorSymbols) { vm.setGeneratorSets(symbols = it) }
                }
                SettingsCategory.ADVANCED -> {
                    ActionRow(stringResource(R.string.hidden_vault), "PIN-protected area for entries you hide from the Vault list") { onOpenHidden() }
            SwitchRow("Travel mode", "Disable automatic autofill suggestions while travelling", s.travelMode, vm::setTravelMode)
            ActionRow("Emergency access", if (s.emergencyEncryptedMaster.isNotBlank()) "Configured — manage recovery from the Emergency Access screen" else "Create a 24-character recovery key") { if (s.emergencyEncryptedMaster.isBlank()) vm.setupEmergency() }
            if (s.emergencyEncryptedMaster.isNotBlank()) {
                ActionRow("Revoke emergency access", "Deletes the encrypted recovery secret", danger = true) { vm.revokeEmergency() }
            }
            ActionRow("Activity log", "Local history of security actions without passwords or secret values") { onOpenActivityLog() }
            ActionRow("Clear recent searches", null) { vm.clearRecentSearches() }
                    ActionRow("Reset settings to defaults", "Keeps your vault, recovery key, emergency access and biometric choice") { dialog = SettingsDialog.ResetDefaults }
            ActionRow("Clear all data (reset vault)", "Deletes everything on this device", danger = true) { dialog = SettingsDialog.Reset }
                }
                SettingsCategory.ABOUT -> {
                    ActionRow("Version", "${BuildConfig.VERSION_NAME} (Code ${BuildConfig.VERSION_CODE})") { }
                    ActionRow("Developer", AppLinks.DEVELOPER) { }
                    ActionRow("Website", AppLinks.WEBSITE) { openLink(context, AppLinks.WEBSITE) }
                    ActionRow("GitHub", AppLinks.GITHUB) { openLink(context, AppLinks.GITHUB) }
                    ActionRow("Email", AppLinks.EMAIL) { openLink(context, "mailto:${AppLinks.EMAIL}") }
                    ActionRow("License", "Source code license") { openLink(context, AppLinks.GITHUB_LICENSE) }
                    ActionRow("Changelog", null) { dialog = SettingsDialog.Changelog }
                    ActionRow("Privacy policy", null) { dialog = SettingsDialog.Privacy }
                    ActionRow("Open source licenses", null) { dialog = SettingsDialog.Licenses }
                }
            }
        }
    }

    when (dialog) {
        SettingsDialog.ChangePassword -> ChangePasswordDialog(
            onSubmit = { o, n, c -> vm.changeMasterPassword(o, n, c) },
            onDone = { dialog = null }
        )
        SettingsDialog.Reset -> ResetDialog(
            onSubmit = { pw -> vm.resetVault(pw) },
            onDone = { dialog = null }
        )
        SettingsDialog.ResetDefaults -> androidx.compose.material3.AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Reset settings?") },
            text = { Text("All preferences return to their defaults. Your vault entries, recovery key, emergency access and biometric choice are not touched.") },
            confirmButton = { TextButton(onClick = { vm.resetToDefaults(); dialog = null }) { Text("Reset") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.p15_cancel)) } }
        )
        SettingsDialog.ExcludedApps -> ExcludedAppsDialog(
            current = s.autofillExcludedPackages,
            onSave = { vm.setExcludedPackages(it); dialog = null },
            onDone = { dialog = null }
        )
        SettingsDialog.AutofillDiagnostics -> AutofillDiagnosticsDialog(context) { dialog = null }
        SettingsDialog.SharingPin -> SharingPinDialog(
            onSave = { vm.setSharingPin(it); dialog = null },
            onClear = { vm.clearSharingPin(); dialog = null },
            onDone = { dialog = null }
        )
        SettingsDialog.RecoveryKey -> RecoveryKeyDialog(
            keyLoader = { vm.recoveryKey() },
            onClose = { dialog = null },
            onCopy = { vm.copySecret(it, "Recovery key") },
            context = context
        )
        SettingsDialog.Changelog -> InfoDialog("Changelog", CHANGELOG) { dialog = null }
        SettingsDialog.Privacy -> InfoDialog("Privacy policy", PRIVACY) { dialog = null }
        SettingsDialog.Licenses -> InfoDialog("Open source licenses", LICENSES) { dialog = null }
        null -> Unit
    }
}

private enum class SettingsDialog {
    ExcludedApps, ChangePassword, Reset, ResetDefaults, Changelog, Privacy, Licenses, AutofillDiagnostics, SharingPin, RecoveryKey }

@Composable
private fun Section(title: String) {
    HorizontalDivider(Modifier.padding(top = 8.dp))
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp))
}

@Composable
private fun ActionRow(title: String, subtitle: String?, danger: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun <T> ChoiceRow(title: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.second == selected }?.first ?: "Custom"
    Column(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (name, value) ->
                DropdownMenuItem(text = { Text(name) }, onClick = { open = false; onSelect(value) })
            }
        }
    }
}

@Composable
private fun ExcludedAppsDialog(
    current: List<String>,
    onSave: (String) -> Unit,
    onDone: () -> Unit
) {
    var text by remember(current) { mutableStateOf(current.joinToString("\n")) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text("Excluded apps") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("One Android package name per line. These apps receive no BSRPRO Autofill suggestions.")
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    minLines = 5,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Package names") }
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text(stringResource(R.string.p15_save)) } },
        dismissButton = { TextButton(onClick = onDone) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun InfoDialog(title: String, body: String, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(body, style = MaterialTheme.typography.bodyMedium) } },
        confirmButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.p15_close)) } }
    )
}

@Composable
private fun SharingPinDialog(
    onSave: (String) -> Unit,
    onClear: () -> Unit,
    onDone: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text("Secure sharing PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Set a 4–6 digit PIN for sensitive sharing actions when biometric authentication is unavailable.")
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(6) },
                    label = { Text("4–6 digit PIN") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(enabled = pin.length in 4..6, onClick = { onSave(pin); pin = "" }) { Text(stringResource(R.string.p15_save)) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onClear) { Text(stringResource(R.string.p15_remove)) }
                TextButton(onClick = onDone) { Text(stringResource(R.string.p15_cancel)) }
            }
        }
    )
}

@Composable
private fun RecoveryKeyDialog(
    keyLoader: suspend () -> String?,
    onClose: () -> Unit,
    onCopy: (String) -> Unit,
    context: android.content.Context
) {
    var key by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null && key != null) {
            scope.launch {
                try {
                    RecoveryKeyPdf.write(context, uri, key!!)
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    throw ce
                } catch (e: Exception) {
                    error = "Could not save PDF: ${e.message ?: "write failed"}"
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        key = keyLoader()
        loading = false
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Master-password recovery key") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when {
                    loading -> Text("Loading recovery key…")
                    key == null -> Text("No recovery key is configured. Create one after unlocking the vault.", color = MaterialTheme.colorScheme.error)
                    else -> {
                        Text("Store this key offline. Anyone with it can reset the master password.")
                        Card(Modifier.fillMaxWidth()) {
                            Text(
                                key!!,
                                modifier = Modifier.padding(16.dp),
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = key != null, onClick = {
                key?.let(onCopy)
            }) { Text(stringResource(R.string.p15_copy)) }
        },
        dismissButton = {
            Row {
                TextButton(enabled = key != null, onClick = { pdfLauncher.launch("BSRPRO-Recovery-Key.pdf") }) { Text("Save PDF") }
                TextButton(enabled = key != null, onClick = { printRecoveryKey(context, key!!) }) { Text("Print") }
                TextButton(onClick = onClose) { Text(stringResource(R.string.p15_close)) }
            }
        }
    )
}

@Composable
private fun ChangePasswordDialog(onSubmit: suspend (String, String, String) -> String?, onDone: () -> Unit) {
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDone() },
        title = { Text("Change master password", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PwField("Current password", old, !busy) { old = it }
                PwField("New password", new, !busy) { new = it }
                PwField("Confirm new password", confirm, !busy) { confirm = it }
                if (busy) Text("Re-encrypting… this takes a few seconds", style = MaterialTheme.typography.bodySmall)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && old.isNotEmpty() && new.isNotEmpty() && confirm.isNotEmpty(),
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val r = onSubmit(old, new, confirm)
                        busy = false
                        if (r == null) { old = ""; new = ""; confirm = ""; onDone() } else error = r
                    }
                }
            ) { Text("Change") }
        },
        dismissButton = { TextButton(onClick = onDone, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun ResetDialog(onSubmit: suspend (String) -> String?, onDone: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDone() },
        title = { Text("Reset vault?", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("This permanently deletes every password stored on this device. Export a backup first if you may need them. Enter your master password to confirm.")
                PwField("Master password", pw, !busy) { pw = it }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && pw.isNotEmpty(),
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val r = onSubmit(pw)
                        busy = false
                        if (r == null) { pw = ""; onDone() } else error = r
                    }
                }
            ) { Text("Delete everything", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = onDone, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun PwField(label: String, value: String, enabled: Boolean, onChange: (String) -> Unit) {
    PasswordField(value = value, onValueChange = onChange, label = label, enabled = enabled)
}

private const val CHANGELOG = """0.2.12
• Save works for entries made with the Android app picker: title is filled from the app name or website
• Validation message is shown at the top of the form; website is optional for native apps
• Native autofill: after unlock the login is filled directly (dataset authentication) or you pick one
• More diagnostics for the unlock step (adb logcat -s BSRPROAutofill)

0.2.1
• Autofill diagnostics, compatibility mode for Chrome and other browsers
• Real BSRPRO app icon, eye icon on every password field, edit history, import options as radio buttons

0.2.0
• Autofill service with inline suggestions, biometric unlock and "save password" prompt
• Settings screen
• Encrypted .Vault backup, CSV / JSON export, import from Chrome, Bitwarden, LastPass, 1Password, Dashlane, KeePass, Firefox, generic CSV and vCard
• Daily auto-backup
• One-time codes (TOTP) with a live countdown, also offered by autofill

0.1.0
• Vault, lock screen, biometric unlock, generator, entry editor"""

private const val PRIVACY = """BSRPRO Vault keeps your passwords only on this device, encrypted with a key derived from your master password (PBKDF2-HMAC-SHA256, 600,000 iterations, AES-256-GCM).

The app is offline-first. Normal vault storage does not upload your data. An optional password-breach check sends only the first 5 characters of a SHA-1 password hash to the Pwned Passwords range service; the full password and full hash are not sent.

Your master password is never stored. If you turn on biometric unlock, it is kept wrapped by a key in the Android Keystore.

Backups and exports are written only where you choose (or to Downloads/BSRPRO_Backups if you enable auto-backup). Plain CSV / JSON exports are not encrypted, so keep them safe or delete them."""

private const val LICENSES = """Kotlin, kotlinx.coroutines, kotlinx.serialization — Apache License 2.0
AndroidX (Core, Activity, Lifecycle, Navigation, Room, DataStore, WorkManager, Biometric, Autofill, Security) and Jetpack Compose — Apache License 2.0
Dagger Hilt — Apache License 2.0
Google Tink — Apache License 2.0
ZXing core — Apache License 2.0
Coil — Apache License 2.0
Timber — Apache License 2.0"""

@Composable
private fun AutofillDiagnosticsDialog(context: android.content.Context, onClose: () -> Unit) {
    val lines = remember { pro.babasitaram.vault.autofill.AutofillDiagnostics.snapshot() }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Autofill diagnostics", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Autofill: " + (if (AutofillStatus.isEnabled(context)) "BSRPRO is the selected service" else "BSRPRO is NOT the selected service") +
                        "\nVersion: " + pro.babasitaram.vault.BuildConfig.VERSION_NAME,
                    style = MaterialTheme.typography.labelMedium
                )
                Spacer(Modifier.height(8.dp))
                if (lines.isEmpty()) {
                    Text("No autofill request has reached the app yet. Open a login form in another app, tap the username field, then come back here.")
                } else {
                    lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.p15_close)) } },
        dismissButton = {
            TextButton(onClick = {
                val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("autofill diagnostics", pro.babasitaram.vault.autofill.AutofillDiagnostics.report()))
            }) { Text("Copy report") }
        }
    )
}


private enum class SettingsCategory(@androidx.annotation.StringRes val title: Int, @androidx.annotation.StringRes val subtitle: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector, val color: androidx.compose.ui.graphics.Color) {
    SECURITY(R.string.settings_cat_security, R.string.settings_cat_security_sub, Icons.Default.Lock, androidx.compose.ui.graphics.Color(0xFFA78BFA)),
    AUTOFILL(R.string.settings_cat_autofill, R.string.settings_cat_autofill_sub, Icons.Default.AutoAwesome, androidx.compose.ui.graphics.Color(0xFF10B981)),
    BACKUP(R.string.settings_cat_backup, R.string.settings_cat_backup_sub, Icons.Default.Backup, androidx.compose.ui.graphics.Color(0xFF6366F1)),
    INTERFACE(R.string.settings_cat_interface, R.string.settings_cat_interface_sub, Icons.Default.Palette, androidx.compose.ui.graphics.Color(0xFFEC4899)),
    GENERATOR(R.string.settings_cat_generator, R.string.settings_cat_generator_sub, Icons.Default.Key, androidx.compose.ui.graphics.Color(0xFFF59E0B)),
    ADVANCED(R.string.settings_cat_advanced, R.string.settings_cat_advanced_sub, Icons.Default.Settings, androidx.compose.ui.graphics.Color(0xFF3B82F6)),
    ABOUT(R.string.settings_cat_about, R.string.settings_cat_about_sub, Icons.Default.Info, androidx.compose.ui.graphics.Color(0xFF6B7280))
}

/** Searchable index: setting title → the category that contains it. */
private val SETTINGS_INDEX: List<Pair<String, SettingsCategory>> = listOf(
    "Change master password" to SettingsCategory.SECURITY, "Biometric unlock" to SettingsCategory.SECURITY,
    "Auto-lock timeout" to SettingsCategory.SECURITY, "Lock when app goes to background" to SettingsCategory.SECURITY,
    "Block weak passwords" to SettingsCategory.SECURITY, "Secure sharing PIN" to SettingsCategory.SECURITY,
    "Recovery key" to SettingsCategory.SECURITY, "Clipboard auto-clear" to SettingsCategory.SECURITY,
    "Allow screenshots" to SettingsCategory.SECURITY, "Hide sensitive recent-app screenshots" to SettingsCategory.SECURITY,
    "Lock vault now" to SettingsCategory.SECURITY,
    "Autofill service" to SettingsCategory.AUTOFILL, "Autofill diagnostics" to SettingsCategory.AUTOFILL,
    "Show suggestions above the keyboard" to SettingsCategory.AUTOFILL, "Autofill regex rules" to SettingsCategory.AUTOFILL,
    "Excluded apps" to SettingsCategory.AUTOFILL, "Save prompts" to SettingsCategory.AUTOFILL,
    "Auto-backup" to SettingsCategory.BACKUP, "Last backup" to SettingsCategory.BACKUP, "Back up now" to SettingsCategory.BACKUP,
    "Backup folder location" to SettingsCategory.BACKUP, "Restore from backup folder" to SettingsCategory.BACKUP,
    "Export encrypted backup" to SettingsCategory.BACKUP, "Import from backup" to SettingsCategory.BACKUP,
    "Import from CSV" to SettingsCategory.BACKUP, "Import from contacts" to SettingsCategory.BACKUP,
    "Theme dark light system" to SettingsCategory.INTERFACE, "App icon colour" to SettingsCategory.INTERFACE,
    "App font size" to SettingsCategory.INTERFACE, "Show category chips" to SettingsCategory.INTERFACE,
    "Default length" to SettingsCategory.GENERATOR, "Custom keyword prefix" to SettingsCategory.GENERATOR,
    "Exclude similar characters" to SettingsCategory.GENERATOR, "Lowercase uppercase numbers symbols" to SettingsCategory.GENERATOR,
    "Hidden vault PIN" to SettingsCategory.ADVANCED, "Failed attempts before lockout duration" to SettingsCategory.SECURITY, "Language hindi english" to SettingsCategory.INTERFACE,
    "Travel mode" to SettingsCategory.ADVANCED, "Emergency access" to SettingsCategory.ADVANCED,
    "Activity log" to SettingsCategory.ADVANCED, "Clear recent searches" to SettingsCategory.ADVANCED,
    "Reset settings to defaults" to SettingsCategory.ADVANCED, "Clear all data reset vault" to SettingsCategory.ADVANCED,
    "Version" to SettingsCategory.ABOUT, "Developer" to SettingsCategory.ABOUT, "Website" to SettingsCategory.ABOUT,
    "GitHub" to SettingsCategory.ABOUT, "Email" to SettingsCategory.ABOUT, "License" to SettingsCategory.ABOUT,
    "Changelog" to SettingsCategory.ABOUT, "Privacy policy" to SettingsCategory.ABOUT
)

@Composable
private fun SettingsHub(query: String, onQuery: (String) -> Unit, onOpen: (SettingsCategory) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQuery,
        placeholder = { Text(stringResource(R.string.settings_search)) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
    )
    val q = query.trim()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    if (q.isEmpty()) {
        SettingsCategory.values().forEach { c ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(c) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(40.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).background(c.color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) { Icon(c.icon, null, tint = c.color, modifier = Modifier.size(20.dp)) }
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(stringResource(c.title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(c.subtitle), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    } else {
        val hits = SETTINGS_INDEX.filter { it.first.contains(q, ignoreCase = true) || ctx.getString(it.second.title).contains(q, ignoreCase = true) }
        if (hits.isEmpty()) Text("No settings match \"$q\"", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        hits.forEach { (title, c) ->
            ActionRow(title, "in " + ctx.getString(c.title)) { onOpen(c) }
        }
    }
}

private fun openLink(context: android.content.Context, url: String) {
    runCatching {
        context.startActivity(android.content.Intent(
            if (url.startsWith("mailto:")) android.content.Intent.ACTION_SENDTO else android.content.Intent.ACTION_VIEW,
            android.net.Uri.parse(url)
        ))
    }
}
