package pro.babasitaram.vault.data.transfer

import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils

data class ImportItem(val entry: VaultEntry, val duplicateOf: VaultEntry?)

enum class DuplicateAction { SKIP, REPLACE, KEEP_BOTH }

/** MERGE keeps the vault and adds / resolves duplicates; REPLACE moves every current entry to the Bin first. */
enum class ImportMode { MERGE, REPLACE }

/** Same rule as the extension's deduplicateImport(): domain + username + mobile digits (notes: title + body). */
object DuplicateDetector {

    fun find(item: VaultEntry, existing: List<VaultEntry>): VaultEntry? = existing.firstOrNull { e ->
        if (item.isNote || e.isNote) {
            item.isNote && e.isNote &&
                e.title.trim().equals(item.title.trim(), ignoreCase = true) &&
                e.notes == item.notes
        } else {
            UrlUtils.domainOf(e.url) == UrlUtils.domainOf(item.url) &&
                e.username.equals(item.username, ignoreCase = true) &&
                digits(e.mobile) == digits(item.mobile)
        }
    }

    fun plan(candidates: List<VaultEntry>, existing: List<VaultEntry>): List<ImportItem> =
        candidates.map { ImportItem(it, find(it, existing)) }

    private fun digits(s: String) = s.filter { it.isDigit() }
}
