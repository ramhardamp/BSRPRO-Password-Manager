package pro.babasitaram.vault.presentation.settings

import android.content.Context
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.core.model.AppIconColor
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAvailability
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.ChangeMasterPasswordUseCase
import pro.babasitaram.vault.domain.usecase.EmergencyAccessUseCase
import pro.babasitaram.vault.domain.usecase.RecoveryKeyUseCase
import pro.babasitaram.vault.data.local.preferences.SensitiveActionPinStore
import pro.babasitaram.vault.domain.usecase.ClearRecentSearchesUseCase
import pro.babasitaram.vault.domain.usecase.ResetVaultUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settings: SettingsRepository,
    private val auth: AuthRepository,
    private val session: SessionKeyStore,
    private val biometric: BiometricAuthenticator,
    private val changePasswordUseCase: ChangeMasterPasswordUseCase,
    private val resetVaultUseCase: ResetVaultUseCase,
    private val clearRecents: ClearRecentSearchesUseCase,
    private val autoBackup: AutoBackupManager,
    private val emergency: EmergencyAccessUseCase,
    private val recovery: RecoveryKeyUseCase,
    private val sharingPin: SensitiveActionPinStore,
    @ApplicationContext private val context: Context,
    private val clipboard: pro.babasitaram.vault.presentation.util.ClipboardActions
) : ViewModel() {

    /** Copies a secret through the vault clipboard manager (sensitive flag + auto-clear). */
    fun copySecret(text: String, label: String) {
        viewModelScope.launch { clipboard.copy(text, label) }
    }

    val state: StateFlow<VaultSettings> = settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultSettings())

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    private fun edit(t: (VaultSettings) -> VaultSettings) {
        viewModelScope.launch { settings.update(t); autoBackup.requestBackup() }
    }

    // Security — every setter persists immediately; AutoLockController reads the repository on each background event,
    // so a new timeout applies the next time the app goes to the background.
    fun setAutoLock(seconds: Int) = edit { it.copy(autoLockSeconds = seconds) }
    fun setLockOnBackground(v: Boolean) = edit { it.copy(lockOnBackground = v) }
    fun setClipboardClear(seconds: Int) = edit { it.copy(clipboardClearSeconds = seconds) }

    // Autofill / generator / appearance
    fun setAutofillInline(v: Boolean) = edit { it.copy(autofillInline = v) }
    fun setAutofillRegex(v: Boolean) = edit { it.copy(autofillRegexEnabled = v) }
    fun setExcludedPackages(text: String) = edit {
        it.copy(autofillExcludedPackages = text.lines().map(String::trim).filter(String::isNotEmpty).distinct().take(100))
    }
    fun setTravelMode(v: Boolean) = edit { it.copy(travelMode = v) }
    fun setAllowScreenshots(v: Boolean) = edit { it.copy(allowScreenshots = v) }
    fun setSavePrompts(v: Boolean) = edit { it.copy(autofillSavePrompts = v) }
    fun setLockoutAttempts(v: Int) = edit { it.copy(lockoutMaxAttempts = v.coerceIn(3, 20)) }
    fun setLockoutSeconds(v: Int) = edit { it.copy(lockoutSeconds = v.coerceIn(10, 3600)) }
    fun setShowCategoryChips(v: Boolean) = edit { it.copy(showCategoryChips = v) }

    /** Generator character sets: at least one set must stay enabled. */
    fun setGeneratorSets(lower: Boolean? = null, upper: Boolean? = null, digits: Boolean? = null, symbols: Boolean? = null) = edit {
        val next = it.copy(
            generatorLower = lower ?: it.generatorLower,
            generatorUpper = upper ?: it.generatorUpper,
            generatorDigits = digits ?: it.generatorDigits,
            generatorSymbols = symbols ?: it.generatorSymbols
        )
        if (!next.generatorLower && !next.generatorUpper && !next.generatorDigits && !next.generatorSymbols) it else next
    }

    fun setAutoBackup(enabled: Boolean) {
        viewModelScope.launch {
            settings.update { it.copy(autoBackupEnabled = enabled) }
            if (enabled) {
                autoBackup.schedule()
                when (val r = autoBackup.backupNow()) {
                    is VaultResult.Success -> _messages.send("Backup saved to ${r.value}")
                    is VaultResult.Failure -> _messages.send("Auto-backup is on, but the first backup failed")
                    VaultResult.Loading -> Unit
                }
            } else autoBackup.cancel()
        }
    }

    fun backupNow() {
        viewModelScope.launch {
            val msg = when (val r = autoBackup.backupNow()) {
                is VaultResult.Success -> "Backup saved to ${r.value}"
                is VaultResult.Failure -> r.error.toUserMessage()
                VaultResult.Loading -> ""
            }
            if (msg.isNotEmpty()) _messages.send(msg)
        }
    }

    /**
     * Restores every preference to its default. Vault data, recovery / emergency secrets, biometric enrolment
     * and the auto-backup schedule are deliberately kept.
     */
    fun resetToDefaults() {
        viewModelScope.launch {
            settings.update { c ->
                VaultSettings().copy(
                    biometricEnabled = c.biometricEnabled,
                    autoBackupEnabled = c.autoBackupEnabled,
                    lastAutoBackupAt = c.lastAutoBackupAt,
                    emergencyEncryptedMaster = c.emergencyEncryptedMaster,
                    emergencyRequestTime = c.emergencyRequestTime,
                    emergencyActive = c.emergencyActive,
                    emergencyContactName = c.emergencyContactName,
                    emergencyContactPhone = c.emergencyContactPhone,
                    recoveryEncryptedMaster = c.recoveryEncryptedMaster,
                    recoveryEncryptedKey = c.recoveryEncryptedKey,
                    recoveryCreatedAt = c.recoveryCreatedAt
                )
            }
            _messages.send("Settings restored to defaults")
        }
    }
    fun setGeneratorLength(n: Int) = edit { it.copy(generatorDefaultLength = n.coerceIn(8, 256)) }
    fun setGeneratorKeyword(k: String) = edit { it.copy(generatorKeyword = k.take(32)) }
    fun setExcludeSimilar(v: Boolean) = edit { it.copy(generatorExcludeSimilar = v) }
    fun setBlockWeakPasswords(v: Boolean) = edit { it.copy(blockWeakPasswords = v) }
    fun setTheme(t: ThemeMode) = edit { it.copy(theme = t) }
    fun setFontScale(percent: Int) = edit { it.copy(fontScalePercent = percent.coerceIn(80, 200)) }
    fun setHideSensitiveRecents(v: Boolean) = viewModelScope.launch {
        settings.update { it.copy(hideSensitiveContentInRecents = v) }
        val activity = (context as? android.app.Activity)
        if (android.os.Build.VERSION.SDK_INT >= 33 && activity != null) {
            activity.setRecentsScreenshotEnabled(!v)
        }
        _messages.send(if (v) "Sensitive recent-app screenshots hidden" else "Recent-app screenshots enabled")
    }

    suspend fun recoveryKey(): String? = when (val r = recovery.currentKey()) {
        is VaultResult.Success -> r.value
        else -> null
    }

    fun setSharingPin(pin: String) {
        viewModelScope.launch {
            try {
                val clean = pin.filter(Char::isDigit).take(6)
                require(clean.length in 4..6) { "Sharing PIN must contain 4-6 digits" }
                sharingPin.save(clean.toCharArray())
                _messages.send("Secure sharing PIN saved")
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                _messages.send(e.message ?: "Could not save sharing PIN")
            }
        }
    }

    fun clearSharingPin() {
        viewModelScope.launch {
            sharingPin.clear()
            _messages.send("Secure sharing PIN removed")
        }
    }

    fun setAppIcon(color: AppIconColor) {
        viewModelScope.launch {
            // the launcher alias is switched when the app goes to the background (see AppIconApplier)
            settings.update { it.copy(appIcon = color) }; autoBackup.requestBackup()
            _messages.send("Icon changes when you leave the app — your launcher may take a moment to refresh")
        }
    }

    fun toggleBiometric(activity: FragmentActivity) {
        viewModelScope.launch {
            if (settings.current().biometricEnabled) {
                auth.clearBiometricCredential()
                settings.update { it.copy(biometricEnabled = false) }
                _messages.send("Biometric unlock disabled")
                return@launch
            }
            if (biometric.availability() != BiometricAvailability.Available) {
                _messages.send("Set up a fingerprint or screen lock in Android settings first")
                return@launch
            }
            biometric.authenticate(activity, "Enable biometric unlock", "Confirm it's you").collect { result ->
                if (result is AuthResult.Success) {
                    session.withPassword { auth.saveBiometricCredential(it) }
                    settings.update { it.copy(biometricEnabled = true) }
                    _messages.send("Biometric unlock enabled")
                }
            }
        }
    }

    /** Returns null on success, otherwise the message to show in the dialog. Wipes all three arrays. */
    suspend fun changeMasterPassword(old: String, new: String, confirm: String): String? {
        val o = old.toCharArray(); val n = new.toCharArray(); val c = confirm.toCharArray()
        return try {
            when (val r = changePasswordUseCase(o, n, c)) {
                is VaultResult.Success -> { autoBackup.requestBackup(); _messages.send("Master password changed"); null }
                is VaultResult.Failure -> r.error.toUserMessage()
                VaultResult.Loading -> null
            }
        } finally {
            o.fill('\u0000'); n.fill('\u0000'); c.fill('\u0000')
        }
    }

    /** Returns null on success (the app then shows the setup screen), otherwise the dialog message. */
    suspend fun resetVault(password: String): String? {
        val pw = password.toCharArray()
        return try {
            when (val r = resetVaultUseCase(pw)) {
                is VaultResult.Failure -> r.error.toUserMessage()
                else -> {
                    sharingPin.clear()
                    null
                }
            }
        } finally {
            pw.fill('\u0000')
        }
    }

    fun setupEmergency() {
        viewModelScope.launch {
            when (val r = emergency.setup()) {
                is VaultResult.Success -> _messages.send("Emergency key: ${r.value}")
                is VaultResult.Failure -> _messages.send(r.error.toUserMessage())
                VaultResult.Loading -> Unit
            }
        }
    }

    fun revokeEmergency() {
        viewModelScope.launch {
            when (val r = emergency.revoke()) {
                is VaultResult.Success -> _messages.send("Emergency access revoked")
                is VaultResult.Failure -> _messages.send(r.error.toUserMessage())
                VaultResult.Loading -> Unit
            }
        }
    }

    fun clearRecentSearches() {
        viewModelScope.launch {
            clearRecents()
            _messages.send("Recent searches cleared")
        }
    }

    fun lockDevice() {
        viewModelScope.launch {
            session.lock()
            _messages.send("Vault locked")
        }
    }
}
