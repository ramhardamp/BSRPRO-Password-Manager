package pro.babasitaram.vault.presentation.files

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.CustomField
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.IdGenerator
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase

private val FILE_KEYS = setOf(
    "file", "filename", "file_uri", "fileurl", "uri", "mime", "mimetype", "filesize", "attachment", "attachmenturi"
)

internal fun VaultEntry.hasFileMetadata(): Boolean =
    recordType.equals("file", true) || recordType.equals("attachment", true) ||
        customFields.any { key -> val normalized = key.k.replace("_", "").lowercase(); normalized in FILE_KEYS || key.k.startsWith("attachment_uri_", true) || key.k.startsWith("attachment_name_", true) || key.k.startsWith("attachment_mime_", true) }

fun VaultEntry.fileField(name: String): String? = customFields.firstOrNull { it.k.equals(name, true) }?.v

@HiltViewModel
class FilesViewModel @Inject constructor(
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase,
    private val deleteEntry: DeleteEntryUseCase,
    @ApplicationContext private val context: Context
) : ViewModel() {
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { values -> values.filter { it.deletedAt == 0L && it.hasFileMetadata() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val messagesChannel = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = messagesChannel.receiveAsFlow()

    fun importFile(uri: Uri) {
        viewModelScope.launch {
            try {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val meta = queryMeta(uri)
                val now = System.currentTimeMillis()
                val id = IdGenerator.newId(now)
                val entry = VaultEntry(
                    id = id,
                    title = meta.name.ifBlank { "Attached file" },
                    notes = "File attachment",
                    recordType = "file",
                    customFields = listOf(
                        CustomField("file_uri", uri.toString()),
                        CustomField("file_name", meta.name),
                        CustomField("mime_type", meta.mime),
                        CustomField("file_size", meta.size.toString())
                    )
                )
                when (val result = saveEntry(entry)) {
                    is VaultResult.Success -> messagesChannel.send("File added")
                    is VaultResult.Failure -> messagesChannel.send(result.error.message ?: "Could not add file")
                    VaultResult.Loading -> Unit
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                messagesChannel.send(e.message ?: "Could not read selected file")
            }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            when (val result = deleteEntry(id)) {
                is VaultResult.Success -> messagesChannel.send("Moved to Bin")
                is VaultResult.Failure -> messagesChannel.send(result.error.message ?: "Could not delete file")
                VaultResult.Loading -> Unit
            }
        }
    }

    private data class FileMeta(val name: String, val mime: String, val size: Long)
    private fun queryMeta(uri: Uri): FileMeta {
        var name = ""
        var size = 0L
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni).orEmpty()
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val mime = context.contentResolver.getType(uri).orEmpty().ifBlank { "application/octet-stream" }
        return FileMeta(name, mime, size)
    }
}
