@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.totpmanager

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun TotpEditorScreen(onDone: () -> Unit, vm: TotpEditorViewModel = hiltViewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    BackHandler(enabled = !s.saving) { onDone() }
    LaunchedEffect(s.saved) { if (s.saved) onDone() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (s.existing == null) "New TOTP" else "Edit TOTP") },
                navigationIcon = { IconButton(onClick = onDone, enabled = !s.saving) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = { Button(onClick = vm::save, enabled = !s.saving && !s.saved) { Text(stringResource(R.string.p15_save)) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            s.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            OutlinedTextField(s.title, vm::setTitle, label = { Text("Service name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.username, vm::setUsername, label = { Text("Username / Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                s.secret, vm::setSecret,
                label = { Text("TOTP secret (base32)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.fillMaxWidth()
            )
            Text("Algorithm", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SHA1", "SHA256", "SHA512").forEach { a ->
                    FilterChip(selected = s.algorithm == a, onClick = { vm.setAlgorithm(a) }, label = { Text(a) })
                }
            }
            Text("Digits", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(6, 8).forEach { d ->
                    FilterChip(selected = s.digits == d, onClick = { vm.setDigits(d) }, label = { Text("$d") })
                }
            }
            Text("Period", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60).forEach { p ->
                    FilterChip(selected = s.period == p, onClick = { vm.setPeriod(p) }, label = { Text("${p}s") })
                }
            }
            OutlinedTextField(
                s.backupCodes, vm::setBackupCodes,
                label = { Text("Backup codes (optional)") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
