package pro.babasitaram.vault.core.security

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** One link the user created. Only the entry title and expiry are kept — never the link or any secret. */
data class ShareRecord(
    val id: String, val entryId: String, val title: String, val createdAt: Long,
    val expiresAt: Long, val viewCount: Int = 0, val revoked: Boolean = false,
    val revokedAt: Long = 0L, val expiredAt: Long = 0L
) {
    fun isActive(now: Long): Boolean = !revoked && expiresAt > now
    fun isExpired(now: Long): Boolean = !revoked && expiresAt <= now
}

/**
 * Local list of created share links. Links are self-contained encrypted fragments, so "revoke" here removes
 * the record from this list; a link that was already sent can only be stopped by its expiry / view limit.
 */
@Singleton
class ShareRecordStore @Inject constructor(@ApplicationContext context: Context) {
    private val prefs = context.getSharedPreferences("bsrpro_share_records", Context.MODE_PRIVATE)
    private val _records = MutableStateFlow(load())
    val records: StateFlow<List<ShareRecord>> = _records.asStateFlow()

    private fun load(): List<ShareRecord> = runCatching {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ShareRecord(o.getString("id"), o.getString("entryId"), o.optString("title"), o.optLong("createdAt"), o.optLong("expiresAt"), o.optInt("viewCount"), o.optBoolean("revoked"), o.optLong("revokedAt"), o.optLong("expiredAt"))
        }
    }.getOrDefault(emptyList())

    private fun persist(list: List<ShareRecord>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("entryId", it.entryId).put("title", it.title)
                .put("createdAt", it.createdAt).put("expiresAt", it.expiresAt)
                .put("viewCount", it.viewCount).put("revoked", it.revoked)
                .put("revokedAt", it.revokedAt).put("expiredAt", it.expiredAt))
        }
        prefs.edit().putString("items", arr.toString()).apply()
        _records.value = list
    }

    fun add(entryId: String, title: String, ttlMs: Long, now: Long = System.currentTimeMillis()) {
        cleanup(now)
        persist(_records.value + ShareRecord(java.util.UUID.randomUUID().toString(), entryId, title, now, now + ttlMs))
    }

    fun revoke(id: String, now: Long = System.currentTimeMillis()) = persist(
        _records.value.map { if (it.id == id && !it.revoked) it.copy(revoked = true, revokedAt = now) else it }
    )
    fun revokeAll(now: Long = System.currentTimeMillis()) = persist(
        _records.value.map { if (!it.revoked && it.expiresAt > now) it.copy(revoked = true, revokedAt = now) else it }
    )
    fun remove(id: String) = revoke(id)

    /** Moves expired items into the expired state and purges records 30 days after expiry/revocation. */
    @Synchronized
    fun cleanup(now: Long = System.currentTimeMillis()) {
        val retention = 30L * 24 * 60 * 60 * 1000
        val updated = _records.value.map { record ->
            if (!record.revoked && record.expiresAt <= now && record.expiredAt == 0L) {
                record.copy(expiredAt = now)
            } else record
        }.filter { record ->
            val terminalAt = when {
                record.revoked -> record.revokedAt.takeIf { it > 0L } ?: record.createdAt
                record.expiredAt > 0L -> record.expiredAt
                else -> 0L
            }
            terminalAt == 0L || now - terminalAt < retention
        }
        if (updated != _records.value) persist(updated)
    }

    fun clearExpired(now: Long = System.currentTimeMillis()) {
        persist(_records.value.filter { it.expiresAt > now || it.revoked })
    }

    fun clearRevoked() = persist(_records.value.filterNot { it.revoked })

    fun clearAll() = persist(emptyList())
}
