package pro.babasitaram.vault.core.util

import java.net.URLDecoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class TotpConfig(
    val secret: String,
    val digits: Int = 6,
    val periodSeconds: Int = 30,
    val algorithm: String = "SHA1"
)

data class TotpCode(val code: String, val secondsRemaining: Int, val periodSeconds: Int)

/** RFC 6238 TOTP. Accepts a bare base32 secret or an otpauth:// URI (as the extension stores them). */
object Totp {
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    fun parse(input: String): TotpConfig? {
        val t = input.trim()
        if (t.isEmpty()) return null
        if (!t.startsWith("otpauth://", ignoreCase = true)) return TotpConfig(secret = t)
        val query = t.substringAfter('?', "")
        val params = query.split('&').filter { it.contains('=') }.associate {
            val k = it.substringBefore('=').lowercase()
            val v = runCatching { URLDecoder.decode(it.substringAfter('='), "UTF-8") }.getOrDefault("")
            k to v
        }
        val secret = params["secret"] ?: return null
        return TotpConfig(
            secret = secret,
            digits = params["digits"]?.toIntOrNull()?.takeIf { it in 6..8 } ?: 6,
            periodSeconds = params["period"]?.toIntOrNull()?.takeIf { it > 0 } ?: 30,
            algorithm = (params["algorithm"] ?: "SHA1").uppercase()
        )
    }

    /** Builds an otpauth:// URI from editor fields (same shape the browser extension stores). */
    fun buildUri(secret: String, issuer: String, account: String, algorithm: String = "SHA1", digits: Int = 6, period: Int = 30): String {
        fun enc(v: String) = java.net.URLEncoder.encode(v, "UTF-8").replace("+", "%20")
        val cleanSecret = secret.filterNot { it.isWhitespace() || it == '-' }.uppercase()
        val label = if (account.isBlank()) enc(issuer) else "${enc(issuer)}:${enc(account)}"
        return "otpauth://totp/$label?secret=$cleanSecret&issuer=${enc(issuer)}&algorithm=$algorithm&digits=$digits&period=$period"
    }

    fun base32Decode(input: String): ByteArray? {
        val clean = input.filterNot { it.isWhitespace() || it == '-' || it == '=' }.uppercase()
        if (clean.isEmpty()) return null
        var buffer = 0
        var bits = 0
        val out = java.io.ByteArrayOutputStream()
        for (c in clean) {
            val v = ALPHABET.indexOf(c)
            if (v < 0) return null
            buffer = (buffer shl 5) or v
            bits += 5
            if (bits >= 8) {
                bits -= 8
                out.write((buffer shr bits) and 0xFF)
            }
        }
        return out.toByteArray()
    }

    fun generate(config: TotpConfig, timeMs: Long): String? {
        val key = base32Decode(config.secret) ?: return null
        val macName = when (config.algorithm) {
            "SHA256" -> "HmacSHA256"
            "SHA512" -> "HmacSHA512"
            else -> "HmacSHA1"
        }
        val counter = timeMs / 1000L / config.periodSeconds
        val msg = ByteArray(8) { i -> ((counter shr (8 * (7 - i))) and 0xFF).toByte() }
        val mac = Mac.getInstance(macName)
        mac.init(SecretKeySpec(key, macName))
        val h = mac.doFinal(msg)
        val offset = h[h.size - 1].toInt() and 0x0F
        val bin = ((h[offset].toInt() and 0x7F) shl 24) or
            ((h[offset + 1].toInt() and 0xFF) shl 16) or
            ((h[offset + 2].toInt() and 0xFF) shl 8) or
            (h[offset + 3].toInt() and 0xFF)
        var mod = 1
        repeat(config.digits) { mod *= 10 }
        return (bin % mod).toString().padStart(config.digits, '0')
    }

    fun current(input: String, timeMs: Long): TotpCode? {
        val cfg = parse(input) ?: return null
        val code = generate(cfg, timeMs) ?: return null
        val period = cfg.periodSeconds
        val remaining = period - ((timeMs / 1000L) % period).toInt()
        return TotpCode(code, remaining, period)
    }
}
