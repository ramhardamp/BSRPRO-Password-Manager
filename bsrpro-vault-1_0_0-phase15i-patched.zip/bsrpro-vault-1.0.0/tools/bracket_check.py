import sys,re,glob
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1] / 'app' / 'src'
bad=0
for f in glob.glob(str(ROOT / '**' / '*.kt'),recursive=True):
    s=open(f).read(); st=[]; i=0; n=len(s); err=None
    pairs={')':'(',']':'[','}':'{'}
    while i<n:
        c=s[i]
        if s.startswith('//',i): i=s.find('\n',i); i=n if i<0 else i; continue
        if s.startswith('/*',i): j=s.find('*/',i+2); i=n if j<0 else j+2; continue
        if s.startswith('"""',i):
            j=s.find('"""',i+3); i=n if j<0 else j+3; continue
        if c=='"':
            i+=1
            while i<n and s[i]!='"':
                i+= 2 if s[i]=='\\' else 1
            i+=1; continue
        if c=="'":
            j=i+1
            if j<n and s[j]=='\\': j+=2
            else: j+=1
            if j<n and s[j]=="'": i=j+1; continue
        if c in '([{': st.append(c)
        elif c in ')]}':
            if not st or st.pop()!=pairs[c]: err='mismatch'; break
        i+=1
    if err or st: print('BAD',f,err,len(st)); bad+=1
print('files with issues:',bad)
