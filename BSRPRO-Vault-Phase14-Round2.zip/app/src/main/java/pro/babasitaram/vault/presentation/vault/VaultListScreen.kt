@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.components.Avatar
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.components.bucketColor
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.findFragmentActivity

private sealed interface ListRow {
    data class Header(val key: String, val count: Int, val expanded: Boolean) : ListRow
    data class Item(val entry: VaultEntry, val indented: Boolean) : ListRow
}

private fun groupKey(e: VaultEntry): String =
    UrlUtils.domainOf(e.url).ifEmpty { e.appName.ifEmpty { e.title.ifEmpty { "other" } } }

private fun buildRows(entries: List<VaultEntry>, grouped: Boolean, expanded: Set<String>): List<ListRow> {
    if (!grouped) return entries.map { ListRow.Item(it, false) }
    return entries.groupBy { groupKey(it) }.flatMap { (key, list) ->
        if (list.size == 1) {
            listOf(ListRow.Item(list.first(), false))
        } else {
            val open = key in expanded
            buildList {
                add(ListRow.Header(key, list.size, open))
                if (open) list.forEach { add(ListRow.Item(it, true)) }
            }
        }
    }
}

@Composable
fun VaultListScreen(
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
    onGenerator: () -> Unit,
    onSettings: () -> Unit,
    onEdit: (String) -> Unit = {},
    onShare: (String) -> Unit = {},
    vm: VaultListViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    var sortMenuOpen by remember { mutableStateOf(false) }
    var createFolderOpen by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(emptySet<String>()) }
    CollectMessages(vm.messages)

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            OutlinedTextField(
                value = state.query,
                onValueChange = vm::setQuery,
                placeholder = { Text("Search passwords") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(ListFilter.values().toList()) { filter ->
                    FilterChip(
                        selected = state.filter == filter,
                        onClick = { vm.setFilter(filter) },
                        label = { Text(filter.label) }
                    )
                }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(CATEGORIES) { category ->
                    FilterChip(
                        selected = state.category == category,
                        onClick = { vm.setCategory(category) },
                        label = { Text(category.replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = state.folderId == null,
                        onClick = { vm.setFolder(null) },
                        label = { Text("All folders") }
                    )
                }
                items(state.folders, key = { it.id }) { folder ->
                    FilterChip(
                        selected = state.folderId == folder.id,
                        onClick = { vm.setFolder(folder.id) },
                        label = { Text(folder.name) }
                    )
                }
                item {
                    FilterChip(
                        selected = false,
                        onClick = { createFolderOpen = true },
                        label = { Text("+ Folder") }
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    IconButton(onClick = { sortMenuOpen = true }) {
                        Icon(Icons.Default.Sort, contentDescription = "Sort")
                    }
                    DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                        SortMode.values().forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option.label) },
                                onClick = { sortMenuOpen = false; vm.setSort(option) }
                            )
                        }
                    }
                }
                IconButton(onClick = vm::toggleGrouped) {
                    Icon(Icons.AutoMirrored.Filled.ViewList, contentDescription = "Group by site")
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Manage folders") },
                            onClick = { menuOpen = false; createFolderOpen = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Password generator") },
                            onClick = { menuOpen = false; onGenerator() }
                        )
                        DropdownMenuItem(
                            text = { Text(if (state.biometricEnabled) "Disable biometric unlock" else "Enable biometric unlock") },
                            onClick = {
                                menuOpen = false
                                context.findFragmentActivity()?.let { vm.toggleBiometric(it) }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = { menuOpen = false; onSettings() }
                        )
                        DropdownMenuItem(
                            text = { Text("Lock now") },
                            onClick = { menuOpen = false; vm.lock() }
                        )
                    }
                }
            }

            val rows = remember(state.entries, state.grouped, expanded) {
                buildRows(state.entries, state.grouped, expanded)
            }

            when {
                state.totalCount == 0 -> EmptyState(
                    "No passwords yet",
                    "Tap + to add one, or restore a backup when creating a vault."
                )
                rows.isEmpty() -> EmptyState("No matches", "Try a different search or filter.")
                else -> {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        items(rows) { row ->
                            when (row) {
                                is ListRow.Header -> ListItem(
                                    headlineContent = { Text(row.key) },
                                    supportingContent = { Text("${row.count} entries") },
                                    leadingContent = { Icon(Icons.Default.Folder, contentDescription = null) },
                                    trailingContent = {
                                        Icon(
                                            if (row.expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null
                                        )
                                    },
                                    modifier = Modifier.clickable {
                                        expanded = if (row.key in expanded) expanded - row.key else expanded + row.key
                                    }
                                )
                                is ListRow.Item -> EntryRow(
                                    entry = row.entry,
                                    indented = row.indented,
                                    onClick = { onOpen(row.entry.id) },
                                    onCopy = { vm.copyPassword(row.entry) },
                                    onCopyUsername = { vm.copyUsername(row.entry) },
                                    onCopyTotp = { vm.copyTotp(row.entry) },
                                    onEdit = { onEdit(row.entry.id) },
                                    onDelete = { vm.delete(row.entry) },
                                    onShare = { onShare(row.entry.id) },
                                    onToggleStar = { vm.toggleStar(row.entry) }
                                )
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = onAdd,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .navigationBarsPadding()
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add entry")
        }
    }

    if (createFolderOpen) {
        AlertDialog(
            onDismissRequest = { newFolderName = ""; createFolderOpen = false },
            title = { Text("New folder") },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Folder name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.createFolder(newFolderName)
                        newFolderName = ""
                        createFolderOpen = false
                    },
                    enabled = newFolderName.trim().isNotEmpty()
                ) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { newFolderName = ""; createFolderOpen = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun EntryRow(
    entry: VaultEntry,
    indented: Boolean,
    onClick: () -> Unit,
    onCopy: () -> Unit,
    onCopyUsername: () -> Unit,
    onCopyTotp: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onToggleStar: () -> Unit
) {
    val subtitle = entry.username.ifEmpty { UrlUtils.domainOf(entry.url).ifEmpty { entry.appName } }
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    ListItem(
        headlineContent = { Text(entry.title.ifEmpty { "(untitled)" }, maxLines = 1) },
        supportingContent = { if (subtitle.isNotEmpty()) Text(subtitle, maxLines = 1) },
        leadingContent = { Avatar(entry.title.ifEmpty { subtitle }) },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (entry.starred) Icon(Icons.Default.Star, "Starred", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                if (entry.password.isNotEmpty()) {
                    Box(Modifier.padding(horizontal = 6.dp).size(8.dp).background(bucketColor(entry.strengthBucket()), CircleShape))
                    IconButton(onClick = onCopy) { Icon(Icons.Default.ContentCopy, "Copy password") }
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Entry actions") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (entry.password.isNotBlank()) DropdownMenuItem(text = { Text("Copy password") }, onClick = { menu = false; onCopy() })
                        if (entry.username.isNotBlank()) DropdownMenuItem(text = { Text("Copy username") }, onClick = { menu = false; onCopyUsername() })
                        if (entry.totp.isNotBlank()) DropdownMenuItem(text = { Text("Copy TOTP") }, onClick = { menu = false; onCopyTotp() })
                        DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text("Move to Bin") }, onClick = { menu = false; confirmDelete = true })
                        DropdownMenuItem(text = { Text("Share securely") }, onClick = { menu = false; onShare() })
                        DropdownMenuItem(text = { Text(if (entry.starred) "Remove from favorites" else "Add to favorites") }, onClick = { menu = false; onToggleStar() })
                    }
                }
            }
        },
        modifier = Modifier
            .combinedClickable(onClick = onClick, onLongClick = { menu = true })
            .padding(start = if (indented) 24.dp else 0.dp)
    )

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Move to Bin?") },
            text = { Text("${entry.title.ifBlank { "This entry" }} will be moved to Bin and kept for up to 30 days.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Move to Bin") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}
