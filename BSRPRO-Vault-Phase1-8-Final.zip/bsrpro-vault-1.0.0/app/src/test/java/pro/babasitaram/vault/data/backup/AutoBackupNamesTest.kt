package pro.babasitaram.vault.data.backup

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class AutoBackupNamesTest {
    @Test fun `recognizes only dated legacy vault backup names`() {
        assertTrue(AutoBackupNames.isLegacyDated("vault_20261002.Vault"))
        assertTrue(AutoBackupNames.isLegacyDated("VAULT_20240131.vault"))
        assertFalse(AutoBackupNames.isLegacyDated("BSRPRO.Vault"))
        assertFalse(AutoBackupNames.isLegacyDated("vault_20261340.Vault"))
        assertFalse(AutoBackupNames.isLegacyDated("vault_2026102.Vault"))
        assertFalse(AutoBackupNames.isLegacyDated("my_vault_20261002.Vault"))
    }
    @Test fun `debounce interval coalesces rapid changes`() {
        assertEquals(2_500L, AutoBackupManager.DEBOUNCE_MS)
    }
}
