package pro.babasitaram.vault.presentation.sharing

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dagger.hilt.android.AndroidEntryPoint
import java.security.MessageDigest
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.SecureShareManager
import pro.babasitaram.vault.domain.repository.VaultRepository

@AndroidEntryPoint
class SecureShareActivity : ComponentActivity() {
    @javax.inject.Inject lateinit var repository: VaultRepository
    @javax.inject.Inject lateinit var autoBackup: pro.babasitaram.vault.data.backup.AutoBackupManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var result by mutableStateOf<VaultEntry?>(null)
        var loaded by mutableStateOf(false)
        lifecycleScope.launch {
            result = decodeShare(intent?.data?.fragment)
            loaded = true
        }
        setContent {
            var imported by remember { mutableStateOf(false) }
            pro.babasitaram.vault.presentation.theme.VaultTheme {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Secure Share", style = MaterialTheme.typography.headlineSmall)
                    if (!loaded) {
                        Text("Decrypting secure share…")
                    } else if (result == null) {
                        Text("This link is invalid or expired.", color = MaterialTheme.colorScheme.error)
                    } else {
                        val shared = result!!
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(shared.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium)
                                if (shared.username.isNotBlank()) Text(shared.username)
                                if (shared.url.isNotBlank()) Text(shared.url)
                                if (shared.password.isNotBlank()) Text("Password protected — reveal only after import")
                            }
                        }
                        Button(
                            onClick = {
                                lifecycleScope.launch {
                                    repository.upsert(shared)
                                    autoBackup.requestBackup()
                                    imported = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !imported
                        ) {
                            Text(if (imported) "Imported" else "Import into vault")
                        }
                    }
                    Button(onClick = ::finish, modifier = Modifier.fillMaxWidth()) { Text("Close") }
                }
            }
        }
    }

    private suspend fun decodeShare(fragment: String?): VaultEntry? {
        val raw = fragment?.let(android.net.Uri::decode) ?: return null
        val parts = raw.split('.')
        if (parts.size != 3) return null
        val expiry = parts[2].toLongOrNull() ?: return null
        if (System.currentTimeMillis() > expiry) return null
        val cipher = SecureShareManager.decodeCiphertext(parts[0])
        val key = parts[1].toCharArray()
        return try {
            val fingerprint = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).joinToString("") { "%02x".format(it) }
            val prefs = getSharedPreferences("secure_share", MODE_PRIVATE)
            if (prefs.getBoolean(fingerprint, false)) return null
            val plain = withContext(Dispatchers.Default) { VaultCrypto.decrypt(cipher, key) }
            val entry = pro.babasitaram.vault.core.crypto.VaultJson.decodeFromString(VaultEntry.serializer(), plain)
            prefs.edit().putBoolean(fingerprint, true).apply()
            entry
        } catch (_: Exception) {
            null
        } finally {
            key.fill('\u0000')
        }
    }
}
