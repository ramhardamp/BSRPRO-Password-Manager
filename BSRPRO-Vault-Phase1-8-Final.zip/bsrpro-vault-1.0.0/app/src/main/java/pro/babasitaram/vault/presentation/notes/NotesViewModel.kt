// file: app/src/main/java/pro/babasitaram/vault/presentation/notes/NotesViewModel.kt
package pro.babasitaram.vault.presentation.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.domain.repository.VaultRepository

@HiltViewModel
class NotesViewModel @Inject constructor(
    repository: VaultRepository
) : ViewModel() {
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { values -> values.filter { it.deletedAt == 0L && (it.isNote || it.recordType.equals("note", true) || it.notes.isNotBlank()) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}
