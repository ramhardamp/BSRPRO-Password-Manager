package pro.babasitaram.vault.presentation.lock

import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAvailability
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.UnlockVaultUseCase
import pro.babasitaram.vault.domain.usecase.EmergencyAccessUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage

data class LockUiState(
    val busy: Boolean = false,
    val error: String? = null,
    val lockedSeconds: Int = 0,
    val biometricAvailable: Boolean = false,
    val emergencyConfigured: Boolean = false,
    val emergencyRequestTime: Long = 0L
)

@HiltViewModel
class LockViewModel @Inject constructor(
    private val unlockVault: UnlockVaultUseCase,
    private val auth: AuthRepository,
    private val settings: SettingsRepository,
    private val biometric: BiometricAuthenticator,
    private val emergency: EmergencyAccessUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(LockUiState())
    val state: StateFlow<LockUiState> = _state.asStateFlow()
    private var countdown: Job? = null

    init {
        viewModelScope.launch {
            val enabled = settings.current().biometricEnabled &&
                auth.hasBiometricCredential() &&
                biometric.availability() == BiometricAvailability.Available
            val emergencyStatus = emergency.status()
            _state.update { it.copy(biometricAvailable = enabled, emergencyConfigured = emergencyStatus.configured, emergencyRequestTime = emergencyStatus.requestTime) }
            val remaining = auth.lockoutState().lockedUntilMs - System.currentTimeMillis()
            if (remaining > 0) startCountdown(remaining)
        }
    }

    fun unlock(password: String) {
        val pw = password.toCharArray()
        viewModelScope.launch {
            try {
                attemptUnlock(pw)
            } finally {
                pw.fill('\u0000')
            }
        }
    }

    private suspend fun attemptUnlock(pw: CharArray): VaultResult<Unit> {
        _state.update { it.copy(busy = true, error = null) }
        val r = unlockVault(pw)
        if (r is VaultResult.Failure) {
            val e = r.error
            val message = when {
                e == VaultError.InvalidMasterPassword -> {
                    val ls = auth.lockoutState()
                    if (ls.lockedUntilMs > System.currentTimeMillis()) {
                        startCountdown(ls.lockedUntilMs - System.currentTimeMillis())
                        "Too many attempts"
                    } else {
                        val left = auth.remainingAttempts(ls)
                        "Incorrect password. $left attempt${if (left == 1) "" else "s"} left."
                    }
                }
                e is VaultError.RateLimited -> {
                    startCountdown(e.retryAfterMs)
                    "Too many attempts"
                }
                else -> e.toUserMessage()
            }
            _state.update { it.copy(busy = false, error = message) }
        } else {
            _state.update { it.copy(busy = false) }
        }
        return r
    }

    fun unlockWithBiometric(activity: FragmentActivity) {
        viewModelScope.launch {
            biometric.authenticate(activity, "Unlock BSRPRO Vault", "Confirm it's you").collect { result ->
                when (result) {
                    is AuthResult.Success -> unlockFromStoredCredential()
                    is AuthResult.Error -> _state.update { it.copy(error = result.message) }
                    AuthResult.Failed, AuthResult.Cancelled -> Unit
                }
            }
        }
    }

    private suspend fun unlockFromStoredCredential() {
        val pw = auth.loadBiometricCredential()
        if (pw == null) {
            _state.update { it.copy(biometricAvailable = false, error = "Enter your master password") }
            return
        }
        try {
            val r = attemptUnlock(pw)
            if (r is VaultResult.Failure && r.error == VaultError.InvalidMasterPassword) {
                // master password changed since biometrics were enabled
                auth.clearBiometricCredential()
                settings.update { it.copy(biometricEnabled = false) }
                _state.update { it.copy(biometricAvailable = false, error = "Master password changed — enter it manually") }
            }
        } finally {
            pw.fill('\u0000')
        }
    }


    fun requestEmergency(key: String) {
        viewModelScope.launch {
            when (val r = emergency.request(key)) {
                is VaultResult.Success -> _state.update { it.copy(error = "Emergency request submitted. Unlock available after 72 hours.", emergencyRequestTime = r.value - EmergencyAccessUseCase.WAIT_MS) }
                is VaultResult.Failure -> _state.update { it.copy(error = r.error.toUserMessage()) }
                VaultResult.Loading -> Unit
            }
        }
    }

    fun unlockEmergency(key: String) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = null) }
            when (val r = emergency.unlock(key)) {
                is VaultResult.Success -> {
                    _state.update { it.copy(busy = false) }
                }
                is VaultResult.Failure -> {
                    _state.update { it.copy(busy = false, error = r.error.toUserMessage()) }
                }
                VaultResult.Loading -> Unit
            }
        }
    }

    private fun startCountdown(ms: Long) {
        countdown?.cancel()
        countdown = viewModelScope.launch {
            var left = ((ms + 999) / 1000).toInt()
            while (left > 0) {
                _state.update { it.copy(lockedSeconds = left) }
                delay(1_000)
                left--
            }
            _state.update { it.copy(lockedSeconds = 0, error = null) }
        }
    }
}
