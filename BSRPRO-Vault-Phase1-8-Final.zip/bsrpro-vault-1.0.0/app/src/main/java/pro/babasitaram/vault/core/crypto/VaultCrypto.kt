package pro.babasitaram.vault.core.crypto

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.BadPaddingException
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import pro.babasitaram.vault.core.constants.VaultConstants
import pro.babasitaram.vault.core.util.VaultError

/**
 * Bit-for-bit compatible with the browser extension's src/crypto.js:
 *  - legacy vault/canary format: base64( salt16 || iv12 || AES-GCM ciphertext+tag )
 *  - V3 backup container: {"header":{...canonical...},"ciphertext":"b64"} with the header as GCM AAD.
 */
/** A derived AES key together with the salt it was derived from (lets the blob store re-encrypt without a new PBKDF2 run). */
class DerivedVaultKey(val salt: ByteArray, val key: SecretKey)

object VaultCrypto {
    private const val ITERATIONS = VaultConstants.PBKDF2_ITERATIONS
    private const val SALT_SIZE = VaultConstants.SALT_BYTES
    private const val IV_SIZE = VaultConstants.IV_BYTES
    private const val TAG_BITS = VaultConstants.GCM_TAG_BITS
    private const val MIN_PACKED = SALT_SIZE + IV_SIZE + 16

    private val secureRandom = SecureRandom()
    private val canonicalKeys = listOf("format", "version", "kdf", "iterations", "salt", "iv", "cipher", "tagBits")

    // ───────── public API ─────────
    suspend fun deriveKey(password: CharArray, salt: ByteArray): SecretKey =
        withContext(Dispatchers.Default) { deriveKeyBlocking(password, salt) }

    suspend fun encrypt(plaintext: String, password: CharArray): String = withContext(Dispatchers.Default) {
        encryptBlocking(plaintext, password, secureRandom.randomBytes(SALT_SIZE), secureRandom.randomBytes(IV_SIZE))
    }

    suspend fun decrypt(ciphertextB64: String, password: CharArray): String =
        withContext(Dispatchers.Default) { decryptBlocking(ciphertextB64, password) }

    suspend fun hashMaster(password: CharArray): String = encrypt(VaultConstants.VAULT_CANARY, password)

    suspend fun verifyMaster(hashB64: String, password: CharArray): Boolean = try {
        decrypt(hashB64, password) == VaultConstants.VAULT_CANARY
    } catch (e: VaultError) {
        false
    }

    suspend fun encryptV3(plaintext: String, password: CharArray): String = withContext(Dispatchers.Default) {
        encryptV3Blocking(plaintext, password, secureRandom.randomBytes(SALT_SIZE), secureRandom.randomBytes(IV_SIZE))
    }

    suspend fun decryptV3(container: String, password: CharArray): String =
        withContext(Dispatchers.Default) { decryptV3Blocking(container, password) }

    fun wipeChars(chars: CharArray) = chars.fill('\u0000')

    /** New random salt + PBKDF2 key. */
    suspend fun deriveNewVaultKey(password: CharArray): DerivedVaultKey = withContext(Dispatchers.Default) {
        val salt = secureRandom.randomBytes(SALT_SIZE)
        DerivedVaultKey(salt, deriveKeyBlocking(password, salt))
    }

    /** Legacy-format encrypt that reuses an already derived key (fresh random IV, same salt). */
    suspend fun encryptWithKey(plaintext: String, dk: DerivedVaultKey): String = withContext(Dispatchers.Default) {
        encryptWithKeyBlocking(plaintext, dk, secureRandom.randomBytes(IV_SIZE))
    }

    /** Legacy-format decrypt that also returns the derived key so the caller can cache it. */
    suspend fun decryptWithKeyInfo(ciphertextB64: String, password: CharArray): Pair<String, DerivedVaultKey> =
        withContext(Dispatchers.Default) {
            val packed = decodeB64(ciphertextB64.filterNot { it.isWhitespace() })
            if (packed.size < MIN_PACKED) throw VaultError.InvalidFormat("Invalid ciphertext: too short")
            val salt = packed.copyOfRange(0, SALT_SIZE)
            val iv = packed.copyOfRange(SALT_SIZE, SALT_SIZE + IV_SIZE)
            val ct = packed.copyOfRange(SALT_SIZE + IV_SIZE, packed.size)
            val key = deriveKeyBlocking(password, salt)
            decryptToString(key, iv, ct, null) to DerivedVaultKey(salt, key)
        }

    internal fun encryptWithKeyBlocking(plaintext: String, dk: DerivedVaultKey, iv: ByteArray): String {
        val ct = aesGcm(Cipher.ENCRYPT_MODE, dk.key, iv, plaintext.toByteArray(Charsets.UTF_8), null)
        return b64(dk.salt + iv + ct)
    }

    // ───────── internals (deterministic variants are used by golden-vector tests) ─────────
    internal fun deriveKeyBlocking(password: CharArray, salt: ByteArray): SecretKey {
        require(salt.size == SALT_SIZE) { "Salt must be $SALT_SIZE bytes" }
        require(password.isNotEmpty()) { "Password must not be empty" }
        val keyBytes = Pbkdf2.deriveSha256(password, salt, ITERATIONS, 32)
        try {
            return SecretKeySpec(keyBytes, "AES")
        } finally {
            keyBytes.fill(0)
        }
    }

    internal fun encryptBlocking(plaintext: String, password: CharArray, salt: ByteArray, iv: ByteArray): String {
        val key = deriveKeyBlocking(password, salt)
        val ct = aesGcm(Cipher.ENCRYPT_MODE, key, iv, plaintext.toByteArray(Charsets.UTF_8), null)
        return b64(salt + iv + ct)
    }

    internal fun decryptBlocking(ciphertextB64: String, password: CharArray): String {
        val packed = decodeB64(ciphertextB64.filterNot { it.isWhitespace() })
        if (packed.size < SALT_SIZE + IV_SIZE) throw VaultError.InvalidFormat("Invalid ciphertext: too short")
        if (packed.size < MIN_PACKED) throw VaultError.InvalidFormat("Invalid ciphertext: payload too short")
        val salt = packed.copyOfRange(0, SALT_SIZE)
        val iv = packed.copyOfRange(SALT_SIZE, SALT_SIZE + IV_SIZE)
        val ct = packed.copyOfRange(SALT_SIZE + IV_SIZE, packed.size)
        return decryptToString(deriveKeyBlocking(password, salt), iv, ct, null)
    }

    internal fun canonicalHeader(salt: ByteArray, iv: ByteArray): String =
        // Must be byte-identical to canonicalHeader() in crypto.js (it is also the GCM AAD).
        """{"format":"BSRPRO.Vault","version":3,"kdf":"PBKDF2-HMAC-SHA256","iterations":600000,""" +
            """"salt":"${b64(salt)}","iv":"${b64(iv)}","cipher":"AES-256-GCM","tagBits":128}"""

    internal fun encryptV3Blocking(plaintext: String, password: CharArray, salt: ByteArray, iv: ByteArray): String {
        val header = canonicalHeader(salt, iv)
        val key = deriveKeyBlocking(password, salt)
        val ct = aesGcm(Cipher.ENCRYPT_MODE, key, iv, plaintext.toByteArray(Charsets.UTF_8), header.toByteArray(Charsets.UTF_8))
        return """{"header":$header,"ciphertext":"${b64(ct)}"}"""
    }

    internal fun decryptV3Blocking(container: String, password: CharArray): String {
        val root = try {
            Json.parseToJsonElement(container) as? JsonObject
        } catch (e: Exception) {
            null
        } ?: throw VaultError.InvalidFormat("Not a V3 container")
        val h = root["header"] as? JsonObject ?: throw VaultError.InvalidFormat("Missing V3 header")

        fun str(k: String) = (h[k] as? JsonPrimitive)?.takeIf { it.isString }?.content
        fun num(k: String) = (h[k] as? JsonPrimitive)?.takeIf { !it.isString }?.content

        // Only backups produced by BSRPRO (extension or this app) pass; other apps' files are rejected here.
        if (str("format") != VaultConstants.V3_FORMAT || num("version") != "3" ||
            str("kdf") != VaultConstants.V3_KDF || num("iterations") != ITERATIONS.toString() ||
            str("cipher") != VaultConstants.V3_CIPHER || num("tagBits") != TAG_BITS.toString()
        ) throw VaultError.InvalidFormat("Unsupported V3 header")

        val salt = decodeB64(str("salt") ?: throw VaultError.InvalidFormat("Missing V3 salt"))
        val iv = decodeB64(str("iv") ?: throw VaultError.InvalidFormat("Missing V3 iv"))
        if (salt.size != SALT_SIZE || iv.size != IV_SIZE) throw VaultError.InvalidFormat("Invalid V3 salt/iv")

        val canonical = canonicalHeader(salt, iv)
        if (h != Json.parseToJsonElement(canonical) || h.keys.toList() != canonicalKeys) {
            throw VaultError.InvalidFormat("Non-canonical V3 header")
        }

        val ctB64 = (root["ciphertext"] as? JsonPrimitive)?.takeIf { it.isString }?.content
            ?: throw VaultError.InvalidFormat("Missing V3 ciphertext")
        val ct = decodeB64(ctB64)
        if (ct.size < 16) throw VaultError.InvalidFormat("Truncated V3 ciphertext")

        return decryptToString(deriveKeyBlocking(password, salt), iv, ct, canonical.toByteArray(Charsets.UTF_8))
    }

    // ───────── helpers ─────────
    private fun aesGcm(mode: Int, key: SecretKey, iv: ByteArray, input: ByteArray, aad: ByteArray?): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(mode, key, GCMParameterSpec(TAG_BITS, iv))
        if (aad != null) cipher.updateAAD(aad)
        return cipher.doFinal(input)
    }

    private fun decryptToString(key: SecretKey, iv: ByteArray, ct: ByteArray, aad: ByteArray?): String {
        val plain = try {
            aesGcm(Cipher.DECRYPT_MODE, key, iv, ct, aad)
        } catch (e: BadPaddingException) {
            // GCM tag mismatch: wrong password or tampered data (indistinguishable by design)
            throw VaultError.InvalidMasterPassword
        }
        try {
            return String(plain, Charsets.UTF_8)
        } finally {
            plain.fill(0)
        }
    }

    private fun b64(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)

    private fun decodeB64(s: String): ByteArray = try {
        Base64.getDecoder().decode(s)
    } catch (e: IllegalArgumentException) {
        throw VaultError.InvalidFormat("Invalid base64")
    }
}
