// file: app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesViewModel.kt
package pro.babasitaram.vault.presentation.mobiles

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.domain.repository.VaultRepository

@HiltViewModel
class MobilesViewModel @Inject constructor(
    repository: VaultRepository
) : ViewModel() {
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { values -> values.filter { it.deletedAt == 0L && (it.mobile.isNotBlank() || it.phone.isNotBlank() || it.recordType.equals("mobile", true)) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}
