package pro.babasitaram.vault.domain.usecase

import javax.inject.Inject
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository

/** Re-checks the master password (rate-limited like the lock screen) before sensitive actions. */
class VerifyMasterPasswordUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val auth: AuthRepository
) {
    suspend operator fun invoke(password: CharArray): VaultResult<Unit> = vaultCatching {
        auth.checkAllowed()
        try {
            blobStore.read(password)
        } catch (e: VaultError.InvalidMasterPassword) {
            auth.recordFailure()
            throw e
        }
        auth.recordSuccess()
    }
}

/** Re-encrypts the vault under a new master password. The old password stops working immediately. */
class ChangeMasterPasswordUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val auth: AuthRepository,
    private val settings: SettingsRepository
) {
    suspend operator fun invoke(old: CharArray, new: CharArray, confirm: CharArray): VaultResult<Unit> = vaultCatching {
        if (!new.contentEquals(confirm)) throw VaultError.Validation("New passwords do not match")
        if (new.contentEquals(old)) throw VaultError.Validation("The new password must differ from the current one")
        if (!PasswordStrength.isAcceptableMaster(java.nio.CharBuffer.wrap(new))) {
            throw VaultError.Validation("Use at least 12 characters with upper & lower case letters, digits or symbols")
        }
        auth.checkAllowed()
        val data = try {
            blobStore.read(old)                      // full payload incl. folder markers
        } catch (e: VaultError.InvalidMasterPassword) {
            auth.recordFailure()
            throw e
        }
        auth.recordSuccess()
        blobStore.write(data, new)                   // new salt + new key (cache fingerprint no longer matches)
        blobStore.deleteBackups()                    // .bak / .bak2 are still encrypted with the OLD password
        session.unlock(new)
        // The old emergency ciphertext decrypts only to the old master password; invalidate it.
        settings.update { it.copy(emergencyEncryptedMaster = "", emergencyRequestTime = 0L, emergencyActive = false) }
        if (settings.current().biometricEnabled) auth.saveBiometricCredential(new)
    }
}

/** Wipes the vault from this device. Requires the master password. */
class ResetVaultUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val repository: VaultRepository,
    private val auth: AuthRepository,
    private val settings: SettingsRepository,
    private val verify: VerifyMasterPasswordUseCase
) {
    suspend operator fun invoke(password: CharArray): VaultResult<Unit> {
        val r = verify(password)
        if (r is VaultResult.Failure) return r
        return vaultCatching {
            blobStore.deleteAll()
            auth.clearBiometricCredential()
            settings.update { it.copy(biometricEnabled = false, autoBackupEnabled = false, lastAutoBackupAt = 0L, emergencyEncryptedMaster = "", emergencyRequestTime = 0L, emergencyActive = false) }
            repository.clear()
            session.lock()                           // RootViewModel then shows the setup screen
        }
    }
}

class ClearRecentSearchesUseCase @Inject constructor(private val dao: VaultDao) {
    suspend operator fun invoke() = dao.clearRecents()
}
