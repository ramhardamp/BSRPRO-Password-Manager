// file: app/src/main/java/pro/babasitaram/vault/presentation/notes/NotesScreen.kt
package pro.babasitaram.vault.presentation.notes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState

@Composable
fun NotesScreen(onBack: () -> Unit = {}, vm: NotesViewModel = hiltViewModel()) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    Scaffold(topBar = { TopAppBar(title = { Text("Notes") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } }) }) { padding ->
        if (entries.isEmpty()) {
            EmptyState("No notes", "Entries with notes or note records will appear here.", Modifier.padding(padding).fillMaxWidth())
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(entries, key = { it.id }) { entry -> NoteItem(entry) }
            }
        }
    }
}

@Composable
private fun NoteItem(entry: VaultEntry) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(entry.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium)
            if (entry.notes.isNotBlank()) Text(entry.notes)
            else Text("Note record without note text", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
