// file: app/src/main/java/pro/babasitaram/vault/presentation/files/FilesViewModel.kt
package pro.babasitaram.vault.presentation.files

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.domain.repository.VaultRepository

private val FILE_KEYS = setOf(
    "file", "filename", "fileName", "file_uri", "fileUri", "file_url", "fileUrl",
    "files", "attachment", "attachmentUri", "mime", "mimeType", "fileSize", "size"
)

private fun VaultEntry.hasFileMetadata(): Boolean =
    recordType.equals("file", true) || recordType.equals("attachment", true) ||
        customFields.any { it.k.lowercase() in FILE_KEYS.map(String::lowercase).toSet() }

@HiltViewModel
class FilesViewModel @Inject constructor(
    repository: VaultRepository
) : ViewModel() {
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { values -> values.filter { it.deletedAt == 0L && it.hasFileMetadata() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}
