package pro.babasitaram.vault.autofill

import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.core.util.UrlUtils

/** EXACT = same domain / same Android package. RELATED = parent or sub-domain (shown with a warning). */
enum class MatchKind { EXACT, RELATED }

data class EntryMatch(val entry: VaultEntry, val kind: MatchKind)

object AutofillMatcher {

    fun match(entries: List<VaultEntry>, packageName: String, webDomain: String?): List<EntryMatch> {
        val host = webDomain?.let { UrlUtils.domainOf(it) }.orEmpty()
        val out = ArrayList<EntryMatch>()
        for (e in entries) {
            if (e.isFolderMarker || e.isNote || e.recordType.equals("note", ignoreCase = true)) continue
            if (e.username.isEmpty() && e.password.isEmpty() && e.appPin.isEmpty() && e.totp.isEmpty()) continue
            // Explicit Android package association takes precedence and can match even
            // when the Autofill framework also reports a web domain.
            val kind = appKind(e, packageName) ?: if (host.isNotEmpty()) webKind(e, host) else null
            if (kind != null) out.add(EntryMatch(e, kind))
        }
        return out.sortedWith(
            compareBy<EntryMatch> { it.kind.ordinal }
                .thenByDescending { it.entry.lastUsedAt }
                .thenByDescending { it.entry.updatedAt }
                .thenBy { it.entry.title.lowercase() }
        )
    }

    private fun webKind(e: VaultEntry, host: String): MatchKind? {
        val entryHost = UrlUtils.domainOf(e.url)
        if (entryHost.isEmpty()) return null
        return when {
            entryHost == host -> MatchKind.EXACT
            host.endsWith(".$entryHost") || entryHost.endsWith(".$host") -> MatchKind.RELATED
            else -> null
        }
    }

    private fun appKind(e: VaultEntry, packageName: String): MatchKind? {
        val requestedPackage = packageName.trim()
        if (requestedPackage.isEmpty()) return null
        val savedPackage = e.appPackage.trim()
        val savedUrl = e.url.trim()
        val viaUrl = savedUrl.startsWith("androidapp://", ignoreCase = true) &&
            savedUrl.substringAfter("androidapp://", "").trim() == requestedPackage
        return if ((savedPackage.isNotEmpty() && savedPackage == requestedPackage) || viaUrl) MatchKind.EXACT else null
    }
}

/** What goes into each kind of field. Pure functions so they can be unit-tested. */
object AutofillValues {
    /** If the current code expires within this many seconds, the next period's code is used instead. */
    const val OTP_EDGE_SECONDS = 3

    fun valueFor(type: AutofillFieldType, e: VaultEntry, nowMs: Long): String = when (type) {
        AutofillFieldType.USERNAME -> e.username.ifEmpty { e.email.ifEmpty { e.mobile } }
        AutofillFieldType.PASSWORD -> e.password
        AutofillFieldType.PIN -> e.appPin
        AutofillFieldType.OTP -> otpFor(e, nowMs)
        AutofillFieldType.NEW_PASSWORD -> ""   // an existing password is never put into a "new password" field
    }

    fun otpFor(e: VaultEntry, nowMs: Long): String {
        if (e.totp.isBlank()) return ""
        val cfg = Totp.parse(e.totp) ?: return ""
        val current = Totp.current(e.totp, nowMs) ?: return ""
        val at = if (current.secondsRemaining <= OTP_EDGE_SECONDS) nowMs + current.secondsRemaining * 1000L else nowMs
        return Totp.generate(cfg, at).orEmpty()
    }
}
