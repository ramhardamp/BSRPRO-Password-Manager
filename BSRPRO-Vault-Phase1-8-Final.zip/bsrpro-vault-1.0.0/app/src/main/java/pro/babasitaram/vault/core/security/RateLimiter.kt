package pro.babasitaram.vault.core.security

import pro.babasitaram.vault.core.util.VaultError
import androidx.compose.runtime.*

data class LockoutState(val failedAttempts: Int = 0, val lockedUntilMs: Long = 0L)

interface LockoutStore {
    suspend fun load(): LockoutState
    suspend fun save(state: LockoutState)
}

/** 5 wrong master-password attempts → 30 s lockout. State is persisted so restarting the app does not reset it. */
class RateLimiter(
    private val store: LockoutStore,
    private val clock: () -> Long = System::currentTimeMillis,
    private val maxAttempts: Int = 5,
    private val lockoutMs: Long = 30_000L
) {
    suspend fun check() {
        val s = store.load()
        val remaining = s.lockedUntilMs - clock()
        if (remaining > 0) throw VaultError.RateLimited(remaining)
    }

    suspend fun recordFailure(): LockoutState {
        val s = store.load()
        val failed = s.failedAttempts + 1
        val next = if (failed >= maxAttempts) LockoutState(0, clock() + lockoutMs) else LockoutState(failed, 0)
        store.save(next)
        return next
    }

    suspend fun recordSuccess() = store.save(LockoutState())

    suspend fun state(): LockoutState = store.load()

    fun remainingAttempts(state: LockoutState): Int =
        if (state.lockedUntilMs > clock()) 0 else (maxAttempts - state.failedAttempts).coerceAtLeast(0)
}
