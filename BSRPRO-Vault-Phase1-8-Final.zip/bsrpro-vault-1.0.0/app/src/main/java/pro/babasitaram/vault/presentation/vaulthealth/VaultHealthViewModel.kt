// file: app/src/main/java/pro/babasitaram/vault/presentation/vaulthealth/VaultHealthViewModel.kt
package pro.babasitaram.vault.presentation.vaulthealth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.domain.repository.VaultRepository

data class VaultHealthState(
    val total: Int = 0,
    val weakPasswords: List<VaultEntry> = emptyList(),
    val reusedPasswords: List<VaultEntry> = emptyList(),
    val duplicateLogins: List<VaultEntry> = emptyList(),
    val missingUsernames: List<VaultEntry> = emptyList(),
    val oldPasswords: List<VaultEntry> = emptyList()
)

@HiltViewModel
class VaultHealthViewModel @Inject constructor(
    repository: VaultRepository
) : ViewModel() {
    val state: StateFlow<VaultHealthState> = repository.entries
        .map { values ->
            val entries = values.filter { it.deletedAt == 0L }
            val ageCutoff = System.currentTimeMillis() - 90L * 24L * 60L * 60L * 1000L
            val passwordGroups = entries.filter { it.password.isNotBlank() }.groupBy { it.password }
            val reused = passwordGroups.values.filter { it.size > 1 }.flatten().distinctBy { it.id }
            val loginGroups = entries.mapNotNull { e ->
                val domain = UrlUtils.domainOf(e.url)
                if (e.username.isBlank() || domain.isBlank()) null else e to "${domain.lowercase()}|${e.username.lowercase()}"
            }.groupBy({ it.second }, { it.first })
            val duplicate = loginGroups.values.filter { it.size > 1 }.flatten().distinctBy { it.id }
            VaultHealthState(
                total = entries.size,
                weakPasswords = entries.filter { it.password.isNotBlank() && PasswordStrength.score(it.password) <= 2 },
                reusedPasswords = reused,
                duplicateLogins = duplicate,
                missingUsernames = entries.filter { it.username.isBlank() && it.recordType.equals("login", true) },
                oldPasswords = entries.filter {
                    it.password.isNotBlank() &&
                        (it.updatedAt > 0L && it.updatedAt < ageCutoff) &&
                        it.recordType.equals("login", true)
                }
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultHealthState())
}
