package pro.babasitaram.vault.core.security

import android.net.Uri
import java.security.SecureRandom
import java.util.Base64
import kotlinx.serialization.json.Json
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultEntry

/** Self-contained, 10-minute encrypted share link. The key remains in the URI fragment. */
object SecureShareManager {
    const val SCHEME = "bsrpro"
    const val HOST = "share"
    const val TTL_MS = 10L * 60L * 1000L

    suspend fun create(entry: VaultEntry, now: Long = System.currentTimeMillis()): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
        val random = SecureRandom()
        val key = buildString(32) { repeat(32) { append(alphabet[random.nextInt(alphabet.length)]) } }
        val payload = Json.encodeToString(VaultEntry.serializer(), entry)
        val ciphertext = VaultCrypto.encrypt(payload, key.toCharArray())
        val urlSafeCiphertext = ciphertext.replace('+', '-').replace('/', '_').trimEnd('=')
        val expiry = now + TTL_MS
        return Uri.Builder()
            .scheme(SCHEME)
            .authority(HOST)
            .fragment("$urlSafeCiphertext.$key.$expiry")
            .build()
            .toString()
    }

    fun decodeCiphertext(value: String): String {
        val normalized = value.replace('-', '+').replace('_', '/') + "=".repeat((4 - value.length % 4) % 4)
        return normalized
    }
}
