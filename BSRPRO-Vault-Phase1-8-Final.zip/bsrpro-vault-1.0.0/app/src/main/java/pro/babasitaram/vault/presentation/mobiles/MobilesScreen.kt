// file: app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesScreen.kt
package pro.babasitaram.vault.presentation.mobiles
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState

@Composable
fun MobilesScreen(onBack: () -> Unit = {}, vm: MobilesViewModel = hiltViewModel()) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    Scaffold(topBar = { TopAppBar(title = { Text("Mobiles") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } }) }) { padding ->
        if (entries.isEmpty()) {
            EmptyState("No mobile entries", "Entries containing mobile or phone numbers will appear here.", Modifier.padding(padding).fillMaxWidth())
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(entries, key = { it.id }) { entry -> MobileItem(entry) }
            }
        }
    }
}

@Composable
private fun MobileItem(entry: VaultEntry) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(entry.title.ifBlank { entry.fullName.ifBlank { "Mobile entry" } }, style = MaterialTheme.typography.titleMedium)
            val number = entry.mobile.ifBlank { entry.phone }
            if (number.isNotBlank()) Text(number)
        }
    }
}
