// file: app/src/main/java/pro/babasitaram/vault/presentation/totpmanager/TotpManagerScreen.kt
package pro.babasitaram.vault.presentation.totpmanager
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.presentation.components.EmptyState

@Composable
fun TotpManagerScreen(
    onBack: () -> Unit = {},
    vm: TotpManagerViewModel = hiltViewModel()
) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1_000L)
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TOTP Manager") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState("No TOTP entries", "Add an authenticator secret to an entry to see live codes.", Modifier.padding(padding).fillMaxWidth())
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(entries, key = { it.id }) { entry -> TotpItem(entry, now) }
            }
        }
    }
}

@Composable
private fun TotpItem(entry: VaultEntry, now: Long) {
    val result = Totp.current(entry.totp, now)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(entry.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium)
            if (entry.username.isNotBlank()) Text(entry.username, style = MaterialTheme.typography.bodyMedium)
            if (result == null) {
                Text("Invalid authenticator secret", color = MaterialTheme.colorScheme.error)
            } else {
                Text(result.code, style = MaterialTheme.typography.headlineMedium)
                Text("Expires in ${result.secondsRemaining}s")
            }
        }
    }
}
