// file: app/src/main/java/pro/babasitaram/vault/presentation/vaulthealth/VaultHealthScreen.kt
package pro.babasitaram.vault.presentation.vaulthealth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState

@Composable
fun VaultHealthScreen(onBack: () -> Unit = {}, vm: VaultHealthViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    Scaffold(topBar = { TopAppBar(title = { Text("Vault Health") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } }) }) { padding ->
        if (state.total == 0) {
            EmptyState("No vault entries", "Health checks appear after you add or import entries.", Modifier.padding(padding).fillMaxWidth())
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { SummaryCard(state) }
                if (state.weakPasswords.isNotEmpty()) item { IssueCard("Weak passwords", state.weakPasswords) }
                if (state.reusedPasswords.isNotEmpty()) item { IssueCard("Duplicate/reused passwords", state.reusedPasswords) }
                if (state.duplicateLogins.isNotEmpty()) item { IssueCard("Duplicate logins", state.duplicateLogins) }
                if (state.oldPasswords.isNotEmpty()) item { IssueCard("Passwords 90+ days old", state.oldPasswords) }
                if (state.missingUsernames.isNotEmpty()) item { IssueCard("Logins without usernames", state.missingUsernames) }
                if (state.weakPasswords.isEmpty() && state.reusedPasswords.isEmpty() && state.duplicateLogins.isEmpty() && state.missingUsernames.isEmpty() && state.oldPasswords.isEmpty()) {
                    item { Card(Modifier.fillMaxWidth()) { Text("No current health findings", modifier = Modifier.padding(18.dp)) } }
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(state: VaultHealthState) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Vault summary", style = MaterialTheme.typography.titleMedium)
            Text("Entries: ${state.total}")
            Text("Weak: ${state.weakPasswords.size}  •  Reused: ${state.reusedPasswords.size}")
            Text("Duplicates: ${state.duplicateLogins.size}  •  Missing usernames: ${state.missingUsernames.size}")
            Text("Passwords 90+ days old: ${state.oldPasswords.size}")
        }
    }
}

@Composable
private fun IssueCard(title: String, entries: List<VaultEntry>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            entries.take(20).forEach { Text(it.title.ifBlank { "Untitled" }) }
            if (entries.size > 20) Text("+${entries.size - 20} more")
        }
    }
}
