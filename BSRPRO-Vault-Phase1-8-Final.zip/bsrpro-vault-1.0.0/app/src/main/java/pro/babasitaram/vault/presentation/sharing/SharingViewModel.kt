package pro.babasitaram.vault.presentation.sharing

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.SecureShareManager
import pro.babasitaram.vault.domain.repository.VaultRepository

@HiltViewModel
class SharingViewModel @Inject constructor(
    repository: VaultRepository
) : ViewModel() {
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { list -> list.filter { it.deletedAt == 0L && !it.isFolderMarker } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    suspend fun createLink(entry: VaultEntry): String =
        SecureShareManager.create(entry)
}
