package pro.babasitaram.vault.data.repository

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.data.local.db.toEntity
import pro.babasitaram.vault.data.local.db.toMetadata
import pro.babasitaram.vault.domain.repository.VaultRepository

class VaultRepositoryImpl(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val dao: VaultDao
) : VaultRepository {

    private val mutex = Mutex()
    private var all: List<VaultEntry> = emptyList()
    private var allFolders: List<Folder> = emptyList()

    private val _entries = MutableStateFlow<List<VaultEntry>>(emptyList())
    private val _folders = MutableStateFlow<List<Folder>>(emptyList())
    private val _trashedEntries = MutableStateFlow<List<VaultEntry>>(emptyList())
    override val entries: StateFlow<List<VaultEntry>> = _entries.asStateFlow()
    override val folders: StateFlow<List<Folder>> = _folders.asStateFlow()
    override val trashedEntries: StateFlow<List<VaultEntry>> = _trashedEntries.asStateFlow()

    override fun entry(id: String): VaultEntry? = _entries.value.firstOrNull { it.id == id }

    override fun findDuplicate(candidate: VaultEntry): VaultEntry? {
        val domain = UrlUtils.domainOf(candidate.url)
        if (candidate.username.isBlank() || (domain.isEmpty() && candidate.appPackage.isEmpty())) return null
        return _entries.value.firstOrNull {
            it.id != candidate.id &&
                it.username.equals(candidate.username, ignoreCase = true) &&
                (
                    (domain.isNotEmpty() && UrlUtils.domainOf(it.url) == domain) ||
                        (candidate.appPackage.isNotEmpty() && it.appPackage == candidate.appPackage)
                    )
        }
    }

    override suspend fun setData(data: VaultData) = mutex.withLock {
        publish(data.entries, data.folders)
    }

    override suspend fun upsert(entry: VaultEntry) = mutex.withLock {
        val idx = all.indexOfFirst { it.id == entry.id }
        val next = if (idx >= 0) all.toMutableList().also { it[idx] = entry } else all + entry
        persist(next, allFolders)       // write first: memory only changes if the disk write succeeded
        publish(next, allFolders)
    }

    override suspend fun upsertAll(entries: List<VaultEntry>, folders: List<Folder>) = mutex.withLock {
        if (entries.isEmpty() && folders.isEmpty()) return@withLock
        val merged = LinkedHashMap<String, VaultEntry>()
        all.forEach { merged[it.id] = it }
        entries.forEach { merged[it.id] = it }
        val nextFolders = allFolders + folders.filter { f -> allFolders.none { it.id == f.id } }
        val next = merged.values.toList()
        persist(next, nextFolders)
        publish(next, nextFolders)
    }

    override suspend fun softDelete(id: String) = mutex.withLock {
        val now = System.currentTimeMillis()
        val idx = all.indexOfFirst { it.id == id && it.deletedAt == 0L }
        if (idx < 0) return@withLock
        val next = all.toMutableList().also { it[idx] = it[idx].copy(deletedAt = now, updatedAt = now) }
        persist(next, allFolders)
        publish(next, allFolders)
    }

    override suspend fun restore(id: String) = mutex.withLock {
        val idx = all.indexOfFirst { it.id == id && it.deletedAt > 0L }
        if (idx < 0) return@withLock
        val next = all.toMutableList().also { it[idx] = it[idx].copy(deletedAt = 0L, updatedAt = System.currentTimeMillis()) }
        persist(next, allFolders)
        publish(next, allFolders)
    }

    override suspend fun emptyTrash() = mutex.withLock {
        val next = all.filterNot { it.deletedAt > 0L }
        if (next.size == all.size) return@withLock
        persist(next, allFolders)
        publish(next, allFolders)
    }

    override suspend fun cleanupExpiredTrash(now: Long, retentionMs: Long) = mutex.withLock {
        val cutoff = now - retentionMs
        val next = all.filterNot { it.deletedAt > 0L && it.deletedAt <= cutoff }
        if (next.size == all.size) return@withLock
        persist(next, allFolders)
        publish(next, allFolders)
    }

    override suspend fun clear() = mutex.withLock {
        all = emptyList()
        allFolders = emptyList()
        _entries.value = emptyList()
        _folders.value = emptyList()
        _trashedEntries.value = emptyList()
        dao.wipe()
    }

    private suspend fun persist(entries: List<VaultEntry>, folders: List<Folder>) {
        session.withPassword { pw -> blobStore.write(VaultData(entries, folders), pw) }
    }

    private suspend fun publish(entries: List<VaultEntry>, folders: List<Folder>) {
        all = entries
        allFolders = folders
        val visible = entries.filterNot { it.isFolderMarker || it.deletedAt > 0L }
        val trashed = entries.filterNot { it.isFolderMarker }.filter { it.deletedAt > 0L }
        _entries.value = visible
        _folders.value = folders
        _trashedEntries.value = trashed
        dao.replaceAll(visible.map { it.toMetadata() }, folders.map { it.toEntity() })
    }
}
