package pro.babasitaram.vault.presentation.setup

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.usecase.CreateVaultUseCase
import pro.babasitaram.vault.domain.usecase.RestoreBackupUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage

import androidx.compose.foundation.layout.*

data class SetupUiState(
    val busy: Boolean = false,
    val error: String? = null,
    val awaitingBackupPassword: Boolean = false
)

@HiltViewModel
class SetupViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val createVault: CreateVaultUseCase,
    private val restoreBackup: RestoreBackupUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(SetupUiState())
    val state: StateFlow<SetupUiState> = _state.asStateFlow()

    private var pendingBackup: String? = null

    fun create(password: String, confirm: String) {
        val pw = password.toCharArray()
        val cf = confirm.toCharArray()
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = null) }
            val r = createVault(pw, cf)
            pw.fill('\u0000')
            cf.fill('\u0000')
            _state.update { it.copy(busy = false, error = (r as? VaultResult.Failure)?.error?.toUserMessage()) }
            // On success the session unlocks and RootViewModel switches to the vault screens.
        }
    }

    fun onBackupPicked(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = null) }
            val text = try {
                withContext(Dispatchers.IO) {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw java.io.IOException("Cannot open file")
                    require(bytes.size <= MAX_BACKUP_BYTES) { "File too large" }
                    String(bytes, Charsets.UTF_8)
                }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, error = "Could not read the selected file") }
                return@launch
            }
            pendingBackup = text
            _state.update { it.copy(busy = false, awaitingBackupPassword = true) }
        }
    }

    fun restore(backupPassword: String) {
        val text = pendingBackup ?: return
        val pw = backupPassword.toCharArray()
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = null) }
            val r = restoreBackup(text, pw)
            pw.fill('\u0000')
            if (r is VaultResult.Failure) {
                _state.update { it.copy(busy = false, error = r.error.toUserMessage(), awaitingBackupPassword = false) }
            } else {
                pendingBackup = null
                _state.update { it.copy(busy = false, awaitingBackupPassword = false) }
            }
        }
    }

    fun cancelRestore() {
        pendingBackup = null
        _state.update { it.copy(awaitingBackupPassword = false) }
    }

    private companion object {
        const val MAX_BACKUP_BYTES = 50_000_000
    }
}
