package pro.babasitaram.vault.presentation.vault

import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAvailability
import pro.babasitaram.vault.core.util.EntrySearch
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.GetEntriesUseCase
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions

import androidx.compose.foundation.layout.*

enum class ListFilter(val label: String) { ALL("All"), STRONG("Strong"), WEAK("Weak"), STARRED("Starred") }

val CATEGORIES = listOf("work", "personal", "banking", "social", "other")

data class VaultListUiState(
    val entries: List<VaultEntry> = emptyList(),
    val totalCount: Int = 0,
    val query: String = "",
    val category: String? = null,
    val filter: ListFilter = ListFilter.ALL,
    val grouped: Boolean = false,
    val biometricEnabled: Boolean = false
)

fun VaultEntry.strengthBucket(): String = strength.ifBlank { PasswordStrength.bucket(password) }

@OptIn(FlowPreview::class)
@HiltViewModel
class VaultListViewModel @Inject constructor(
    getEntries: GetEntriesUseCase,
    private val settings: SettingsRepository,
    private val auth: AuthRepository,
    private val session: SessionKeyStore,
    private val biometric: BiometricAuthenticator,
    private val lockVault: LockVaultUseCase,
    private val clipboard: ClipboardActions
) : ViewModel() {

    private val query = MutableStateFlow("")
    private val category = MutableStateFlow<String?>(null)
    private val filter = MutableStateFlow(ListFilter.ALL)
    private val grouped = MutableStateFlow(false)
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    private val debouncedQuery = query.debounce { if (it.isEmpty()) 0L else 200L }

    private val visible = combine(getEntries(), debouncedQuery, category, filter) { entries, q, c, f ->
        val base = entries.filter { e ->
            (c == null || e.category.equals(c, ignoreCase = true)) &&
                when (f) {
                    ListFilter.ALL -> true
                    ListFilter.STRONG -> e.strengthBucket() == "strong"
                    ListFilter.WEAK -> e.strengthBucket() == "weak"
                    ListFilter.STARRED -> e.starred
                }
        }
        if (q.isBlank()) base.sortedBy { it.title.lowercase() } else EntrySearch.filter(base, q)
    }

    private val core = combine(visible, getEntries(), query, category, filter) { shown, all, q, c, f ->
        VaultListUiState(entries = shown, totalCount = all.size, query = q, category = c, filter = f)
    }

    val state: StateFlow<VaultListUiState> = combine(core, grouped, settings.settings) { s, g, cfg ->
        s.copy(grouped = g, biometricEnabled = cfg.biometricEnabled)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultListUiState())

    fun setQuery(value: String) { query.value = value }
    fun setCategory(value: String?) { category.value = if (category.value == value) null else value }
    fun setFilter(value: ListFilter) { filter.value = value }
    fun toggleGrouped() { grouped.value = !grouped.value }

    fun copyPassword(entry: VaultEntry) {
        viewModelScope.launch { _messages.send(clipboard.copy(entry.password, "Password")) }
    }

    fun lock() {
        viewModelScope.launch { lockVault() }
    }

    fun toggleBiometric(activity: FragmentActivity) {
        viewModelScope.launch {
            if (settings.current().biometricEnabled) {
                auth.clearBiometricCredential()
                settings.update { it.copy(biometricEnabled = false) }
                _messages.send("Biometric unlock disabled")
                return@launch
            }
            if (biometric.availability() != BiometricAvailability.Available) {
                _messages.send("Set up a fingerprint or screen lock in Android settings first")
                return@launch
            }
            biometric.authenticate(activity, "Enable biometric unlock", "Confirm it's you").collect { result ->
                if (result is AuthResult.Success) {
                    session.withPassword { auth.saveBiometricCredential(it) }
                    settings.update { it.copy(biometricEnabled = true) }
                    _messages.send("Biometric unlock enabled")
                }
            }
        }
    }
}
