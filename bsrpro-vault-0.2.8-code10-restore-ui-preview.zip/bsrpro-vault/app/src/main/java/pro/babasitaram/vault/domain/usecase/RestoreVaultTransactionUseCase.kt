package pro.babasitaram.vault.domain.usecase

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import javax.inject.Inject
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.model.VaultPayload
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.domain.repository.VaultRepository

/** In-place V3 restore. Marker is diagnostic for M1.B startup recovery; this class never auto-clears it on launch. */
class RestoreVaultTransactionUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val repository: VaultRepository,
    @ApplicationContext context: Context
) {
    private val marker = File(context.filesDir, "vault-restore.transaction")
    private val snapshot = File(context.filesDir, "vault-restore.snapshot")
    private val mutex = Mutex()

    suspend operator fun invoke(containerJson: String, currentPassword: CharArray): VaultResult<Int> = mutex.withLock {
        vaultCatching {
            // First authenticate against the currently installed vault. This must not mutate it.
            val oldData = blobStore.read(currentPassword)
            val oldRaw = blobStore.readRaw() ?: throw VaultError.VaultNotFound

            val plaintext = VaultCrypto.decryptV3(containerJson, currentPassword)
            val parsed = V3PayloadParser.parse(plaintext)
            val incoming = VaultData(parsed.entries, parsed.folders)
            // Normalize supported V3 schemas to the app's canonical payload before digest comparison.
            // The read-back digest below proves the persisted data matches the validated decrypted payload.
            val expectedDigest = digest(canonical(incoming))

            writeSynced(snapshot, oldRaw)
            writeSynced(marker, "PREPARED\n${snapshot.name}\n${System.currentTimeMillis()}")
            try {
                blobStore.write(incoming, currentPassword)
                val restored = blobStore.read(currentPassword)
                val actualDigest = digest(canonical(restored))
                if (!MessageDigest.isEqual(expectedDigest, actualDigest)) {
                    throw VaultError.InvalidFormat("Restored vault round-trip mismatch")
                }
                repository.setData(restored)
                marker.delete()
                snapshot.delete()
                restored.entries.count { !it.isFolderMarker }
            } catch (failure: Exception) {
                try {
                    blobStore.writeRaw(oldRaw)
                    val recovered = blobStore.read(currentPassword)
                    if (recovered != oldData) throw IllegalStateException("Rollback verification mismatch")
                    repository.setData(recovered)
                    marker.delete()
                    snapshot.delete()
                } catch (rollbackFailure: Exception) {
                    // Keep marker + snapshot for explicit recovery in M1.B; never delete evidence.
                    throw VaultError.IOError(IllegalStateException("Restore failed and rollback needs recovery", rollbackFailure))
                }
                throw failure
            }
        }
    }

    private fun canonical(data: VaultData): String = VaultJson.encodeToString(
        VaultPayload.serializer(), VaultPayload(entries = data.entries, folders = data.folders)
    )

    private fun digest(text: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))

    private fun writeSynced(file: File, text: String) {
        file.parentFile?.mkdirs()
        FileOutputStream(file).use { out ->
            out.write(text.toByteArray(Charsets.UTF_8)); out.flush(); out.fd.sync()
        }
    }
}
