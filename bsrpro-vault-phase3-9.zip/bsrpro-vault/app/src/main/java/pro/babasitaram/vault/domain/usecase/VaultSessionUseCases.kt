package pro.babasitaram.vault.domain.usecase

import javax.inject.Inject
import kotlinx.coroutines.flow.StateFlow
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.VaultClipboardManager
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.VaultRepository

class CreateVaultUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val repository: VaultRepository,
    private val auth: AuthRepository
) {
    suspend operator fun invoke(
        password: CharArray,
        confirm: CharArray,
        initial: VaultData = VaultData(),
        enforceStrength: Boolean = true
    ): VaultResult<Unit> = vaultCatching {
        if (auth.vaultExists()) throw VaultError.Validation("A vault already exists on this device")
        if (!password.contentEquals(confirm)) throw VaultError.Validation("Passwords do not match")
        if (enforceStrength && !PasswordStrength.isAcceptableMaster(java.nio.CharBuffer.wrap(password))) {
            throw VaultError.Validation("Use at least 12 characters with upper & lower case letters, digits or symbols")
        }
        if (password.isEmpty()) throw VaultError.Validation("Password must not be empty")
        blobStore.write(initial, password)
        session.unlock(password)
        repository.setData(initial)
        auth.recordSuccess()
    }
}

class UnlockVaultUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val repository: VaultRepository,
    private val auth: AuthRepository
) {
    /** The caller owns [password] and must wipe it afterwards. */
    suspend operator fun invoke(password: CharArray): VaultResult<Unit> = vaultCatching {
        auth.checkAllowed()
        if (!auth.vaultExists()) throw VaultError.VaultNotFound
        val data = try {
            blobStore.read(password)
        } catch (e: VaultError.InvalidMasterPassword) {
            auth.recordFailure()
            throw e
        }
        session.unlock(password)
        repository.setData(data)
        auth.recordSuccess()
    }
}

class LockVaultUseCase @Inject constructor(
    private val session: SessionKeyStore,
    private val blobStore: VaultBlobStore,
    private val repository: VaultRepository,
    private val clipboard: VaultClipboardManager
) {
    suspend operator fun invoke() {
        session.lock()
        blobStore.invalidateKeyCache()
        clipboard.clearNow()
        repository.clear()
    }
}

/** Creates a fresh vault from a BSRPRO.Vault backup (V3 container). The backup password becomes the master password. */
class RestoreBackupUseCase @Inject constructor(private val createVault: CreateVaultUseCase) {
    suspend operator fun invoke(containerJson: String, backupPassword: CharArray): VaultResult<Int> {
        val data = try {
            val plain = VaultCrypto.decryptV3(containerJson, backupPassword)
            val parsed = V3PayloadParser.parse(plain)
            VaultData(parsed.entries, parsed.folders)
        } catch (e: VaultError) {
            return VaultResult.Failure(e)
        }
        return when (val r = createVault(backupPassword, backupPassword, data, enforceStrength = false)) {
            is VaultResult.Success -> VaultResult.Success(data.entries.count { !it.isFolderMarker })
            is VaultResult.Failure -> VaultResult.Failure(r.error)
            is VaultResult.Loading -> VaultResult.Loading
        }
    }
}

class GetEntriesUseCase @Inject constructor(private val repository: VaultRepository) {
    operator fun invoke(): StateFlow<List<VaultEntry>> = repository.entries
}

class DeleteEntryUseCase @Inject constructor(private val repository: VaultRepository) {
    suspend operator fun invoke(id: String): VaultResult<Unit> = vaultCatching { repository.delete(id) }
}

class SaveEntryUseCase @Inject constructor(private val repository: VaultRepository) {
    /** [existing] is the stored version when editing (null for a new entry). */
    suspend operator fun invoke(
        entry: VaultEntry,
        existing: VaultEntry? = null,
        now: Long = System.currentTimeMillis()
    ): VaultResult<VaultEntry> = vaultCatching {
        var e = entry.copy(
            id = entry.id.ifBlank { pro.babasitaram.vault.core.util.IdGenerator.newId(now) },
            createdAt = existing?.createdAt?.takeIf { it > 0 } ?: now,
            updatedAt = now,
            strength = if (entry.password.isEmpty()) "" else PasswordStrength.bucket(entry.password)
        )
        if (existing != null) {
            val changedPassword = existing.password.isNotEmpty() && existing.password != e.password
            val history = if (changedPassword) {
                (listOf(pro.babasitaram.vault.core.model.PasswordHistoryItem(existing.password, now)) + existing.passwordHistory).take(20)
            } else existing.passwordHistory
            val changed = changedFields(existing, e)
            val edits = if (changed.isEmpty()) existing.editHistory else
                (listOf(pro.babasitaram.vault.core.model.EditHistoryItem(now, changed, "android")) + existing.editHistory).take(50)
            e = e.copy(passwordHistory = history, editHistory = edits)
        }
        repository.upsert(e)
        e
    }

    private fun changedFields(a: VaultEntry, b: VaultEntry): List<String> = buildList {
        if (a.title != b.title) add("title")
        if (a.url != b.url) add("url")
        if (a.username != b.username) add("username")
        if (a.password != b.password) add("password")
        if (a.notes != b.notes) add("notes")
        if (a.totp != b.totp) add("totp")
        if (a.category != b.category) add("category")
        if (a.tags != b.tags) add("tags")
    }
}
