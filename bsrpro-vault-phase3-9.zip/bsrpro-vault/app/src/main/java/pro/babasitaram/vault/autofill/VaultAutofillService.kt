package pro.babasitaram.vault.autofill

import android.content.Intent
import android.os.Build
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveRequest
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import pro.babasitaram.vault.MainActivity
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.autofill.model.ParsedStructure
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import timber.log.Timber

/**
 * System autofill provider.
 *  - unlocked vault: datasets for entries whose domain / package matches
 *  - locked vault: one "Unlock" entry that opens [AutofillAuthActivity]
 *  - after a login form is submitted: the save flow ([onSaveRequest])
 * Nothing sensitive is ever logged.
 */
@AndroidEntryPoint
class VaultAutofillService : AutofillService() {

    @Inject lateinit var session: SessionKeyStore
    @Inject lateinit var repository: VaultRepository
    @Inject lateinit var settings: SettingsRepository
    @Inject lateinit var auth: AuthRepository
    @Inject lateinit var factory: AutofillDatasetFactory
    @Inject lateinit var pendingSaves: PendingSaveStore

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onFillRequest(request: FillRequest, cancellationSignal: CancellationSignal, callback: FillCallback) {
        val parsed = request.fillContexts.lastOrNull()?.structure?.let { AutofillParser.parse(it) }
        if (parsed == null || !parsed.isFillable || parsed.packageName == packageName) {
            callback.onSuccess(null)
            return
        }
        // never offer credentials to a page that is not served over TLS
        if (parsed.webScheme.equals("http", ignoreCase = true)) {
            callback.onSuccess(null)
            return
        }
        val work = scope.launch {
            val response = try {
                buildResponse(parsed, request)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Timber.w("autofill fill request failed: %s", e.javaClass.simpleName)
                null
            }
            callback.onSuccess(response)
        }
        cancellationSignal.setOnCancelListener { work.cancel() }
    }

    private suspend fun buildResponse(parsed: ParsedStructure, request: FillRequest): FillResponse? {
        val cfg = settings.current()
        val inline = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && cfg.autofillInline) request.inlineSuggestionsRequest else null

        if (!session.isUnlocked.value) {
            if (!auth.vaultExists()) return null
            return factory.lockedResponse(parsed, factory.authSender(parsed, inline), inline)
        }
        var matches = AutofillMatcher.match(repository.entries.value, parsed.packageName, parsed.webDomain)
        if (parsed.isOtpOnly) matches = matches.filter { it.entry.totp.isNotBlank() }
        return factory.unlockedResponse(parsed, matches, inline, System.currentTimeMillis())
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        val parsed = request.fillContexts.lastOrNull()?.structure?.let { AutofillParser.parse(it) }
        val pending = parsed?.let { toPending(it) }
        if (pending == null) {
            callback.onSuccess()
            return
        }
        pendingSaves.put(pending)
        // Try to open the app straight away; also post a notification in case the background launch is blocked.
        runCatching {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        SaveNotifier.post(this, pending)
        callback.onSuccess()
    }

    private fun toPending(parsed: ParsedStructure): PendingSave? {
        val password = parsed.fields.firstOrNull { it.type == AutofillFieldType.NEW_PASSWORD && !it.value.isNullOrEmpty() }?.value
            ?: parsed.fields.lastOrNull { it.type == AutofillFieldType.PASSWORD && !it.value.isNullOrEmpty() }?.value
            ?: return null
        val username = parsed.fields.firstOrNull { it.type == AutofillFieldType.USERNAME && !it.value.isNullOrEmpty() }?.value.orEmpty()
        return PendingSave(
            packageName = parsed.packageName,
            webDomain = parsed.webDomain,
            username = username,
            password = password,
            createdAt = System.currentTimeMillis()
        )
    }
}
