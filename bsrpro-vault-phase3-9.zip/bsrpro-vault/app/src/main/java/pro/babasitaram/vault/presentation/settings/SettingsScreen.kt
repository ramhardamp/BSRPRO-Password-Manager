package pro.babasitaram.vault.presentation.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import pro.babasitaram.vault.BuildConfig
import pro.babasitaram.vault.autofill.AutofillStatus
import pro.babasitaram.vault.core.model.AppIconColor
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.findFragmentActivity

private val AUTO_LOCK = listOf("Never" to VaultSettings.AUTO_LOCK_NEVER, "30 seconds" to 30, "1 minute" to 60, "5 minutes" to 300, "15 minutes" to 900)
private val CLIPBOARD = listOf("Never" to 0, "15 seconds" to 15, "30 seconds" to 30, "60 seconds" to 60)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenBackup: () -> Unit, vm: SettingsViewModel = hiltViewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    CollectMessages(vm.messages)

    var autofillOn by remember { mutableStateOf(AutofillStatus.isEnabled(context)) }
    LifecycleResumeEffect(Unit) {
        autofillOn = AutofillStatus.isEnabled(context)
        onPauseOrDispose { }
    }

    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())) {
            Section("Security")
            ActionRow("Change master password", "Re-encrypts your vault. The old password stops working.") { dialog = SettingsDialog.ChangePassword }
            SwitchRow("Biometric unlock", "Unlock with fingerprint or face", s.biometricEnabled) {
                context.findFragmentActivity()?.let(vm::toggleBiometric)
            }
            ChoiceRow("Auto-lock timeout", AUTO_LOCK, s.autoLockSeconds, vm::setAutoLock)
            SwitchRow("Lock when app goes to background", null, s.lockOnBackground, vm::setLockOnBackground)
            ChoiceRow("Clipboard auto-clear", CLIPBOARD, s.clipboardClearSeconds, vm::setClipboardClear)

            Section("Autofill")
            ActionRow(
                "Autofill service",
                if (autofillOn) "BSRPRO Vault is your autofill service" else "Off — tap to choose BSRPRO Vault in Android settings"
            ) {
                val primary = AutofillStatus.enableIntent(context)
                runCatching { context.startActivity(primary) }.onFailure { runCatching { context.startActivity(AutofillStatus.fallbackIntent()) } }
            }
            SwitchRow("Show suggestions above the keyboard", "Inline suggestions (Android 11+)", s.autofillInline, vm::setAutofillInline)

            Section("Generator")
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("Default length: ${s.generatorDefaultLength}", style = MaterialTheme.typography.bodyLarge)
                Slider(
                    value = s.generatorDefaultLength.toFloat(),
                    onValueChange = { vm.setGeneratorLength(it.toInt()) },
                    valueRange = 8f..256f
                )
                OutlinedTextField(
                    value = s.generatorKeyword,
                    onValueChange = vm::setGeneratorKeyword,
                    label = { Text("Custom keyword / prefix") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            SwitchRow("Exclude similar characters", "Skips I, l, 1, O, 0, o", s.generatorExcludeSimilar, vm::setExcludeSimilar)

            Section("Appearance")
            ChoiceRow("Theme", ThemeMode.values().map { it.name.lowercase().replaceFirstChar(Char::uppercase) to it }, s.theme, vm::setTheme)
            ChoiceRow("App icon colour", AppIconColor.values().map { it.label to it }, s.appIcon, vm::setAppIcon)

            Section("Data")
            ActionRow("Export encrypted backup", "Also CSV and JSON exports") { onOpenBackup() }
            ActionRow("Import from backup", ".Vault files") { onOpenBackup() }
            ActionRow("Import from CSV", "Chrome, Bitwarden, LastPass, 1Password and more") { onOpenBackup() }
            ActionRow("Clear recent searches", null) { vm.clearRecentSearches() }
            ActionRow("Reset vault", "Deletes everything on this device", danger = true) { dialog = SettingsDialog.Reset }

            Section("About")
            ActionRow("Version", BuildConfig.VERSION_NAME) { }
            ActionRow("Changelog", null) { dialog = SettingsDialog.Changelog }
            ActionRow("Privacy policy", null) { dialog = SettingsDialog.Privacy }
            ActionRow("Open source licenses", null) { dialog = SettingsDialog.Licenses }
        }
    }

    when (dialog) {
        SettingsDialog.ChangePassword -> ChangePasswordDialog(
            onSubmit = { o, n, c -> vm.changeMasterPassword(o, n, c) },
            onDone = { dialog = null }
        )
        SettingsDialog.Reset -> ResetDialog(
            onSubmit = { pw -> vm.resetVault(pw) },
            onDone = { dialog = null }
        )
        SettingsDialog.Changelog -> InfoDialog("Changelog", CHANGELOG) { dialog = null }
        SettingsDialog.Privacy -> InfoDialog("Privacy policy", PRIVACY) { dialog = null }
        SettingsDialog.Licenses -> InfoDialog("Open source licenses", LICENSES) { dialog = null }
        null -> Unit
    }
}

private enum class SettingsDialog { ChangePassword, Reset, Changelog, Privacy, Licenses }

@Composable
private fun Section(title: String) {
    HorizontalDivider(Modifier.padding(top = 8.dp))
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp))
}

@Composable
private fun ActionRow(title: String, subtitle: String?, danger: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun <T> ChoiceRow(title: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.second == selected }?.first ?: "Custom"
    Column(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (name, value) ->
                DropdownMenuItem(text = { Text(name) }, onClick = { open = false; onSelect(value) })
            }
        }
    }
}

@Composable
private fun InfoDialog(title: String, body: String, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(body, style = MaterialTheme.typography.bodyMedium) } },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable
private fun ChangePasswordDialog(onSubmit: suspend (String, String, String) -> String?, onDone: () -> Unit) {
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDone() },
        title = { Text("Change master password") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PwField("Current password", old, !busy) { old = it }
                PwField("New password", new, !busy) { new = it }
                PwField("Confirm new password", confirm, !busy) { confirm = it }
                if (busy) Text("Re-encrypting… this takes a few seconds", style = MaterialTheme.typography.bodySmall)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && old.isNotEmpty() && new.isNotEmpty() && confirm.isNotEmpty(),
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val r = onSubmit(old, new, confirm)
                        busy = false
                        if (r == null) { old = ""; new = ""; confirm = ""; onDone() } else error = r
                    }
                }
            ) { Text("Change") }
        },
        dismissButton = { TextButton(onClick = onDone, enabled = !busy) { Text("Cancel") } }
    )
}

@Composable
private fun ResetDialog(onSubmit: suspend (String) -> String?, onDone: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDone() },
        title = { Text("Reset vault?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("This permanently deletes every password stored on this device. Export a backup first if you may need them. Enter your master password to confirm.")
                PwField("Master password", pw, !busy) { pw = it }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && pw.isNotEmpty(),
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val r = onSubmit(pw)
                        busy = false
                        if (r == null) { pw = ""; onDone() } else error = r
                    }
                }
            ) { Text("Delete everything", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = onDone, enabled = !busy) { Text("Cancel") } }
    )
}

@Composable
private fun PwField(label: String, value: String, enabled: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true, enabled = enabled,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
    )
}

private const val CHANGELOG = """0.2.0
• Autofill service with inline suggestions, biometric unlock and "save password" prompt
• Settings screen
• Encrypted .Vault backup, CSV / JSON export, import from Chrome, Bitwarden, LastPass, 1Password, Dashlane, KeePass, Firefox, generic CSV and vCard
• Daily auto-backup
• One-time codes (TOTP) with a live countdown, also offered by autofill

0.1.0
• Vault, lock screen, biometric unlock, generator, entry editor"""

private const val PRIVACY = """BSRPRO Vault keeps your passwords only on this device, encrypted with a key derived from your master password (PBKDF2-HMAC-SHA256, 600,000 iterations, AES-256-GCM).

The app has no internet permission: nothing is uploaded, no analytics, no ads, no crash reporting.

Your master password is never stored. If you turn on biometric unlock, it is kept wrapped by a key in the Android Keystore.

Backups and exports are written only where you choose (or to Downloads/BSRPRO_Backups if you enable auto-backup). Plain CSV / JSON exports are not encrypted, so keep them safe or delete them."""

private const val LICENSES = """Kotlin, kotlinx.coroutines, kotlinx.serialization — Apache License 2.0
AndroidX (Core, Activity, Lifecycle, Navigation, Room, DataStore, WorkManager, Biometric, Autofill, Security) and Jetpack Compose — Apache License 2.0
Dagger Hilt — Apache License 2.0
Google Tink — Apache License 2.0
ZXing core — Apache License 2.0
Coil — Apache License 2.0
Timber — Apache License 2.0"""
