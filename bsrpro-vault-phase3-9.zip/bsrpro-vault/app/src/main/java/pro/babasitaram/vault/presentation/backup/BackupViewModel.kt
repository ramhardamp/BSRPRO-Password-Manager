package pro.babasitaram.vault.presentation.backup

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.data.backup.UriIo
import pro.babasitaram.vault.data.transfer.DuplicateAction
import pro.babasitaram.vault.data.transfer.EntryExporter
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.data.transfer.ImportParser
import pro.babasitaram.vault.data.transfer.SourceKind
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.BuildExportUseCase
import pro.babasitaram.vault.domain.usecase.CommitImportUseCase
import pro.babasitaram.vault.domain.usecase.ImportPreview
import pro.babasitaram.vault.domain.usecase.PrepareImportUseCase
import pro.babasitaram.vault.domain.usecase.VerifyMasterPasswordUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage

sealed interface ImportStage {
    data object Idle : ImportStage
    data class NeedsBackupPassword(val text: String, val error: String? = null) : ImportStage
    data class Review(val preview: ImportPreview, val actions: Map<Int, DuplicateAction>) : ImportStage
}

data class BackupUiState(
    val busy: Boolean = false,
    val exportAsk: ExportFormat? = null,
    val exportError: String? = null,
    val importing: ImportStage = ImportStage.Idle,
    val autoBackupEnabled: Boolean = false,
    val lastAutoBackupAt: Long = 0L
)

sealed interface BackupEvent {
    data class Message(val text: String) : BackupEvent
    data class SaveFile(val fileName: String, val mime: String) : BackupEvent
}

@HiltViewModel
class BackupViewModel @Inject constructor(
    private val verify: VerifyMasterPasswordUseCase,
    private val buildExport: BuildExportUseCase,
    private val prepare: PrepareImportUseCase,
    private val commit: CommitImportUseCase,
    private val io: UriIo,
    private val settings: SettingsRepository,
    private val autoBackup: AutoBackupManager
) : ViewModel() {

    private val _state = MutableStateFlow(BackupUiState())
    val state: StateFlow<BackupUiState> = _state.asStateFlow()
    private val _events = Channel<BackupEvent>(Channel.BUFFERED)
    val events: Flow<BackupEvent> = _events.receiveAsFlow()

    /** Export text waiting for the user to pick where to save it. Dropped after writing / cancelling. */
    private var pendingExport: String? = null

    init {
        viewModelScope.launch {
            settings.settings.collect { s ->
                _state.update { it.copy(autoBackupEnabled = s.autoBackupEnabled, lastAutoBackupAt = s.lastAutoBackupAt) }
            }
        }
    }

    // ───────────────────────── export ─────────────────────────

    fun startExport(format: ExportFormat) = _state.update { it.copy(exportAsk = format, exportError = null) }

    fun cancelExport() {
        pendingExport = null
        _state.update { it.copy(exportAsk = null, exportError = null) }
    }

    /** Every export re-asks for the master password; the encrypted backup is encrypted with it. */
    fun confirmExport(password: String) {
        val format = _state.value.exportAsk ?: return
        val pw = password.toCharArray()
        viewModelScope.launch {
            _state.update { it.copy(busy = true, exportError = null) }
            try {
                val v = verify(pw)
                if (v is VaultResult.Failure) {
                    _state.update { it.copy(busy = false, exportError = v.error.toUserMessage()) }
                    return@launch
                }
                when (val r = buildExport(format)) {
                    is VaultResult.Success -> {
                        pendingExport = r.value
                        _state.update { it.copy(busy = false, exportAsk = null) }
                        val date = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                        _events.send(BackupEvent.SaveFile(EntryExporter.fileName(format, date), format.mime))
                    }
                    is VaultResult.Failure -> _state.update { it.copy(busy = false, exportError = r.error.toUserMessage()) }
                    VaultResult.Loading -> Unit
                }
            } finally {
                pw.fill('\u0000')
            }
        }
    }

    fun onExportTarget(uri: Uri?) {
        val text = pendingExport
        pendingExport = null
        if (uri == null || text == null) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            try {
                io.writeText(uri, text)
                _events.send(BackupEvent.Message("Export saved"))
            } catch (e: VaultError) {
                _events.send(BackupEvent.Message(e.toUserMessage()))
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    // ───────────────────────── import ─────────────────────────

    fun onImportFile(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            try {
                val text = io.readText(uri)
                when (ImportParser.detectKind(text)) {
                    SourceKind.V3_BACKUP, SourceKind.DEVICE_BACKUP ->
                        _state.update { it.copy(busy = false, importing = ImportStage.NeedsBackupPassword(text)) }
                    else -> runPrepare(text, null)
                }
            } catch (e: VaultError) {
                _state.update { it.copy(busy = false) }
                _events.send(BackupEvent.Message(e.toUserMessage()))
            }
        }
    }

    fun submitBackupPassword(password: String) {
        val stage = _state.value.importing as? ImportStage.NeedsBackupPassword ?: return
        val pw = password.toCharArray()
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            try {
                runPrepare(stage.text, pw)
            } finally {
                pw.fill('\u0000')
            }
        }
    }

    private suspend fun runPrepare(text: String, backupPassword: CharArray?) {
        when (val r = prepare(text, backupPassword)) {
            is VaultResult.Success -> {
                val defaults = r.value.items.withIndex().filter { it.value.duplicateOf != null }.associate { it.index to DuplicateAction.SKIP }
                _state.update { it.copy(busy = false, importing = ImportStage.Review(r.value, defaults)) }
            }
            is VaultResult.Failure -> {
                val msg = r.error.toUserMessage()
                val stage = _state.value.importing
                if (stage is ImportStage.NeedsBackupPassword || backupPassword != null) {
                    _state.update { it.copy(busy = false, importing = ImportStage.NeedsBackupPassword(text, msg)) }
                } else {
                    _state.update { it.copy(busy = false, importing = ImportStage.Idle) }
                    _events.send(BackupEvent.Message(msg))
                }
            }
            VaultResult.Loading -> Unit
        }
    }

    fun setAction(index: Int, action: DuplicateAction) = updateReview { it.copy(actions = it.actions + (index to action)) }

    fun setAllDuplicates(action: DuplicateAction) = updateReview { r ->
        r.copy(actions = r.preview.items.withIndex().filter { it.value.duplicateOf != null }.associate { it.index to action })
    }

    private fun updateReview(f: (ImportStage.Review) -> ImportStage.Review) = _state.update {
        val s = it.importing
        if (s is ImportStage.Review) it.copy(importing = f(s)) else it
    }

    fun cancelImport() = _state.update { it.copy(importing = ImportStage.Idle, busy = false) }

    fun confirmImport() {
        val s = _state.value.importing as? ImportStage.Review ?: return
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            when (val r = commit(s.preview, s.actions)) {
                is VaultResult.Success -> {
                    _state.update { it.copy(busy = false, importing = ImportStage.Idle) }
                    _events.send(BackupEvent.Message("Imported ${r.value} ${if (r.value == 1) "entry" else "entries"}"))
                }
                is VaultResult.Failure -> {
                    _state.update { it.copy(busy = false) }
                    _events.send(BackupEvent.Message(r.error.toUserMessage()))
                }
                VaultResult.Loading -> Unit
            }
        }
    }

    // ───────────────────────── auto-backup ─────────────────────────

    fun setAutoBackup(enabled: Boolean) {
        viewModelScope.launch {
            settings.update { it.copy(autoBackupEnabled = enabled) }
            if (enabled) {
                autoBackup.schedule()
                when (val r = autoBackup.backupNow()) {
                    is VaultResult.Success -> _events.send(BackupEvent.Message("Backup saved to ${r.value}"))
                    is VaultResult.Failure -> _events.send(BackupEvent.Message("Auto-backup is on, but the first backup failed"))
                    VaultResult.Loading -> Unit
                }
            } else autoBackup.cancel()
        }
    }

    fun backupNow() {
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val msg = when (val r = autoBackup.backupNow()) {
                is VaultResult.Success -> "Backup saved to ${r.value}"
                is VaultResult.Failure -> r.error.toUserMessage()
                VaultResult.Loading -> ""
            }
            _state.update { it.copy(busy = false) }
            if (msg.isNotEmpty()) _events.send(BackupEvent.Message(msg))
        }
    }
}
