package pro.babasitaram.vault.presentation.backup

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import pro.babasitaram.vault.data.transfer.DuplicateAction
import pro.babasitaram.vault.data.transfer.ExportFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(onBack: () -> Unit, vm: BackupViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var saveMime by remember { mutableStateOf("application/octet-stream") }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> vm.onImportFile(uri) }
    val exportTarget = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? -> vm.onExportTarget(uri) }

    LaunchedEffect(vm) {
        vm.events.collect { e ->
            when (e) {
                is BackupEvent.Message -> android.widget.Toast.makeText(context, e.text, android.widget.Toast.LENGTH_LONG).show()
                is BackupEvent.SaveFile -> { saveMime = e.mime; exportTarget.launch(e.fileName) }
            }
        }
    }

    val review = state.importing as? ImportStage.Review
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (review != null) "Review import" else "Backup & import") },
                navigationIcon = {
                    IconButton(onClick = { if (review != null) vm.cancelImport() else onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (state.busy) CircularProgressIndicator(Modifier.padding(16.dp).align(Alignment.CenterHorizontally))
            if (review != null) ReviewPane(review, vm) else MainPane(state, vm, onPick = { importPicker.launch(arrayOf("*/*")) })
        }
    }

    state.exportAsk?.let { format ->
        PasswordDialog(
            title = "Export — ${format.label}",
            message = if (format.plaintext) "This file is NOT encrypted. Anyone who gets it can read every password. Enter your master password to continue."
            else "Enter your master password. The backup will be encrypted with it.",
            confirmLabel = "Export",
            error = state.exportError,
            busy = state.busy,
            onConfirm = vm::confirmExport,
            onCancel = vm::cancelExport
        )
    }
    (state.importing as? ImportStage.NeedsBackupPassword)?.let { s ->
        PasswordDialog(
            title = "Backup password",
            message = "Enter the master password that was used when this backup was created.",
            confirmLabel = "Open",
            error = s.error,
            busy = state.busy,
            onConfirm = vm::submitBackupPassword,
            onCancel = vm::cancelImport
        )
    }
}

@Composable
private fun MainPane(state: BackupUiState, vm: BackupViewModel, onPick: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Export", style = MaterialTheme.typography.titleMedium)
                Text("The encrypted .Vault backup can be opened by the BSRPRO browser extension.", style = MaterialTheme.typography.bodySmall)
                Button(onClick = { vm.startExport(ExportFormat.V3) }, Modifier.fillMaxWidth(), enabled = !state.busy) { Text("Encrypted backup (.Vault)") }
                Text("Unencrypted formats", style = MaterialTheme.typography.labelLarge)
                listOf(ExportFormat.VAULT_CSV, ExportFormat.CHROME_CSV, ExportFormat.BITWARDEN_CSV, ExportFormat.PLAIN_JSON).forEach {
                    OutlinedButton(onClick = { vm.startExport(it) }, Modifier.fillMaxWidth(), enabled = !state.busy) { Text(it.label) }
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Import", style = MaterialTheme.typography.titleMedium)
                Text(
                    ".Vault backup, BSRPRO / Chrome / Edge / Bitwarden / LastPass / 1Password / Dashlane / KeePass / Firefox CSV, generic CSV, plain JSON or vCard. You review everything before it is added.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = onPick, Modifier.fillMaxWidth(), enabled = !state.busy) { Text("Choose a file…") }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Daily auto-backup", style = MaterialTheme.typography.titleMedium)
                        Text("Saves Downloads/BSRPRO_Backups/vault_YYYYMMDD.Vault", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = state.autoBackupEnabled, onCheckedChange = vm::setAutoBackup)
                }
                Text(
                    "Backups are encrypted with your master password, so they are written while the vault is unlocked; a missed day is caught up the next time you unlock.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (state.lastAutoBackupAt > 0) {
                    Text("Last backup: ${DateFormat.getDateTimeInstance().format(Date(state.lastAutoBackupAt))}", style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(onClick = vm::backupNow, enabled = !state.busy) { Text("Back up now") }
            }
        }
    }
}

@Composable
private fun ReviewPane(review: ImportStage.Review, vm: BackupViewModel) {
    val p = review.preview
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(p.format.label, style = MaterialTheme.typography.titleSmall)
            Text(
                "${p.newCount} new · ${p.duplicateCount} duplicate${if (p.duplicateCount == 1) "" else "s"}" +
                    if (p.skippedRows > 0) " · ${p.skippedRows} row(s) skipped" else "",
                style = MaterialTheme.typography.bodyMedium
            )
            if (p.duplicateCount > 0) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.SKIP) }) { Text("Skip all duplicates") }
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.REPLACE) }) { Text("Replace all") }
                }
            }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(p.items) { index, item ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(item.entry.title, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        listOf(item.entry.username.ifEmpty { item.entry.mobile }, item.entry.url).filter { it.isNotEmpty() }.joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (item.duplicateOf != null) {
                        val action = review.actions[index] ?: DuplicateAction.SKIP
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DuplicateAction.values().forEach { a ->
                                FilterChip(
                                    selected = action == a,
                                    onClick = { vm.setAction(index, a) },
                                    label = { Text(when (a) { DuplicateAction.SKIP -> "Skip"; DuplicateAction.REPLACE -> "Replace"; DuplicateAction.KEEP_BOTH -> "Keep both" }) }
                                )
                            }
                        }
                    } else {
                        Text("New", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                HorizontalDivider()
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::cancelImport, Modifier.weight(1f)) { Text("Cancel") }
            Button(onClick = vm::confirmImport, Modifier.weight(1f)) { Text("Import") }
        }
    }
}

@Composable
internal fun PasswordDialog(
    title: String,
    message: String,
    confirmLabel: String,
    error: String?,
    busy: Boolean,
    onConfirm: (String) -> Unit,
    onCancel: () -> Unit
) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { if (!busy) onCancel() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(message, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    value = pw, onValueChange = { pw = it }, singleLine = true, enabled = !busy,
                    label = { Text("Master password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(pw); pw = "" }, enabled = pw.isNotEmpty() && !busy) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onCancel, enabled = !busy) { Text("Cancel") } }
    )
}
