package pro.babasitaram.vault.autofill

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.os.Build
import android.service.autofill.Dataset
import android.service.autofill.FillResponse
import android.service.autofill.InlinePresentation
import android.service.autofill.SaveInfo
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.view.inputmethod.InlineSuggestionsRequest
import android.widget.RemoteViews
import android.widget.inline.InlinePresentationSpec
import androidx.annotation.RequiresApi
import androidx.autofill.inline.UiVersions
import androidx.autofill.inline.v1.InlineSuggestionUi
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton
import pro.babasitaram.vault.MainActivity
import pro.babasitaram.vault.R
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.autofill.model.ParsedStructure

/** Builds the datasets / responses the autofill framework shows to the user. */
@Singleton
class AutofillDatasetFactory @Inject constructor(@ApplicationContext private val context: Context) {

    private val requestCodes = AtomicInteger(1)

    /** Suggestions for the unlocked vault (+ save info so a new login can be saved afterwards). */
    @Suppress("DEPRECATION")
    fun unlockedResponse(
        parsed: ParsedStructure,
        matches: List<EntryMatch>,
        inlineRequest: InlineSuggestionsRequest?,
        nowMs: Long
    ): FillResponse? {
        val builder = FillResponse.Builder()
        val limit = inlineLimit(inlineRequest)
        var added = 0
        for (m in matches) {
            if (added >= limit) break
            val dataset = dataset(parsed, m, specAt(inlineRequest, added), nowMs) ?: continue
            builder.addDataset(dataset)
            added++
        }
        val save = saveInfo(parsed)
        if (save != null) builder.setSaveInfo(save)
        return if (added > 0 || save != null) builder.build() else null
    }

    /** Single "Unlock BSRPRO Vault" entry; the framework opens [authSender] when it is tapped. */
    @Suppress("DEPRECATION")
    fun lockedResponse(parsed: ParsedStructure, authSender: IntentSender, inlineRequest: InlineSuggestionsRequest?): FillResponse {
        val ids = parsed.fillableFields.map { it.id }.toTypedArray()
        val title = context.getString(R.string.autofill_unlock_title)
        val subtitle = context.getString(R.string.autofill_unlock_subtitle)
        val presentation = remoteViews(title, subtitle)
        val builder = FillResponse.Builder()
        val spec = specAt(inlineRequest, 0)
        val inline = if (spec != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) inlinePresentation(spec, title, subtitle) else null
        if (inline != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.setAuthentication(ids, authSender, presentation, inline)
        } else {
            builder.setAuthentication(ids, authSender, presentation)
        }
        return builder.build()
    }

    /** IntentSender that opens [AutofillAuthActivity]; the framework fills in the result extra, so the intent is mutable. */
    fun authSender(parsed: ParsedStructure, inlineRequest: InlineSuggestionsRequest?): IntentSender {
        val intent = Intent(context, AutofillAuthActivity::class.java).apply {
            putParcelableArrayListExtra(AutofillAuthActivity.EXTRA_IDS, ArrayList<AutofillId>(parsed.fields.map { it.id }))
            putExtra(AutofillAuthActivity.EXTRA_TYPES, parsed.fields.map { it.type.name }.toTypedArray())
            putExtra(AutofillAuthActivity.EXTRA_PACKAGE, parsed.packageName)
            putExtra(AutofillAuthActivity.EXTRA_DOMAIN, parsed.webDomain)
            putExtra(AutofillAuthActivity.EXTRA_SCHEME, parsed.webScheme)
            if (inlineRequest != null) putExtra(AutofillAuthActivity.EXTRA_INLINE, inlineRequest)
        }
        var flags = PendingIntent.FLAG_CANCEL_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) flags = flags or PendingIntent.FLAG_MUTABLE
        return PendingIntent.getActivity(context, requestCodes.getAndIncrement(), intent, flags).intentSender
    }

    // ───────────────────────── internals ─────────────────────────

    @Suppress("DEPRECATION")
    private fun dataset(parsed: ParsedStructure, m: EntryMatch, spec: InlinePresentationSpec?, nowMs: Long): Dataset? {
        val values = parsed.fields.mapNotNull { f ->
            AutofillValues.valueFor(f.type, m.entry, nowMs).takeIf { it.isNotEmpty() }?.let { f to it }
        }
        if (values.isEmpty()) return null
        val title = m.entry.title.ifBlank { m.entry.url.ifBlank { m.entry.appName } }.ifBlank { "BSRPRO" }
        val subtitle = subtitle(parsed, m)
        val builder = Dataset.Builder(remoteViews(title, subtitle))
        for ((f, v) in values) builder.setValue(f.id, AutofillValue.forText(v))
        if (spec != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            inlinePresentation(spec, title, subtitle)?.let { builder.setInlinePresentation(it) }
        }
        return builder.build()
    }

    private fun subtitle(parsed: ParsedStructure, m: EntryMatch): String {
        val base = if (parsed.isOtpOnly) context.getString(R.string.autofill_one_time_code)
        else m.entry.username.ifEmpty { m.entry.email.ifEmpty { m.entry.mobile } }
        return if (m.kind == MatchKind.RELATED) "\u26A0 ${context.getString(R.string.autofill_related_site)} \u2022 $base" else base
    }

    private fun remoteViews(title: String, subtitle: String?): RemoteViews =
        RemoteViews(context.packageName, R.layout.autofill_item).apply {
            setTextViewText(R.id.autofill_title, title)
            setTextViewText(R.id.autofill_subtitle, subtitle.orEmpty())
        }

    private fun saveInfo(parsed: ParsedStructure): SaveInfo? {
        val required = parsed.passwordFields.map { it.id }
        if (required.isEmpty()) return null
        val usernames = parsed.usernameFields.map { it.id }
        val type = if (usernames.isEmpty()) SaveInfo.SAVE_DATA_TYPE_PASSWORD
        else SaveInfo.SAVE_DATA_TYPE_PASSWORD or SaveInfo.SAVE_DATA_TYPE_USERNAME
        val b = SaveInfo.Builder(type, required.toTypedArray())
        if (usernames.isNotEmpty()) b.setOptionalIds(usernames.toTypedArray())
        b.setFlags(SaveInfo.FLAG_SAVE_ON_ALL_VIEWS_INVISIBLE)
        return b.build()
    }

    private fun inlineLimit(req: InlineSuggestionsRequest?): Int {
        if (req == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return MAX_DATASETS
        return req.maxSuggestionCount.coerceIn(1, MAX_DATASETS)
    }

    private fun specAt(req: InlineSuggestionsRequest?, index: Int): InlinePresentationSpec? {
        if (req == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val specs = req.inlinePresentationSpecs
        if (specs.isEmpty()) return null
        return specs[minOf(index, specs.lastIndex)]
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun inlinePresentation(spec: InlinePresentationSpec, title: String, subtitle: String?): InlinePresentation? {
        if (!UiVersions.getVersions(spec.style).contains(UiVersions.INLINE_UI_VERSION_1)) return null
        val attribution = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val content = InlineSuggestionUi.newContentBuilder(attribution)
            .setTitle(title)
            .apply { if (!subtitle.isNullOrEmpty()) setSubtitle(subtitle) }
            .build()
        return InlinePresentation(content.slice, spec, false)
    }

    companion object {
        const val MAX_DATASETS = 10
    }
}
