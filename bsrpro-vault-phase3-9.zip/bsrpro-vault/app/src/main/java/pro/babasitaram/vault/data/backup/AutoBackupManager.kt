package pro.babasitaram.vault.data.backup

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.data.transfer.EntryExporter
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.BuildExportUseCase
import timber.log.Timber

/**
 * Daily V3 backup to Downloads/BSRPRO_Backups/vault_YYYYMMDD.Vault.
 *
 * A V3 file is encrypted with the master password, which only exists in memory while the vault is unlocked.
 * So the daily worker backs up when the vault is unlocked and otherwise does nothing; [runIfDue] is also
 * called whenever the vault is unlocked, so a missed day is caught up at the next unlock.
 */
@Singleton
class AutoBackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val buildExport: BuildExportUseCase
) {
    internal var clock: () -> Long = { System.currentTimeMillis() }

    fun schedule() {
        val req = PeriodicWorkRequestBuilder<AutoBackupWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiresStorageNotLow(true).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel() {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }

    /** True once a calendar day has passed since the last successful backup. */
    suspend fun isDue(): Boolean {
        val s = settings.current()
        return s.autoBackupEnabled && dayKey(clock()) != dayKey(s.lastAutoBackupAt)
    }

    /** @return true if a backup file was written. */
    suspend fun runIfDue(): Boolean {
        if (!isDue() || !session.isUnlocked.value) return false
        return backupNow() is VaultResult.Success
    }

    suspend fun backupNow(): VaultResult<String> {
        if (!session.isUnlocked.value) return VaultResult.Failure(VaultError.VaultLocked)
        val text = when (val r = buildExport(ExportFormat.V3)) {
            is VaultResult.Success -> r.value
            is VaultResult.Failure -> return r
            VaultResult.Loading -> return VaultResult.Loading
        }
        return try {
            val name = "vault_${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(clock()))}.Vault"
            val where = withContext(Dispatchers.IO) { write(name, text) }
            settings.update { it.copy(lastAutoBackupAt = clock()) }
            Timber.i("auto-backup written")
            VaultResult.Success(where)
        } catch (e: Exception) {
            Timber.w("auto-backup failed: %s", e.javaClass.simpleName)
            VaultResult.Failure(VaultError.IOError(e))
        }
    }

    private fun write(name: String, text: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER"
            // replace today's earlier file (only files created by this app are visible/deletable here)
            resolver.query(
                collection, arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                arrayOf(name, "$relative%"), null
            )?.use { c -> while (c.moveToNext()) resolver.delete(android.content.ContentUris.withAppendedId(collection, c.getLong(0)), null, null) }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(collection, values) ?: throw java.io.IOException("MediaStore insert failed")
            resolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: throw java.io.IOException("open failed")
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            return "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/$name"
        }
        // Android 8/9: no scoped storage permission requested, so write to the app's own Downloads folder
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FOLDER).apply { mkdirs() }
        File(dir, name).writeText(text, Charsets.UTF_8)
        return "${dir.absolutePath}/$name"
    }

    private fun dayKey(ms: Long): String = if (ms <= 0) "" else SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))

    companion object {
        const val WORK_NAME = "bsrpro_auto_backup"
        const val FOLDER = "BSRPRO_Backups"
    }
}

@EntryPoint
@InstallIn(SingletonComponent::class)
interface AutoBackupEntryPoint {
    fun autoBackupManager(): AutoBackupManager
}

class AutoBackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val manager = EntryPointAccessors.fromApplication(applicationContext, AutoBackupEntryPoint::class.java).autoBackupManager()
        manager.runIfDue()          // no-op while the vault is locked; caught up at the next unlock
        return Result.success()
    }
}
