@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.sharing

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.asImageBitmap
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.SecureShareManager
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.util.findFragmentActivity

@Composable
fun SharingScreen(
    onBack: () -> Unit = {},
    vm: SharingViewModel = hiltViewModel()
) {
    BackHandler { onBack() }

    val entries by vm.entries.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val activity = context.findFragmentActivity()

    var pinDialog by rememberSaveable { mutableStateOf(false) }
    var pendingEntryId by rememberSaveable { mutableStateOf<String?>(null) }
    var pin by rememberSaveable { mutableStateOf("") }
    var actionLabel by rememberSaveable { mutableStateOf("Share") }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var expiryMinutes by rememberSaveable { mutableStateOf(10f) }
    var maxViews by rememberSaveable { mutableStateOf(1f) }
    var linkPassword by rememberSaveable { mutableStateOf("") }
    var qrLink by rememberSaveable { mutableStateOf<String?>(null) }

    fun options() = SecureShareManager.ShareOptions(
        ttlMs = expiryMinutes.toLong() * 60_000L,
        maxViews = maxViews.toInt(),
        password = linkPassword
    )

    suspend fun performAuthorizedAction(entry: VaultEntry, label: String) {
        val opts = options()
        val link = vm.createLink(entry, opts)
        when (label) {
            "Share" -> shareText(context, link)
            "Copy" -> vm.copySecret(link, "Secure link")
            "QR" -> qrLink = link
        }
    }

    fun requestShare(entry: VaultEntry, label: String) {
        scope.launch {
            if (vm.biometricAvailable() && activity != null) {
                if (vm.authenticateBiometric(activity)) {
                    performAuthorizedAction(entry, label)
                    return@launch
                }
            }

            if (vm.isPinConfigured()) {
                pendingEntryId = entry.id
                actionLabel = label
                pinDialog = true
            } else {
                message = "Enable biometric unlock or set a 4–6 digit sharing PIN in Settings first."
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Secure Sharing", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState(
                "Nothing to share",
                "Active vault entries can be shared using an encrypted link.",
                Modifier.padding(padding).fillMaxWidth()
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, null)
                                Text(
                                    "Link protection",
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(start = 8.dp)
                                )
                            }
                            Text("Expiry: ${expiryMinutes.toInt()} minutes")
                            Slider(
                                value = expiryMinutes,
                                onValueChange = { expiryMinutes = it },
                                valueRange = 1f..60f,
                                steps = 58
                            )
                            Text("View limit: ${maxViews.toInt()}")
                            Slider(
                                value = maxViews,
                                onValueChange = { maxViews = it },
                                valueRange = 1f..10f,
                                steps = 8
                            )
                            OutlinedTextField(
                                value = linkPassword,
                                onValueChange = { linkPassword = it.take(128) },
                                label = { Text("Optional link password") },
                                supportingText = {
                                    Text("For password-protected shares, send this password separately.")
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                message?.let { text ->
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Text(
                                text,
                                modifier = Modifier.padding(16.dp),
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }

                items(entries, key = { it.id }) { entry ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                entry.title.ifBlank { "Untitled" },
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                entry.username.ifBlank { entry.url },
                                style = MaterialTheme.typography.bodySmall
                            )
                            Button(
                                onClick = { requestShare(entry, "Share") },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Share encrypted link")
                            }
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { requestShare(entry, "Copy") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.ContentCopy, null)
                                    Text("  Copy")
                                }
                                OutlinedButton(
                                    onClick = { requestShare(entry, "QR") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.QrCode2, null)
                                    Text("  QR")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (pinDialog) {
        AlertDialog(
            onDismissRequest = {
                pinDialog = false
                pin = ""
            },
            title = { Text("Authorize secure sharing") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter your 4–6 digit sharing PIN to continue.")
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it.filter(Char::isDigit).take(6) },
                        label = { Text("Sharing PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = pin.length in 4..6,
                    onClick = {
                        scope.launch {
                            val entry = entries.firstOrNull { it.id == pendingEntryId }
                            val ok = vm.verifyPin(pin)
                            if (!ok) {
                                message = "Incorrect sharing PIN"
                                return@launch
                            }
                            pinDialog = false
                            pin = ""
                            if (entry != null) performAuthorizedAction(entry, actionLabel)
                        }
                    }
                ) { Text("Continue") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        pinDialog = false
                        pin = ""
                    }
                ) { Text("Cancel") }
            }
        )
    }

    qrLink?.let { link ->
        AlertDialog(
            onDismissRequest = { qrLink = null },
            title = { Text("Secure share QR") },
            text = {
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QrCodeBitmap(link)?.let { bitmap ->
                        androidx.compose.foundation.Image(
                            bitmap = bitmap,
                            contentDescription = "Secure share QR code",
                            modifier = Modifier.size(280.dp)
                        )
                    }
                    Text("Scan this code on a device with BSRPRO installed.")
                    if (linkPassword.isNotBlank()) {
                        Text("The share password is NOT contained in the QR code.")
                    }
                    OutlinedButton(onClick = { vm.copySecret(link, "Secure link") }) {
                        Icon(Icons.Default.ContentCopy, null)
                        Text("  Copy link")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { qrLink = null }) { Text("Close") }
            }
        )
    }
}

private fun QrCodeBitmap(value: String): androidx.compose.ui.graphics.ImageBitmap? = runCatching {
    val matrix = QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, 768, 768)
    val bitmap = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888)
    for (x in 0 until matrix.width) {
        for (y in 0 until matrix.height) {
            bitmap.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        }
    }
    bitmap.asImageBitmap()
}.getOrNull()

private fun shareText(context: Context, value: String) {
    context.startActivity(
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, value)
            },
            "Share secure link"
        )
    )
}

