package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.core.util.TotpConfig

class AutofillMatcherTest {
    private fun e(id: String, url: String = "", user: String = "u", pw: String = "p", pkg: String = "", used: Long = 0, title: String = id) =
        VaultEntry(id = id, title = title, url = url, username = user, password = pw, appPackage = pkg, lastUsedAt = used)

    private val entries = listOf(
        e("gh", "https://github.com/login"),
        e("sub", "https://accounts.github.com"),
        e("evil", "https://evil-github.com"),
        e("other", "https://example.org"),
        e("app", pkg = "com.example.bank"),
        e("legacy", url = "androidapp://com.example.legacy"),
        VaultEntry(id = "note", title = "n", url = "https://github.com", isNote = true, notes = "x"),
        VaultEntry(id = "marker", metaType = "folder", url = "https://github.com")
    )

    @Test fun `web domain matches exact and related hosts only`() {
        val r = AutofillMatcher.match(entries, "com.android.chrome", "www.github.com")
        assertEquals(listOf("gh", "sub"), r.map { it.entry.id })
        assertEquals(listOf(MatchKind.EXACT, MatchKind.RELATED), r.map { it.kind })
    }

    @Test fun `lookalike domains never match`() {
        assertTrue(AutofillMatcher.match(entries, "com.android.chrome", "github.com.evil.io").isEmpty())
        assertTrue(AutofillMatcher.match(entries, "com.android.chrome", "gitub.com").isEmpty())
    }

    @Test fun `native apps match by package or androidapp url`() {
        assertEquals(listOf("app"), AutofillMatcher.match(entries, "com.example.bank", null).map { it.entry.id })
        assertEquals(listOf("legacy"), AutofillMatcher.match(entries, "com.example.legacy", null).map { it.entry.id })
        assertTrue(AutofillMatcher.match(entries, "com.unknown", null).isEmpty())
    }

    @Test fun `native app package matching tolerates surrounding whitespace`() {
        val spaced = e("spaced", pkg = "  com.jio.jpp1  ")
        assertEquals(listOf("spaced"), AutofillMatcher.match(listOf(spaced), " com.jio.jpp1 ", null).map { it.entry.id })
        val legacy = e("legacy-spaced", url = "androidapp://com.jio.jpp1 ")
        assertEquals(listOf("legacy-spaced"), AutofillMatcher.match(listOf(legacy), "com.jio.jpp1", null).map { it.entry.id })
    }

    @Test fun `exact first then most recently used then alphabetical`() {
        val list = listOf(
            e("b", "https://site.com", used = 5, title = "b"),
            e("a", "https://site.com", used = 5, title = "a"),
            e("c", "https://site.com", used = 9, title = "c"),
            e("sub", "https://login.site.com", used = 99)
        )
        assertEquals(listOf("c", "a", "b", "sub"), AutofillMatcher.match(list, "x", "site.com").map { it.entry.id })
    }

    @Test fun `values per field type`() {
        val entry = e("x", user = "me@x.com", pw = "secret")
        assertEquals("me@x.com", AutofillValues.valueFor(AutofillFieldType.USERNAME, entry, 0))
        assertEquals("secret", AutofillValues.valueFor(AutofillFieldType.PASSWORD, entry, 0))
        assertEquals("", AutofillValues.valueFor(AutofillFieldType.PIN, entry, 0))
        val withPin = entry.copy(appPin = "0731")
        assertEquals("0731", AutofillValues.valueFor(AutofillFieldType.PIN, withPin, 0))
        assertEquals("secret", AutofillValues.valueFor(AutofillFieldType.PASSWORD, withPin, 0))
        assertEquals("", AutofillValues.valueFor(AutofillFieldType.NEW_PASSWORD, entry, 0))
        assertEquals("", AutofillValues.valueFor(AutofillFieldType.OTP, entry, 0))
    }

    @Test fun `username falls back to email then mobile`() {
        assertEquals("a@b.c", AutofillValues.valueFor(AutofillFieldType.USERNAME, VaultEntry(email = "a@b.c", mobile = "1"), 0))
        assertEquals("999", AutofillValues.valueFor(AutofillFieldType.USERNAME, VaultEntry(mobile = "999"), 0))
    }

    @Test fun `otp uses the next period when the code is about to expire`() {
        val secret = "JBSWY3DPEHPK3PXP"
        val entry = VaultEntry(totp = secret)
        val cfg = TotpConfig(secret)
        val early = 10_000L          // 20 s left → current code
        val late = 29_500L           // 0.5 s left → next period's code
        assertEquals(Totp.generate(cfg, early), AutofillValues.otpFor(entry, early))
        assertEquals(Totp.generate(cfg, 30_000L), AutofillValues.otpFor(entry, late))
    }

    @Test fun `otp from an otpauth uri and an invalid secret`() {
        val uri = "otpauth://totp/x?secret=JBSWY3DPEHPK3PXP&digits=8&period=30"
        assertEquals(8, AutofillValues.otpFor(VaultEntry(totp = uri), 10_000L).length)
        assertEquals("", AutofillValues.otpFor(VaultEntry(totp = "not base32!"), 10_000L))
    }
}
