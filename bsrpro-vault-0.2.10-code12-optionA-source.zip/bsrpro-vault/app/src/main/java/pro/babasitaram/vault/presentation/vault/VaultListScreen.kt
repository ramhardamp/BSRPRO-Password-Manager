@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.vault

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.components.Avatar
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.components.bucketColor
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.findFragmentActivity

private sealed interface ListRow {
    data class Header(val key: String, val count: Int, val expanded: Boolean) : ListRow
    data class Item(val entry: VaultEntry, val indented: Boolean) : ListRow
}

private fun groupKey(e: VaultEntry): String =
    UrlUtils.domainOf(e.url).ifEmpty { e.appName.ifEmpty { e.title.ifEmpty { "other" } } }

private fun buildRows(entries: List<VaultEntry>, grouped: Boolean, expanded: Set<String>): List<ListRow> {
    if (!grouped) return entries.map<VaultEntry, ListRow> { ListRow.Item(it, false) }
    return entries.groupBy { groupKey(it) }.flatMap<String, List<VaultEntry>, ListRow> { (key, list) ->
        if (list.size == 1) {
            listOf<ListRow>(ListRow.Item(list.first(), false))
        } else {
            val open = key in expanded
            buildList<ListRow> {
                add(ListRow.Header(key, list.size, open))
                if (open) list.forEach { add(ListRow.Item(it, true)) }
            }
        }
    }
}

@Composable
fun VaultListScreen(
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
    onGenerator: () -> Unit,
    onSettings: () -> Unit,
    vm: VaultListViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(setOf<String>()) }
    CollectMessages(vm.messages)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BSRPRO Vault") },
                actions = {
                    IconButton(onClick = vm::toggleGrouped) {
                        Icon(Icons.AutoMirrored.Filled.ViewList, contentDescription = "Group by site")
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Menu") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Password generator") }, onClick = { menuOpen = false; onGenerator() })
                            DropdownMenuItem(
                                text = { Text(if (state.biometricEnabled) "Disable biometric unlock" else "Enable biometric unlock") },
                                onClick = {
                                    menuOpen = false
                                    context.findFragmentActivity()?.let { vm.toggleBiometric(it) }
                                }
                            )
                            DropdownMenuItem(text = { Text("Settings") }, onClick = { menuOpen = false; onSettings() })
                            DropdownMenuItem(text = { Text("Lock now") }, onClick = { menuOpen = false; vm.lock() })
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, contentDescription = "Add entry") }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = state.query,
                onValueChange = vm::setQuery,
                placeholder = { Text("Search passwords") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            )
            LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CATEGORIES) { c ->
                    FilterChip(
                        selected = state.category == c,
                        onClick = { vm.setCategory(c) },
                        label = { Text(c.replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
            LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ListFilter.values().toList()) { f ->
                    FilterChip(selected = state.filter == f, onClick = { vm.setFilter(f) }, label = { Text(f.label) })
                }
            }

            val rows = remember(state.entries, state.grouped, expanded) { buildRows(state.entries, state.grouped, expanded) }
            when {
                state.totalCount == 0 -> EmptyState("No passwords yet", "Tap + to add one, or restore a backup when creating a vault.")
                rows.isEmpty() -> EmptyState("No matches", "Try a different search or filter.")
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(rows) { row ->
                        when (row) {
                            is ListRow.Header -> ListItem(
                                headlineContent = { Text(row.key) },
                                supportingContent = { Text("${row.count} entries") },
                                leadingContent = { Icon(Icons.Default.Folder, contentDescription = null) },
                                trailingContent = {
                                    Icon(if (row.expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                                },
                                modifier = Modifier.clickable {
                                    expanded = if (row.key in expanded) expanded - row.key else expanded + row.key
                                }
                            )
                            is ListRow.Item -> EntryRow(
                                entry = row.entry,
                                indented = row.indented,
                                onClick = { onOpen(row.entry.id) },
                                onCopy = { vm.copyPassword(row.entry) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EntryRow(entry: VaultEntry, indented: Boolean, onClick: () -> Unit, onCopy: () -> Unit) {
    val subtitle = entry.username.ifEmpty { UrlUtils.domainOf(entry.url).ifEmpty { entry.appName } }
    ListItem(
        headlineContent = { Text(entry.title.ifEmpty { "(untitled)" }, maxLines = 1) },
        supportingContent = { if (subtitle.isNotEmpty()) Text(subtitle, maxLines = 1) },
        leadingContent = { Avatar(entry.title.ifEmpty { subtitle }) },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (entry.starred) Icon(Icons.Default.Star, contentDescription = "Starred", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                if (entry.password.isNotEmpty()) {
                    Box(Modifier.padding(horizontal = 6.dp).size(8.dp).background(bucketColor(entry.strengthBucket()), CircleShape))
                    IconButton(onClick = onCopy) { Icon(Icons.Default.ContentCopy, contentDescription = "Copy password") }
                }
            }
        },
        modifier = Modifier.clickable(onClick = onClick).padding(start = if (indented) 24.dp else 0.dp)
    )
}
