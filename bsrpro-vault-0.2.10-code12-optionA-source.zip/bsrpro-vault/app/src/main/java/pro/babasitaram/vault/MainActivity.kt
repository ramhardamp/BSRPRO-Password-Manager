package pro.babasitaram.vault

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.AndroidEntryPoint
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.security.ScreenshotGuard
import pro.babasitaram.vault.presentation.lock.LockScreen
import pro.babasitaram.vault.presentation.navigation.VaultNavHost
import pro.babasitaram.vault.presentation.root.RootState
import pro.babasitaram.vault.presentation.root.RootViewModel
import pro.babasitaram.vault.presentation.setup.SetupScreen
import pro.babasitaram.vault.presentation.theme.VaultTheme

@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ScreenshotGuard.enable(this)
        enableEdgeToEdge()
        requestNotificationPermissionOnce()
        setContent {
            val root: RootViewModel = hiltViewModel()
            val state by root.state.collectAsStateWithLifecycle()
            val settings by root.settings.collectAsStateWithLifecycle()
            val dark = when (settings.theme) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }
            VaultTheme(darkTheme = dark) {
                Surface(Modifier.fillMaxSize()) {
                    when (state) {
                        RootState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                        RootState.NeedsSetup -> SetupScreen()
                        RootState.Locked -> LockScreen()
                        RootState.Unlocked -> VaultNavHost()
                    }
                }
            }
        }
    }

    // Android 13+: needed for the "Save password?" notification that autofill posts (the system never asks twice after a denial)
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun requestNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}
