package pro.babasitaram.vault.domain.usecase

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import javax.inject.Inject
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.model.VaultPayload
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.domain.repository.VaultRepository

/** In-place V3 restore protected by a durable encrypted-blob snapshot and phase journal. */
class RestoreVaultTransactionUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val repository: VaultRepository,
    @ApplicationContext context: Context
) {
    private val journal = RestoreJournal(context.filesDir)
    private val mutex = Mutex()

    suspend operator fun invoke(containerJson: String, currentPassword: CharArray): VaultResult<Int> = mutex.withLock {
        vaultCatching {
            // First authenticate against the currently installed vault. This must not mutate it.
            val oldData = blobStore.read(currentPassword)
            val oldRaw = blobStore.readRaw() ?: throw VaultError.VaultNotFound

            val plaintext = VaultCrypto.decryptV3(containerJson, currentPassword)
            val parsed = V3PayloadParser.parse(plaintext)
            val incoming = VaultData(parsed.entries, parsed.folders)
            // Normalize supported V3 schemas to the app's canonical payload before digest comparison.
            // The read-back digest below proves the persisted data matches the validated decrypted payload.
            val expectedDigest = digest(canonical(incoming))

            journal.prepare(oldRaw)
            try {
                journal.setPhase(RestoreJournal.Phase.REPLACING)
                blobStore.write(incoming, currentPassword)
                journal.setPhase(RestoreJournal.Phase.WRITTEN)
                val restored = blobStore.read(currentPassword)
                val actualDigest = digest(canonical(restored))
                if (!MessageDigest.isEqual(expectedDigest, actualDigest)) {
                    throw VaultError.InvalidFormat("Restored vault round-trip mismatch")
                }
                journal.setPhase(RestoreJournal.Phase.VERIFIED)
                repository.setData(restored)
                journal.clear()
                restored.entries.count { !it.isFolderMarker }
            } catch (failure: Exception) {
                try {
                    blobStore.writeRaw(oldRaw)
                    val recovered = blobStore.read(currentPassword)
                    if (recovered != oldData) throw IllegalStateException("Rollback verification mismatch")
                    repository.setData(recovered)
                    journal.clear()
                } catch (rollbackFailure: Exception) {
                    // Keep journal + snapshot for startup recovery; never delete evidence.
                    throw VaultError.IOError(IllegalStateException("Restore failed and rollback needs recovery", rollbackFailure))
                }
                throw failure
            }
        }
    }

    private fun canonical(data: VaultData): String = VaultJson.encodeToString(
        VaultPayload.serializer(), VaultPayload(entries = data.entries, folders = data.folders)
    )

    private fun digest(text: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))


}

/** Crash recovery runs after the user supplies the existing master password, before normal unlock reads data. */
class RestoreJournal(private val dir: File) {
    enum class Phase { PREPARED, REPLACING, WRITTEN, VERIFIED }
    private val journalFile = File(dir, "vault-restore.transaction")
    private val snapshotFile = File(dir, "vault-restore.snapshot")

    @Synchronized fun prepare(raw: String) {
        dir.mkdirs()
        writeSynced(snapshotFile, raw)
        setPhase(Phase.PREPARED)
    }

    @Synchronized fun setPhase(phase: Phase) {
        writeSynced(journalFile, "BSR-RESTORE-1\n${phase.name}\n${System.currentTimeMillis()}\n")
    }

    @Synchronized fun hasPending(): Boolean = journalFile.exists()

    @Synchronized suspend fun recover(blobStore: VaultBlobStore, password: CharArray) {
        if (!journalFile.exists()) return
        val lines = journalFile.readLines(Charsets.UTF_8)
        require(lines.size >= 3 && lines[0] == "BSR-RESTORE-1" && Phase.entries.any { it.name == lines[1] }) {
            "Restore recovery journal is invalid; recovery files were preserved"
        }
        require(snapshotFile.isFile && snapshotFile.length() in 1..(25L * 1024L * 1024L)) {
            "Restore recovery snapshot is missing or invalid; recovery files were preserved"
        }
        val raw = snapshotFile.readText(Charsets.UTF_8)
        // Authenticate and parse the snapshot BEFORE touching the current vault file.
        // A wrong password or damaged snapshot must never overwrite the current blob.
        val snapshotPlaintext = VaultCrypto.decryptWithKeyInfo(raw, password).first
        V3PayloadParser.parse(snapshotPlaintext)
        blobStore.writeRaw(raw)
        val restored = blobStore.read(password)
        val restoredPlaintext = VaultJson.encodeToString(
            VaultPayload.serializer(), VaultPayload(entries = restored.entries, folders = restored.folders)
        )
        val snapshotData = V3PayloadParser.parse(snapshotPlaintext)
        val expected = VaultJson.encodeToString(
            VaultPayload.serializer(), VaultPayload(entries = snapshotData.entries, folders = snapshotData.folders)
        )
        if (!MessageDigest.isEqual(
                MessageDigest.getInstance("SHA-256").digest(expected.toByteArray(Charsets.UTF_8)),
                MessageDigest.getInstance("SHA-256").digest(restoredPlaintext.toByteArray(Charsets.UTF_8))
            )) throw IllegalStateException("Restore snapshot verification mismatch; journal preserved")
        clear()
    }

    @Synchronized fun clear() {
        if (journalFile.exists() && !journalFile.delete()) throw java.io.IOException("Could not clear restore journal")
        if (snapshotFile.exists() && !snapshotFile.delete()) throw java.io.IOException("Could not clear restore snapshot")
    }

    private fun writeSynced(file: File, value: String) {
        FileOutputStream(file).use { out -> out.write(value.toByteArray(Charsets.UTF_8)); out.flush(); out.fd.sync() }
    }
}
