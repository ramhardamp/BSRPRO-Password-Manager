@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.lock

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.presentation.components.PasswordField
import pro.babasitaram.vault.presentation.util.findFragmentActivity

@Composable
fun LockScreen(vm: LockViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var password by rememberSaveable { mutableStateOf("") }
    val activity = LocalContext.current.findFragmentActivity()
    var autoPrompted by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(state.biometricAvailable) {
        if (state.biometricAvailable && !autoPrompted && activity != null) {
            autoPrompted = true
            vm.unlockWithBiometric(activity)
        }
    }

    val locked = state.lockedSeconds > 0
    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(pro.babasitaram.vault.R.drawable.brand_logo),
                contentDescription = "BSRPRO",
                modifier = Modifier.size(88.dp)
            )
            Text("Vault locked", style = MaterialTheme.typography.headlineMedium)
            PasswordField(password, { password = it }, "Master password", enabled = !state.busy && !locked)
            if (locked) {
                Text("Try again in ${state.lockedSeconds}s", color = MaterialTheme.colorScheme.error)
            } else {
                state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
            Button(
                onClick = { vm.unlock(password); password = "" },
                enabled = password.isNotEmpty() && !state.busy && !locked,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("Unlock")
            }
            if (state.biometricAvailable && activity != null) {
                TextButton(onClick = { vm.unlockWithBiometric(activity) }, enabled = !state.busy && !locked) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null)
                    Text("  Use biometrics")
                }
            }
        }
    }
}
