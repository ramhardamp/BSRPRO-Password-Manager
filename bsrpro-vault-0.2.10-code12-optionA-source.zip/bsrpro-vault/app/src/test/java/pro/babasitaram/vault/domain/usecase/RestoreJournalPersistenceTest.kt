package pro.babasitaram.vault.domain.usecase

import java.nio.file.Files
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import java.io.File

class RestoreJournalPersistenceTest {
    @TempDir lateinit var temp: File

    @Test fun preparedSnapshotAndPhaseSurviveNewJournalInstance() {
        val first = RestoreJournal(temp)
        first.prepare("encrypted-old-vault-blob")
        first.setPhase(RestoreJournal.Phase.REPLACING)

        val restarted = RestoreJournal(temp)
        assertTrue(restarted.hasPending())
        assertEquals("encrypted-old-vault-blob", File(temp, "vault-restore.snapshot").readText())
        assertEquals("BSR-RESTORE-1", File(temp, "vault-restore.transaction").readLines().first())
        assertEquals("REPLACING", File(temp, "vault-restore.transaction").readLines()[1])
    }

    @Test fun clearRemovesJournalAndSnapshot() {
        val journal = RestoreJournal(temp)
        journal.prepare("encrypted-snapshot")
        journal.clear()
        assertTrue(!File(temp, "vault-restore.transaction").exists())
        assertTrue(!File(temp, "vault-restore.snapshot").exists())
    }
}
