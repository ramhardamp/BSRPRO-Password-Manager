# BSRPRO Vault — Android

Native Android companion for the BSRPRO Password Manager browser extension.
Kotlin · Jetpack Compose · Hilt · MVVM + Clean Architecture · min SDK 26.

## Build
1. Open in Android Studio (Koala+ / JDK 17).
2. If `gradlew` is missing: `gradle wrapper --gradle-version 8.7` (or let Android Studio sync).
3. `./gradlew assembleDebug`

## Status
Phases 0–5 done (scaffold, security, crypto, persistence, auth & lock, core UI). Phase 6 (autofill) next. See ROADMAP.md.

## Security rules
- Master password is always `CharArray`, wiped after use.
- No INTERNET permission until the optional sync phase.
- Keystore / signing files are git-ignored. Never commit them.
