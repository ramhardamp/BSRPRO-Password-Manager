package pro.babasitaram.vault.data

import io.mockk.coVerify
import io.mockk.mockk
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.data.repository.VaultRepositoryImpl

class VaultRepositoryImplTest {
    @TempDir
    lateinit var dir: File

    private val pw = "Master#Pass123456".toCharArray()
    private val dao = mockk<VaultDao>(relaxed = true)

    private fun blob() = FileVaultBlobStore(dir, Dispatchers.IO)

    private fun unlockedRepo(): Pair<VaultRepositoryImpl, SessionKeyStore> {
        val session = SessionKeyStore().also { it.unlock(pw) }
        return VaultRepositoryImpl(blob(), session, dao) to session
    }

    @Test
    fun `setData hides folder markers but keeps them in the blob`() = runTest {
        val (repo, _) = unlockedRepo()
        val marker = VaultEntry(id = "m", title = "Work", metaType = "folder")
        repo.setData(VaultData(listOf(VaultEntry(id = "1", title = "A"), marker)))
        assertEquals(listOf("1"), repo.entries.value.map { it.id })
        repo.upsert(VaultEntry(id = "2", title = "B"))
        val onDisk = blob().read(pw)
        assertTrue(onDisk.entries.any { it.id == "m" })
        assertEquals(3, onDisk.entries.size)
    }

    @Test
    fun `upsert persists and updates memory`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.upsert(VaultEntry(id = "1", title = "A"))
        repo.upsert(VaultEntry(id = "1", title = "A2"))
        assertEquals(listOf("A2"), repo.entries.value.map { it.title })
        assertEquals(listOf("A2"), blob().read(pw).entries.map { it.title })
    }

    @Test
    fun `delete removes from memory and disk`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.upsert(VaultEntry(id = "1", title = "A"))
        repo.upsert(VaultEntry(id = "2", title = "B"))
        repo.delete("1")
        assertNull(repo.entry("1"))
        assertEquals(listOf("2"), blob().read(pw).entries.map { it.id })
    }

    @Test
    fun `failed write leaves memory unchanged`() = runTest {
        val session = SessionKeyStore() // locked: no password available for the write
        val repo = VaultRepositoryImpl(blob(), session, dao)
        repo.setData(VaultData(listOf(VaultEntry(id = "1", title = "A"))))
        assertThrows<VaultError.VaultLocked> { repo.upsert(VaultEntry(id = "2", title = "B")) }
        assertEquals(listOf("1"), repo.entries.value.map { it.id })
    }

    @Test
    fun `duplicate detection matches domain and username ignoring case`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.setData(VaultData(listOf(VaultEntry(id = "1", title = "GH", url = "https://www.github.com/login", username = "Bob"))))
        val dup = repo.findDuplicate(VaultEntry(id = "new", url = "http://github.com", username = "bob"))
        assertNotNull(dup)
        assertEquals("1", dup!!.id)
        assertNull(repo.findDuplicate(VaultEntry(id = "new", url = "http://github.com", username = "alice")))
        assertNull(repo.findDuplicate(VaultEntry(id = "1", url = "http://github.com", username = "bob")))
    }

    @Test
    fun `duplicate detection matches android package`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.setData(VaultData(listOf(VaultEntry(id = "1", appPackage = "com.x", username = "u"))))
        assertNotNull(repo.findDuplicate(VaultEntry(id = "n", appPackage = "com.x", username = "U")))
    }

    @Test
    fun `clear empties memory and wipes metadata`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.upsert(VaultEntry(id = "1", title = "A"))
        repo.clear()
        assertTrue(repo.entries.value.isEmpty())
        coVerify { dao.wipe() }
    }
}
