package pro.babasitaram.vault.core.security

import android.os.SystemClock
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.di.ApplicationScope
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase

/** Locks the vault after the app has been in the background for the configured time. */
@Singleton
class AutoLockController @Inject constructor(
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val lockVault: LockVaultUseCase,
    @ApplicationScope private val scope: CoroutineScope
) {
    internal var clock: () -> Long = { SystemClock.elapsedRealtime() }
    private var job: Job? = null
    private var backgroundedAt = 0L

    fun onBackgrounded() {
        if (!session.isUnlocked.value) return
        backgroundedAt = clock()
        job?.cancel()
        job = scope.launch {
            val s = settings.current()
            if (!s.lockOnBackground) return@launch
            val ms = s.autoLockSeconds * 1000L
            if (ms > 0) delay(ms)
            lockVault()
        }
    }

    fun onForegrounded() {
        job?.cancel()
        val since = backgroundedAt
        backgroundedAt = 0L
        if (since == 0L || !session.isUnlocked.value) return
        scope.launch {
            // the timer may not have fired while the process was frozen — check the elapsed time as well
            val s = settings.current()
            if (s.lockOnBackground && clock() - since >= s.autoLockSeconds * 1000L) lockVault()
        }
    }
}
