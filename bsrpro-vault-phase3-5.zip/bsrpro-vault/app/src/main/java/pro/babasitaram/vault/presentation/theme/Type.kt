package pro.babasitaram.vault.presentation.theme

import androidx.compose.material3.Typography

val VaultTypography = Typography()
