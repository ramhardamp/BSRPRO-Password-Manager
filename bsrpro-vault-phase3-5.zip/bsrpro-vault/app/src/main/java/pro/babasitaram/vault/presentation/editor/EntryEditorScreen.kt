@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.editor

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.CustomField
import pro.babasitaram.vault.presentation.components.PasswordField
import pro.babasitaram.vault.presentation.vault.CATEGORIES

private val RECORD_TYPES = listOf("login" to "Login", "card" to "Card", "identity" to "Identity", "note" to "Secure note")

@Composable
fun EntryEditorScreen(onDone: () -> Unit, vm: EntryEditorViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val form = state.form
    LaunchedEffect(state.saved) { if (state.saved) onDone() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isEdit) "Edit entry" else "New entry") },
                navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Cancel") } },
                actions = { TextButton(onClick = { vm.save() }, enabled = !state.saving) { Text("Save") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(RECORD_TYPES) { (key, label) ->
                    FilterChip(selected = form.recordType == key, onClick = { vm.update { it.copy(recordType = key) } }, label = { Text(label) })
                }
            }
            Field("Title *", form.title) { v -> vm.update { it.copy(title = v) } }

            when (form.recordType) {
                "login" -> {
                    Field("Website URL", form.url, KeyboardType.Uri) { v -> vm.update { it.copy(url = v) } }
                    Field("Username", form.username, KeyboardType.Email) { v -> vm.update { it.copy(username = v) } }
                    PasswordField(
                        value = form.password,
                        onValueChange = { v -> vm.update { it.copy(password = v) } },
                        label = "Password",
                        showStrength = true,
                        trailingExtra = {
                            IconButton(onClick = vm::generatePassword) { Icon(Icons.Default.Autorenew, "Generate password") }
                        }
                    )
                    Field("Mobile", form.mobile, KeyboardType.Phone) { v -> vm.update { it.copy(mobile = v) } }
                    Field("Authenticator secret (TOTP)", form.totp) { v -> vm.update { it.copy(totp = v) } }
                }
                "card" -> {
                    Field("Cardholder", form.cardholder) { v -> vm.update { it.copy(cardholder = v) } }
                    Field("Card number", form.cardNumber, KeyboardType.Number) { v -> vm.update { it.copy(cardNumber = v) } }
                    Field("Expiry (MM/YY)", form.cardExpiry) { v -> vm.update { it.copy(cardExpiry = v) } }
                    PasswordField(form.cardCvv, { v -> vm.update { it.copy(cardCvv = v) } }, "CVV")
                }
                "identity" -> {
                    Field("Full name", form.fullName) { v -> vm.update { it.copy(fullName = v) } }
                    Field("Email", form.email, KeyboardType.Email) { v -> vm.update { it.copy(email = v) } }
                    Field("Phone", form.phone, KeyboardType.Phone) { v -> vm.update { it.copy(phone = v) } }
                    Field("Address", form.address, singleLine = false) { v -> vm.update { it.copy(address = v) } }
                    Field("ID number", form.idNumber) { v -> vm.update { it.copy(idNumber = v) } }
                    Field("ID expiry", form.idExpiry) { v -> vm.update { it.copy(idExpiry = v) } }
                }
            }

            Field("Notes", form.notes, singleLine = false) { v -> vm.update { it.copy(notes = v) } }

            Text("Category", style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CATEGORIES) { c ->
                    FilterChip(
                        selected = form.category.equals(c, ignoreCase = true),
                        onClick = { vm.update { it.copy(category = c) } },
                        label = { Text(c.replaceFirstChar { ch -> ch.uppercase() }) }
                    )
                }
            }

            if (state.folders.isNotEmpty()) {
                var open by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { open = true }) {
                        Text("Folder: " + (state.folders.firstOrNull { it.id == form.folderId }?.name ?: "None"))
                    }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        DropdownMenuItem(text = { Text("None") }, onClick = { open = false; vm.update { it.copy(folderId = "") } })
                        state.folders.forEach { f ->
                            DropdownMenuItem(text = { Text(f.name) }, onClick = { open = false; vm.update { it.copy(folderId = f.id) } })
                        }
                    }
                }
            }

            Field("Tags (comma separated)", form.tags) { v -> vm.update { it.copy(tags = v) } }

            Text("Custom fields", style = MaterialTheme.typography.labelLarge)
            form.customFields.forEachIndexed { index, field ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = field.k, onValueChange = { v -> vm.update { f -> f.copy(customFields = f.customFields.replaceAt(index, field.copy(k = v))) } },
                        label = { Text("Name") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = field.v, onValueChange = { v -> vm.update { f -> f.copy(customFields = f.customFields.replaceAt(index, field.copy(v = v))) } },
                        label = { Text("Value") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { vm.update { f -> f.copy(customFields = f.customFields.filterIndexed { i, _ -> i != index }) } }) {
                        Icon(Icons.Default.Close, "Remove field")
                    }
                }
            }
            TextButton(onClick = { vm.update { it.copy(customFields = it.customFields + CustomField()) } }) { Text("Add custom field") }

            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(onClick = { vm.save() }, enabled = !state.saving, modifier = Modifier.fillMaxWidth()) { Text("Save") }
        }
    }

    state.duplicate?.let { dup ->
        AlertDialog(
            onDismissRequest = vm::dismissDuplicate,
            title = { Text("Entry already exists") },
            text = { Text("\"${dup.title}\" already uses this site and username. Overwrite it, or save this as a separate entry?") },
            confirmButton = { TextButton(onClick = { vm.save(overwrite = dup) }) { Text("Overwrite") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { vm.save(skipDuplicateCheck = true) }) { Text("Save as new") }
                    TextButton(onClick = vm::dismissDuplicate) { Text("Cancel") }
                }
            }
        )
    }
}

private fun <T> List<T>.replaceAt(index: Int, value: T): List<T> =
    mapIndexed { i, old -> if (i == index) value else old }

@Composable
private fun Field(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth()
    )
}
