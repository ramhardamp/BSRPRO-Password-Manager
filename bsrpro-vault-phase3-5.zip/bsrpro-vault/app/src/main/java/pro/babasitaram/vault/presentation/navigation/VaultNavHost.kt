package pro.babasitaram.vault.presentation.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import pro.babasitaram.vault.presentation.editor.EntryEditorScreen
import pro.babasitaram.vault.presentation.generator.GeneratorScreen
import pro.babasitaram.vault.presentation.vault.EntryDetailScreen
import pro.babasitaram.vault.presentation.vault.VaultListScreen

object Routes {
    const val LIST = "list"
    const val DETAIL = "detail/{id}"
    const val EDIT = "edit?id={id}"
    const val GENERATOR = "generator"

    fun detail(id: String) = "detail/${Uri.encode(id)}"
    fun edit(id: String? = null) = if (id == null) "edit" else "edit?id=${Uri.encode(id)}"
}

/** Only composed while the vault is unlocked; locking removes it, which drops every decrypted screen. */
@Composable
fun VaultNavHost() {
    val nav = rememberNavController()

    DisposableEffect(nav) {
        onDispose {
            // best effort: destroy the back stack (and its ViewModels) so nothing decrypted survives a lock
            runCatching { nav.popBackStack(Routes.LIST, inclusive = true) }
        }
    }

    NavHost(navController = nav, startDestination = Routes.LIST) {
        composable(Routes.LIST) {
            VaultListScreen(
                onOpen = { nav.navigate(Routes.detail(it)) },
                onAdd = { nav.navigate(Routes.edit()) },
                onGenerator = { nav.navigate(Routes.GENERATOR) }
            )
        }
        composable(Routes.DETAIL, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
            EntryDetailScreen(
                onBack = { nav.popBackStack() },
                onEdit = { nav.navigate(Routes.edit(it)) }
            )
        }
        composable(
            Routes.EDIT,
            arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })
        ) {
            EntryEditorScreen(onDone = { nav.popBackStack() })
        }
        composable(Routes.GENERATOR) {
            GeneratorScreen(onBack = { nav.popBackStack() })
        }
    }
}
