package pro.babasitaram.vault

import android.app.Application
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject
import pro.babasitaram.vault.core.security.AutoLockController
import timber.log.Timber

@HiltAndroidApp
class BsrApplication : Application() {

    @Inject
    lateinit var autoLock: AutoLockController

    override fun onCreate() {
        super.onCreate()
        // Debug-only logging. A redacting release tree is added in Phase 10.
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())

        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) = autoLock.onForegrounded()
            override fun onStop(owner: LifecycleOwner) = autoLock.onBackgrounded()
        })
    }
}
