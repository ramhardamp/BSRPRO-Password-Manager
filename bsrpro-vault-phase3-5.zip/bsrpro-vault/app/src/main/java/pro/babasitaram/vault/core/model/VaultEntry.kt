package pro.babasitaram.vault.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Mirrors the browser extension's entry JSON. Every field has a default so partial entries decode. */
@Serializable
data class VaultEntry(
    @SerialName("id") val id: String = "",
    @SerialName("title") val title: String = "",
    @SerialName("url") val url: String = "",
    @SerialName("username") val username: String = "",
    @SerialName("password") val password: String = "",
    @SerialName("mobile") val mobile: String = "",
    @SerialName("notes") val notes: String = "",
    @SerialName("totp") val totp: String = "",
    @SerialName("category") val category: String = "other",
    @SerialName("categoryLocked") val categoryLocked: Boolean = false,
    @SerialName("isNote") val isNote: Boolean = false,
    @SerialName("recordType") val recordType: String = "login",
    @SerialName("folderId") val folderId: String = "",
    @SerialName("folder") val folder: String = "",
    @SerialName("type") val type: String = "",
    @SerialName("appPackage") val appPackage: String = "",
    @SerialName("appName") val appName: String = "",
    @SerialName("isPrimaryAppLogin") val isPrimaryAppLogin: Boolean = false,
    @SerialName("starred") val starred: Boolean = false,
    @SerialName("tags") val tags: List<String> = emptyList(),
    @SerialName("customFields") val customFields: List<CustomField> = emptyList(),
    @SerialName("cardNumber") val cardNumber: String = "",
    @SerialName("cardholder") val cardholder: String = "",
    @SerialName("cardExpiry") val cardExpiry: String = "",
    @SerialName("cardCvv") val cardCvv: String = "",
    @SerialName("fullName") val fullName: String = "",
    @SerialName("email") val email: String = "",
    @SerialName("phone") val phone: String = "",
    @SerialName("address") val address: String = "",
    @SerialName("idNumber") val idNumber: String = "",
    @SerialName("idExpiry") val idExpiry: String = "",
    @SerialName("strength") val strength: String = "",
    @SerialName("createdAt") val createdAt: Long = 0L,
    @SerialName("updatedAt") val updatedAt: Long = 0L,
    @SerialName("lastUsedAt") val lastUsedAt: Long = 0L,
    @SerialName("passwordHistory") val passwordHistory: List<PasswordHistoryItem> = emptyList(),
    @SerialName("editHistory") val editHistory: List<EditHistoryItem> = emptyList(),
    @SerialName("_metaType") val metaType: String? = null
) {
    val isFolderMarker: Boolean get() = metaType == "folder"
    val isAppEntry: Boolean get() = appPackage.isNotEmpty()
}

@Serializable
data class CustomField(val k: String = "", val v: String = "")

@Serializable
data class PasswordHistoryItem(val pw: String = "", val changedAt: Long = 0L)

@Serializable
data class EditHistoryItem(
    val changedAt: Long = 0L,
    val fields: List<String> = emptyList(),
    val source: String = ""
)
