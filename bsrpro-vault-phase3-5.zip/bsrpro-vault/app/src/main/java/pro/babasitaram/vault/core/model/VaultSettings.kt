package pro.babasitaram.vault.core.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class VaultSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val autoLockSeconds: Int = 60,
    val clipboardClearSeconds: Int = 30,
    val biometricEnabled: Boolean = false,
    val lockOnBackground: Boolean = true,
    val generatorDefaultLength: Int = 20,
    val generatorKeyword: String = "",
    val travelMode: Boolean = false
)
