package pro.babasitaram.vault.data.local.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.domain.repository.SettingsRepository

class SettingsDataStore(private val store: DataStore<Preferences>) : SettingsRepository {

    override val settings: Flow<VaultSettings> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it.toSettings() }

    override suspend fun current(): VaultSettings = settings.first()

    override suspend fun update(transform: (VaultSettings) -> VaultSettings) {
        store.edit { prefs ->
            val n = transform(prefs.toSettings())
            prefs[THEME] = n.theme.name
            prefs[AUTO_LOCK] = n.autoLockSeconds
            prefs[CLIP_CLEAR] = n.clipboardClearSeconds
            prefs[BIOMETRIC] = n.biometricEnabled
            prefs[LOCK_BG] = n.lockOnBackground
            prefs[GEN_LEN] = n.generatorDefaultLength
            prefs[GEN_KEYWORD] = n.generatorKeyword
            prefs[TRAVEL] = n.travelMode
        }
    }

    private fun Preferences.toSettings(): VaultSettings {
        val d = VaultSettings()
        return VaultSettings(
            theme = this[THEME]?.let { n -> ThemeMode.values().firstOrNull { it.name == n } } ?: d.theme,
            autoLockSeconds = this[AUTO_LOCK] ?: d.autoLockSeconds,
            clipboardClearSeconds = this[CLIP_CLEAR] ?: d.clipboardClearSeconds,
            biometricEnabled = this[BIOMETRIC] ?: d.biometricEnabled,
            lockOnBackground = this[LOCK_BG] ?: d.lockOnBackground,
            generatorDefaultLength = this[GEN_LEN] ?: d.generatorDefaultLength,
            generatorKeyword = this[GEN_KEYWORD] ?: d.generatorKeyword,
            travelMode = this[TRAVEL] ?: d.travelMode
        )
    }

    private companion object {
        val THEME = stringPreferencesKey("theme")
        val AUTO_LOCK = intPreferencesKey("auto_lock_seconds")
        val CLIP_CLEAR = intPreferencesKey("clipboard_clear_seconds")
        val BIOMETRIC = booleanPreferencesKey("biometric_enabled")
        val LOCK_BG = booleanPreferencesKey("lock_on_background")
        val GEN_LEN = intPreferencesKey("generator_default_length")
        val GEN_KEYWORD = stringPreferencesKey("generator_keyword")
        val TRAVEL = booleanPreferencesKey("travel_mode")
    }
}
