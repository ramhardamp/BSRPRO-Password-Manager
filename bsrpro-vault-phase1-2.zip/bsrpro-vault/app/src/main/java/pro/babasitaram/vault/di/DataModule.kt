package pro.babasitaram.vault.di

import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/** Skeleton — bindings are added in later phases. */
@Module
@InstallIn(SingletonComponent::class)
object DataModule
