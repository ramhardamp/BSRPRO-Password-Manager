package pro.babasitaram.vault

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class BsrApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Debug-only logging. A redacting release tree is added in Phase 10.
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
    }
}
