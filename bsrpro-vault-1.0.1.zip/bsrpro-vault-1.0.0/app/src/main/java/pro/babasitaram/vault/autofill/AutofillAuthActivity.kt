package pro.babasitaram.vault.autofill

import pro.babasitaram.vault.presentation.components.PasswordField
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.autofill.AutofillId
import android.view.autofill.AutofillManager
import android.view.inputmethod.InlineSuggestionsRequest
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.core.content.IntentCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.autofill.model.AutofillField
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.autofill.model.ParsedStructure
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAvailability
import pro.babasitaram.vault.core.security.ScreenshotGuard
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.UnlockVaultUseCase
import pro.babasitaram.vault.presentation.theme.VaultTheme
import pro.babasitaram.vault.presentation.util.toUserMessage

/**
 * Opened by the autofill framework when the user taps "Unlock BSRPRO Vault" in the suggestion list.
 * Biometric prompt first (when enabled); falls back to a master-password dialog.
 * On success it returns a FillResponse with the matching datasets.
 */
@AndroidEntryPoint
class AutofillAuthActivity : FragmentActivity() {

    @Inject lateinit var biometric: BiometricAuthenticator
    @Inject lateinit var auth: AuthRepository
    @Inject lateinit var settings: SettingsRepository
    @Inject lateinit var unlockVault: UnlockVaultUseCase
    @Inject lateinit var session: SessionKeyStore
    @Inject lateinit var repository: VaultRepository
    @Inject lateinit var factory: AutofillDatasetFactory

    data class Choice(val entryId: String, val title: String, val subtitle: String, val related: Boolean)

    data class AuthUi(
        val showPassword: Boolean = false,
        val busy: Boolean = false,
        val error: String? = null,
        val choices: List<Choice> = emptyList(),
        val notice: String? = null
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val ui = MutableStateFlow(AuthUi())
    private var parsed: ParsedStructure? = null
    private var inlineRequest: InlineSuggestionsRequest? = null
    private var candidates: List<EntryMatch> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ScreenshotGuard.enable(this)
        parsed = readRequest(intent)
        if (parsed == null) {
            AutofillDiagnostics.record("A0 auth activity: unreadable request")
            cancelAndFinish()
            return
        }
        parsed?.let {
            AutofillDiagnostics.record(
                "A1 auth activity started",
                "pkg=${it.packageName} domain=${it.webDomain ?: "-"} fields=${it.fields.size} unlocked=${session.isUnlocked.value}"
            )
        }
        setContent {
            VaultTheme(darkTheme = isSystemInDarkTheme()) {
                val state by ui.collectAsStateWithLifecycle()
                if (state.showPassword) {
                    PasswordDialog(state = state, onSubmit = ::submitPassword, onCancel = ::cancelAndFinish)
                }
                if (state.choices.isNotEmpty()) {
                    ChoiceDialog(state.choices, onPick = ::pick, onCancel = ::cancelAndFinish)
                }
                state.notice?.let { NoticeDialog(it, onClose = ::cancelAndFinish) }
            }
        }
        scope.launch { start() }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun start() {
        if (session.isUnlocked.value) {
            deliver()
            return
        }
        val cfg = settings.current()
        val biometricUsable = cfg.biometricEnabled && auth.hasBiometricCredential() &&
            biometric.availability() == BiometricAvailability.Available
        if (!biometricUsable) {
            ui.update { it.copy(showPassword = true) }
            return
        }
        biometric.authenticate(this, "Unlock BSRPRO Vault", "Confirm it's you to autofill").collect { result ->
            when (result) {
                is AuthResult.Success -> unlockWithStoredCredential()
                AuthResult.Cancelled -> cancelAndFinish()
                is AuthResult.Error -> ui.update { it.copy(showPassword = true, error = result.message) }
                AuthResult.Failed -> Unit
            }
        }
    }

    private suspend fun unlockWithStoredCredential() {
        val pw = auth.loadBiometricCredential()
        if (pw == null) {
            ui.update { it.copy(showPassword = true) }
            return
        }
        try {
            unlockWith(pw)
        } finally {
            pw.fill('\u0000')
        }
    }

    private fun submitPassword(password: String) {
        val pw = password.toCharArray()
        scope.launch {
            ui.update { it.copy(busy = true, error = null) }
            try {
                unlockWith(pw)
            } finally {
                pw.fill('\u0000')
                ui.update { it.copy(busy = false) }
            }
        }
    }

    private suspend fun unlockWith(pw: CharArray) {
        when (val r = unlockVault(pw)) {
            is VaultResult.Success -> deliver()
            is VaultResult.Failure -> {
                if (r.error == VaultError.InvalidMasterPassword && settings.current().biometricEnabled) {
                    // master password changed since biometrics were enabled
                    auth.clearBiometricCredential()
                    settings.update { it.copy(biometricEnabled = false) }
                }
                ui.update { it.copy(showPassword = true, error = r.error.toUserMessage()) }
            }
            VaultResult.Loading -> Unit
        }
    }

    private fun deliver() {
        val p = parsed ?: return cancelAndFinish()
        var matches = AutofillMatcher.match(repository.entries.value, p.packageName, p.webDomain)
        if (p.isOtpOnly) matches = matches.filter { it.entry.totp.isNotBlank() }
        candidates = matches
        AutofillDiagnostics.record(
            "A2 after unlock",
            "entries=${repository.entries.value.size} matches=${matches.size} for ${p.webDomain ?: p.packageName}"
        )
        when {
            matches.isEmpty() -> {
                ui.update {
                    it.copy(
                        showPassword = false, busy = false,
                        notice = "No saved login for this " + (if (p.webDomain != null) "website" else "app") +
                            ". Open BSRPRO Vault, add one and link it to this " + (if (p.webDomain != null) "site" else "app") + "."
                    )
                }
            }
            // a single exact match is filled straight away; anything else is confirmed by the user
            matches.size == 1 && matches[0].kind == MatchKind.EXACT -> returnDataset(matches[0])
            else -> ui.update {
                it.copy(
                    showPassword = false, busy = false,
                    choices = matches.map { m ->
                        Choice(
                            entryId = m.entry.id,
                            title = m.entry.title.ifBlank { m.entry.appName.ifBlank { m.entry.url.ifBlank { "BSRPRO" } } },
                            subtitle = m.entry.username.ifEmpty { m.entry.email.ifEmpty { m.entry.mobile } },
                            related = m.kind == MatchKind.RELATED
                        )
                    }
                )
            }
        }
    }

    private fun pick(entryId: String) {
        val m = candidates.firstOrNull { it.entry.id == entryId } ?: return cancelAndFinish()
        returnDataset(m)
    }

    /** Returns ONE dataset built from the ids the framework gave us — they are never rebuilt or filtered. */
    private fun returnDataset(m: EntryMatch) {
        val p = parsed ?: return cancelAndFinish()
        val dataset = factory.datasetFor(p, m, System.currentTimeMillis())
        if (dataset == null) {
            AutofillDiagnostics.record("A3 dataset EMPTY", "entry has no value for the detected fields")
            ui.update { it.copy(choices = emptyList(), notice = "This entry has nothing to fill in these fields.") }
            return
        }
        AutofillDiagnostics.record("A3 returning dataset", "fields=${p.fillableFields.size} kind=${m.kind}")
        setResult(RESULT_OK, Intent().putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, dataset))
        finish()
    }

    private fun cancelAndFinish() {
        AutofillDiagnostics.record("A4 auth cancelled/closed")
        setResult(RESULT_CANCELED)
        finish()
    }

    private fun readRequest(intent: Intent): ParsedStructure? {
        val ids = IntentCompat.getParcelableArrayListExtra(intent, EXTRA_IDS, AutofillId::class.java) ?: return null
        val types = intent.getStringArrayExtra(EXTRA_TYPES) ?: return null
        if (ids.isEmpty() || ids.size != types.size) return null
        val fields = ids.mapIndexedNotNull { i, id ->
            val type = runCatching { AutofillFieldType.valueOf(types[i]) }.getOrNull() ?: return@mapIndexedNotNull null
            AutofillField(id, type)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            inlineRequest = IntentCompat.getParcelableExtra(intent, EXTRA_INLINE, InlineSuggestionsRequest::class.java)
        }
        return ParsedStructure(
            packageName = intent.getStringExtra(EXTRA_PACKAGE).orEmpty(),
            webDomain = intent.getStringExtra(EXTRA_DOMAIN),
            webScheme = intent.getStringExtra(EXTRA_SCHEME),
            fields = fields
        )
    }

    companion object {
        const val EXTRA_IDS = "pro.babasitaram.vault.autofill.IDS"
        const val EXTRA_TYPES = "pro.babasitaram.vault.autofill.TYPES"
        const val EXTRA_PACKAGE = "pro.babasitaram.vault.autofill.PACKAGE"
        const val EXTRA_DOMAIN = "pro.babasitaram.vault.autofill.DOMAIN"
        const val EXTRA_SCHEME = "pro.babasitaram.vault.autofill.SCHEME"
        const val EXTRA_INLINE = "pro.babasitaram.vault.autofill.INLINE"
    }
}

@Composable
private fun PasswordDialog(state: AutofillAuthActivity.AuthUi, onSubmit: (String) -> Unit, onCancel: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Unlock BSRPRO Vault") },
        text = {
            Column {
                PasswordField(value = pw, onValueChange = { pw = it }, label = "Master password", enabled = !state.busy)
                state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSubmit(pw); pw = "" }, enabled = pw.isNotEmpty() && !state.busy) { Text("Unlock") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

@Composable
private fun ChoiceDialog(choices: List<AutofillAuthActivity.Choice>, onPick: (String) -> Unit, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Choose a login") },
        text = {
            androidx.compose.foundation.lazy.LazyColumn {
                items(choices.size) { i ->
                    val c = choices[i]
                    TextButton(onClick = { onPick(c.entryId) }, modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
                        Column(androidx.compose.ui.Modifier.fillMaxWidth()) {
                            Text(c.title)
                            val sub = (if (c.related) "\u26A0 related site \u2022 " else "") + c.subtitle
                            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

@Composable
private fun NoticeDialog(message: String, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Nothing to fill") },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onClose) { Text("OK") } }
    )
}
