package pro.babasitaram.vault.data.transfer

import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.util.IdGenerator
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.core.util.VaultError

class ParsedImport(val format: ImportFormat, val entries: List<VaultEntry>, val skippedRows: Int)

/** Parses third-party exports. Limits mirror the browser extension (25 MB, 10 000 entries). */
object ImportParser {
    const val MAX_CHARS = 25 * 1024 * 1024
    const val MAX_ENTRIES = 10_000
    private const val MAX_FIELD_CHARS = 1_000_000

    private val BASE64_BLOB = Regex("^[A-Za-z0-9+/]+={0,2}$")

    fun detectKind(raw: String): SourceKind {
        val t = raw.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        if (t.isBlank()) return SourceKind.UNKNOWN
        return when {
            t.startsWith("{") && t.contains("\"BSRPRO.Vault\"") -> SourceKind.V3_BACKUP
            t.startsWith("{") && t.contains("\"entries\"") -> SourceKind.PLAIN_JSON
            t.take(11).equals("BEGIN:VCARD", ignoreCase = true) -> SourceKind.VCARD
            t.length >= 60 && '\n' !in t.trim() && BASE64_BLOB.matches(t.trim()) -> SourceKind.DEVICE_BACKUP
            else -> SourceKind.CSV
        }
    }

    // ───────────────────────── CSV ─────────────────────────

    fun parseCsv(text: String, now: Long = System.currentTimeMillis()): ParsedImport {
        if (text.length > MAX_CHARS) throw VaultError.Validation("Import file is too large (max 25 MB).")
        val rows = Csv.parse(text)
        if (rows.size < 2) throw VaultError.Validation("The file is empty or has no data rows.")
        val header = rows[0].map { it.trim().lowercase() }
        val cols = Columns(header)
        if (cols.password < 0) throw VaultError.Validation("Password column not found. The CSV must contain a \"password\" header.")
        val format = detectFormat(header)

        val out = ArrayList<VaultEntry>()
        var skipped = 0
        for (r in rows.drop(1)) {
            if (cols.type >= 0) {
                val type = cols.get(r, cols.type).trim().lowercase()
                if (type.isNotEmpty() && type != "login") { skipped++; continue }
            }
            val password = cols.get(r, cols.password)                  // never trimmed
            val rawAppPin = cols.get(r, cols.appPin)
            if (rawAppPin.isNotBlank() && (rawAppPin.length !in 4..6 || rawAppPin.any { it !in '0'..'9' })) {
                throw VaultError.Validation("Imported app PIN must contain 4 to 6 digits.")
            }
            val appPin = rawAppPin
            val username = cols.get(r, cols.username).trim()
            val mobile = cols.get(r, cols.mobile).trim()
            val totp = cols.get(r, cols.totp).trim()
            val url = cols.get(r, cols.url).trim()
            if (password.isEmpty() && appPin.isEmpty() && username.isEmpty() && mobile.isEmpty() && totp.isEmpty()) { skipped++; continue }
            if (listOf(password, appPin, username, url, totp).any { it.length > MAX_FIELD_CHARS }) {
                throw VaultError.Validation("Import contains an oversized field.")
            }
            if (out.size >= MAX_ENTRIES) throw VaultError.Validation("Import contains too many entries (max 10,000).")
            val created = cols.get(r, cols.createdAt).trim().toLongOrNull() ?: now
            val updated = cols.get(r, cols.updatedAt).trim().toLongOrNull() ?: now
            out.add(
                VaultEntry(
                    id = IdGenerator.newId(now),
                    title = cols.get(r, cols.title).trim().ifEmpty { titleFromUrl(url) }.ifEmpty { if (username.isNotEmpty()) "Imported Login" else "Imported Entry" },
                    url = url,
                    username = username,
                    password = password,
                    appPin = appPin,
                    mobile = mobile,
                    notes = cols.get(r, cols.notes).trim(),
                    totp = totp,
                    starred = cols.get(r, cols.starred).trim().let { it == "1" || it.equals("true", true) },
                    strength = if (password.isEmpty()) "" else PasswordStrength.bucket(password),
                    createdAt = created,
                    updatedAt = updated
                )
            )
        }
        return ParsedImport(format, out, skipped)
    }

    private fun detectFormat(h: List<String>): ImportFormat = when {
        "login_uri" in h && "login_username" in h -> ImportFormat.BITWARDEN
        "grouping" in h && "extra" in h -> ImportFormat.LASTPASS
        "httprealm" in h -> ImportFormat.FIREFOX
        "mobile" in h && "name" in h && ("strength" in h || "starred" in h) -> ImportFormat.VAULT_CSV
        "group" in h && "title" in h -> ImportFormat.KEEPASS
        "login name" in h || "web site" in h -> ImportFormat.KEEPASS
        "otpsecret" in h || "username2" in h -> ImportFormat.DASHLANE
        "otpauth" in h || ("title" in h && "type" in h) -> ImportFormat.ONEPASSWORD
        h.take(4) == listOf("name", "url", "username", "password") -> ImportFormat.CHROME
        else -> ImportFormat.GENERIC
    }

    /** Header → column index, with synonyms. Exact header matches win over "contains" matches. */
    private class Columns(private val header: List<String>) {
        val title = find("name", "title", "site", "service", "account")
        val url = find("url", "website", "web site", "origin", "uri", "domain", "hostname")
        val username = find("username", "user", "login", "email")
        val password = find("password", "pass", "pwd", "secret")
        val appPin = findExact("app_pin", "apppin", "pin")
        val notes = find("notes", "note", "comment", "extra", "description")
        val totp = find("totp", "otpsecret", "otpauth", "otp", "one-time password")
        val mobile = find("mobile", "phone", "contact")
        val type = findExact("type")
        val starred = findExact("starred", "favorite", "fav")
        val createdAt = findExact("createdat")
        val updatedAt = findExact("updatedat")

        fun get(r: List<String>, idx: Int): String = if (idx in r.indices) r[idx] else ""

        private fun findExact(vararg names: String): Int {
            for (n in names) header.indexOf(n).let { if (it >= 0) return it }
            return -1
        }

        private fun find(vararg names: String): Int {
            val exact = findExact(*names)
            if (exact >= 0) return exact
            for (n in names) {
                val i = header.indexOfFirst { it.contains(n) }
                if (i >= 0) return i
            }
            return -1
        }
    }

    private fun titleFromUrl(url: String): String =
        UrlUtils.domainOf(url).substringBefore('.').replaceFirstChar { it.uppercase() }

    // ───────────────────────── vCard ─────────────────────────

    fun parseVCard(text: String, now: Long = System.currentTimeMillis()): ParsedImport {
        if (text.length > MAX_CHARS) throw VaultError.Validation("Import file is too large (max 25 MB).")
        val cards = Regex("BEGIN:VCARD", RegexOption.IGNORE_CASE).split(text).drop(1)
        val out = ArrayList<VaultEntry>()
        for (card in cards) {
            val fn = vField(card, "FN")
            val n = vField(card, "N").replace(Regex(";+"), " ").trim()
            val mobile = vField(card, "TEL").replace(Regex("[\\s\\-().+]"), "")
            val email = vField(card, "EMAIL")
            val url = vField(card, "URL")
            val notes = vField(card, "NOTE")
            val title = fn.ifEmpty { n }
            if (title.isEmpty() && mobile.isEmpty() && email.isEmpty()) continue
            if (out.size >= MAX_ENTRIES) throw VaultError.Validation("Import contains too many entries (max 10,000).")
            out.add(
                VaultEntry(
                    id = IdGenerator.newId(now),
                    title = title.ifEmpty { mobile.ifEmpty { email } },
                    url = url, username = email, mobile = mobile, notes = notes,
                    createdAt = now, updatedAt = now
                )
            )
        }
        if (out.isEmpty()) throw VaultError.Validation("No valid contacts were found in the vCard file.")
        return ParsedImport(ImportFormat.VCARD, out, 0)
    }

    private fun vField(card: String, key: String): String {
        val re = Regex("^$key(?:;[^:\\r\\n]*)?:(.+)$", setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE))
        return re.find(card)?.groupValues?.get(1)?.replace("\r", "")?.trim().orEmpty()
    }

    // ───────────────────────── plain JSON ─────────────────────────

    fun parsePlainJson(text: String, now: Long = System.currentTimeMillis()): ParsedImport {
        if (text.length > MAX_CHARS) throw VaultError.Validation("Import file is too large (max 25 MB).")
        val root = try {
            VaultJson.parseToJsonElement(text) as? kotlinx.serialization.json.JsonObject
        } catch (e: Exception) {
            null
        } ?: throw VaultError.InvalidFormat("Not a JSON object")
        val arr = root["entries"] as? kotlinx.serialization.json.JsonArray ?: throw VaultError.InvalidFormat("Missing entries array")
        if (arr.size > MAX_ENTRIES) throw VaultError.Validation("Import contains too many entries (max 10,000).")
        val entries = try {
            arr.map { VaultJson.decodeFromJsonElement(VaultEntry.serializer(), it) }
        } catch (e: Exception) {
            throw VaultError.InvalidFormat("Malformed entry")
        }
        val fixed = entries.map { e ->
            e.copy(
                id = IdGenerator.newId(now),
                title = e.title.ifBlank { titleFromUrl(e.url).ifEmpty { "Imported Entry" } },
                createdAt = if (e.createdAt > 0) e.createdAt else now,
                updatedAt = if (e.updatedAt > 0) e.updatedAt else now
            )
        }
        return ParsedImport(ImportFormat.JSON, fixed, 0)
    }
}
