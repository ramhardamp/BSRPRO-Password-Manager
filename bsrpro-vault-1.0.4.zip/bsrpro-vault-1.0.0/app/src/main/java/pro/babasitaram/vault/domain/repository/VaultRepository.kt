package pro.babasitaram.vault.domain.repository

import kotlinx.coroutines.flow.StateFlow
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry

interface VaultRepository {
    /** Visible entries (folder marker records are hidden but preserved on disk). */
    val entries: StateFlow<List<VaultEntry>>
    val folders: StateFlow<List<Folder>>

    fun entry(id: String): VaultEntry?
    fun findDuplicate(candidate: VaultEntry): VaultEntry?

    /** Replace the in-memory vault after unlock/create/restore (does not write to disk). */
    suspend fun setData(data: VaultData)

    suspend fun upsert(entry: VaultEntry)

    /** One disk write for many entries (import). Folders that are not present yet are added. */
    suspend fun upsertAll(entries: List<VaultEntry>, folders: List<Folder> = emptyList()) {
        entries.forEach { upsert(it) }
    }
    suspend fun delete(id: String)

    /** Drop everything from memory + metadata DB (called on lock). */
    suspend fun clear()
}
