package pro.babasitaram.vault.autofill

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.util.LruCache
import android.graphics.drawable.BitmapDrawable
import android.content.IntentSender
import android.os.Build
import android.service.autofill.Dataset
import android.service.autofill.FillResponse
import android.service.autofill.InlinePresentation
import android.service.autofill.SaveInfo
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.view.inputmethod.InlineSuggestionsRequest
import android.widget.RemoteViews
import android.widget.inline.InlinePresentationSpec
import androidx.annotation.RequiresApi
import androidx.autofill.inline.UiVersions
import androidx.autofill.inline.v1.InlineSuggestionUi
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton
import pro.babasitaram.vault.MainActivity
import pro.babasitaram.vault.R
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.autofill.model.ParsedStructure

internal data class AutofillPalette(val background: Int, val primary: Int, val secondary: Int) {
    companion object {
        fun forNight(night: Boolean) = if (night) {
            AutofillPalette(0xFF211B31.toInt(), 0xFFF3EDFF.toInt(), 0xFFD0C4E4.toInt())
        } else {
            AutofillPalette(0xFFFFFBFF.toInt(), 0xFF241B35.toInt(), 0xFF62576F.toInt())
        }
    }
}

/** Builds the datasets / responses the autofill framework shows to the user. */
@Singleton
class AutofillDatasetFactory @Inject constructor(@ApplicationContext private val context: Context) {

    private val requestCodes = AtomicInteger(1)
    private val appIconCache = LruCache<String, Bitmap>(48)

    /** Suggestions for the unlocked vault (+ save info so a new login can be saved afterwards). */
    @Suppress("DEPRECATION")
    fun unlockedResponse(
        parsed: ParsedStructure,
        matches: List<EntryMatch>,
        inlineRequest: InlineSuggestionsRequest?,
        nowMs: Long
    ): FillResponse? {
        val builder = FillResponse.Builder()
        val limit = inlineLimit(inlineRequest)
        var added = 0
        for (m in matches) {
            if (added >= limit) break
            val dataset = dataset(parsed, m, specAt(inlineRequest, added), nowMs) ?: continue
            builder.addDataset(dataset)
            added++
        }
        val save = saveInfo(parsed)
        if (save != null) builder.setSaveInfo(save)
        AutofillDiagnostics.record("4 datasets", "$added built, saveInfo=${save != null}")
        return if (added > 0 || save != null) builder.build() else null
    }

    /**
     * One "Unlock BSRPRO Vault" entry that uses DATASET authentication: the placeholder dataset holds the ids
     * of every fillable field with null values. When the auth activity returns a real [Dataset] for the same
     * ids the framework fills the form immediately — no second tap (response-level authentication would
     * only re-show the suggestion list and often fills nothing).
     */
    @Suppress("DEPRECATION")
    fun lockedResponse(parsed: ParsedStructure, authSender: IntentSender, inlineRequest: InlineSuggestionsRequest?): FillResponse {
        val title = context.getString(R.string.autofill_unlock_title)
        val subtitle = context.getString(R.string.autofill_unlock_subtitle)
        val builder = Dataset.Builder(remoteViews(title, subtitle))
        for (f in parsed.fillableFields) builder.setValue(f.id, null)
        val spec = specAt(inlineRequest, 0)
        if (spec != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                inlinePresentation(spec, title, subtitle)?.let { builder.setInlinePresentation(it) }
            } catch (e: Exception) {
                AutofillDiagnostics.record("inline presentation FAILED", e.javaClass.simpleName)
            }
        }
        builder.setAuthentication(authSender)
        AutofillDiagnostics.record("4 locked dataset", "placeholder for ${parsed.fillableFields.size} field(s)")
        return FillResponse.Builder().addDataset(builder.build()).build()
    }

    /** The real dataset returned by the auth activity after unlock (same AutofillIds as the placeholder). */
    fun datasetFor(parsed: ParsedStructure, match: EntryMatch, nowMs: Long): Dataset? =
        dataset(parsed, match, null, nowMs)

    /** IntentSender that opens [AutofillAuthActivity]; the framework fills in the result extra, so the intent is mutable. */
    fun authSender(parsed: ParsedStructure, inlineRequest: InlineSuggestionsRequest?): IntentSender {
        val intent = Intent(context, AutofillAuthActivity::class.java).apply {
            putParcelableArrayListExtra(AutofillAuthActivity.EXTRA_IDS, ArrayList<AutofillId>(parsed.fillableFields.map { it.id }))
            putExtra(AutofillAuthActivity.EXTRA_TYPES, parsed.fillableFields.map { it.type.name }.toTypedArray())
            putExtra(AutofillAuthActivity.EXTRA_PACKAGE, parsed.packageName)
            putExtra(AutofillAuthActivity.EXTRA_DOMAIN, parsed.webDomain)
            putExtra(AutofillAuthActivity.EXTRA_SCHEME, parsed.webScheme)
            if (inlineRequest != null) putExtra(AutofillAuthActivity.EXTRA_INLINE, inlineRequest)
        }
        var flags = PendingIntent.FLAG_CANCEL_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) flags = flags or PendingIntent.FLAG_MUTABLE
        return PendingIntent.getActivity(context, requestCodes.getAndIncrement(), intent, flags).intentSender
    }

    // ───────────────────────── internals ─────────────────────────

    @Suppress("DEPRECATION")
    private fun dataset(parsed: ParsedStructure, m: EntryMatch, spec: InlinePresentationSpec?, nowMs: Long): Dataset? {
        val values = parsed.fillableFields.mapNotNull { f ->
            AutofillValues.valueFor(f.type, m.entry, nowMs).takeIf { it.isNotEmpty() }?.let { f to it }
        }
        AutofillDiagnostics.record(
            "4 dataset values",
            values.groupingBy { it.first.type.name }.eachCount().entries.joinToString(", ") { "${it.key}x${it.value}" }.ifEmpty { "none" }
        )
        if (values.isEmpty()) return null
        val resolvedAppName = resolveAppName(m.entry.appName, m.entry.appPackage)
        val title = if (m.entry.appPackage.isNotBlank()) resolvedAppName
            else m.entry.title.ifBlank { m.entry.url.ifBlank { resolvedAppName } }.ifBlank { "BSRPRO" }
        val subtitle = subtitle(parsed, m)
        val presentationTitle = if (parsed.pinFields.isNotEmpty() && m.entry.appPin.isNotEmpty()) "$title · PIN available" else title
        val inlineSubtitle = subtitle.orEmpty()
        val builder = Dataset.Builder(remoteViews(presentationTitle, subtitle, m.entry.appPackage, resolvedAppName))
        for ((f, v) in values) builder.setValue(f.id, AutofillValue.forText(v))
        if (spec != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                inlinePresentation(spec, presentationTitle, inlineSubtitle)?.let { builder.setInlinePresentation(it) }
            } catch (e: Exception) {
                // the classic dropdown below still works even if the keyboard strip cannot be built
                AutofillDiagnostics.record("inline presentation FAILED", e.javaClass.simpleName)
            }
        }
        return builder.build()
    }

    private fun subtitle(parsed: ParsedStructure, m: EntryMatch): String {
        val base = if (parsed.isOtpOnly) context.getString(R.string.autofill_one_time_code)
        else m.entry.username.ifEmpty { m.entry.email.ifEmpty { m.entry.mobile } }
        return if (m.kind == MatchKind.RELATED) "\u26A0 ${context.getString(R.string.autofill_related_site)} \u2022 $base" else base
    }

    private fun remoteViews(title: String, subtitle: String?, appPackage: String = "", appName: String = ""): RemoteViews {
        val night = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val palette = AutofillPalette.forNight(night)
        return RemoteViews(context.packageName, R.layout.autofill_item).apply {
            setTextViewText(R.id.autofill_title, title)
            setTextViewText(R.id.autofill_subtitle, subtitle.orEmpty())
            setTextColor(R.id.autofill_title, palette.primary)
            setTextColor(R.id.autofill_subtitle, palette.secondary)
            val icon = if (appPackage.isNotBlank()) appIconCache.get(appPackage) ?: runCatching {
                drawableBitmap(context.packageManager.getApplicationIcon(appPackage)).also { appIconCache.put(appPackage, it) }
            }.getOrNull() else null
            val displayIcon = icon ?: alphabetAvatar(appName.ifBlank { appPackage })
            setImageViewBitmap(R.id.autofill_icon, displayIcon)
        }
    }

    private fun resolveAppName(savedName: String, packageName: String): String {
        if (savedName.isNotBlank()) return savedName
        if (packageName.isBlank()) return "BSRPRO"
        return runCatching {
            val info = context.packageManager.getApplicationInfo(packageName, 0)
            context.packageManager.getApplicationLabel(info).toString().ifBlank { packageName }
        }.getOrDefault(packageName.substringAfterLast('.').replaceFirstChar { it.uppercase() })
    }

    private fun alphabetAvatar(label: String): Bitmap {
        val bitmap = Bitmap.createBitmap(144, 144, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6750A4.toInt() }
        canvas.drawCircle(72f, 72f, 72f, bg)
        val text = label.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "B"
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt(); textSize = 76f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        }
        canvas.drawText(text, 72f, 99f, paint)
        return bitmap
    }

    private fun drawableBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) return drawable.bitmap
        val sourceW = drawable.intrinsicWidth.coerceAtLeast(1)
        val sourceH = drawable.intrinsicHeight.coerceAtLeast(1)
        val scale = minOf(1f, 144f / sourceW, 144f / sourceH)
        val w = (sourceW * scale).toInt().coerceAtLeast(1)
        val h = (sourceH * scale).toInt().coerceAtLeast(1)
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bitmap ->
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
        }
    }

    private fun saveInfo(parsed: ParsedStructure): SaveInfo? {
        val secretFields = parsed.secretFields
        if (secretFields.isEmpty()) return null
        val primary = secretFields.firstOrNull { it.type == AutofillFieldType.PASSWORD || it.type == AutofillFieldType.PIN }
            ?: secretFields.first()
        val optional = (secretFields.filterNot { it.id == primary.id } + parsed.usernameFields).map { it.id }.distinct()
        val type = if (parsed.usernameFields.isEmpty()) SaveInfo.SAVE_DATA_TYPE_PASSWORD
        else SaveInfo.SAVE_DATA_TYPE_PASSWORD or SaveInfo.SAVE_DATA_TYPE_USERNAME
        val b = SaveInfo.Builder(type, arrayOf(primary.id))
        if (optional.isNotEmpty()) b.setOptionalIds(optional.toTypedArray())
        b.setFlags(SaveInfo.FLAG_SAVE_ON_ALL_VIEWS_INVISIBLE)
        return b.build()
    }

    private fun inlineLimit(req: InlineSuggestionsRequest?): Int {
        if (req == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return MAX_DATASETS
        return req.maxSuggestionCount.coerceIn(1, MAX_DATASETS)
    }

    private fun specAt(req: InlineSuggestionsRequest?, index: Int): InlinePresentationSpec? {
        if (req == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val specs = req.inlinePresentationSpecs
        if (specs.isEmpty()) return null
        return specs[minOf(index, specs.lastIndex)]
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun inlinePresentation(spec: InlinePresentationSpec, title: String, subtitle: String?): InlinePresentation? {
        if (!UiVersions.getVersions(spec.style).contains(UiVersions.INLINE_UI_VERSION_1)) return null
        val attribution = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val content = InlineSuggestionUi.newContentBuilder(attribution)
            .setTitle(title)
            .apply { if (!subtitle.isNullOrEmpty()) setSubtitle(subtitle) }
            .build()
        return InlinePresentation(content.slice, spec, false)
    }

    companion object {
        const val MAX_DATASETS = 10
    }
}
