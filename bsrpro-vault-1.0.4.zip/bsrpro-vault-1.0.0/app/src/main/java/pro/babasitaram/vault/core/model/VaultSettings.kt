package pro.babasitaram.vault.core.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Launcher icon colour. [aliasName] is the <activity-alias> in the manifest (relative to the app namespace). */
enum class AppIconColor(val aliasName: String, val label: String) {
    PURPLE("IconPurple", "Purple"),
    TEAL("IconTeal", "Teal"),
    ORANGE("IconOrange", "Orange"),
    BLUE("IconBlue", "Blue")
}

data class VaultSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    /** Seconds in background before locking. 0 = immediately, [AUTO_LOCK_NEVER] = never. */
    val autoLockSeconds: Int = 60,
    /** Seconds until the clipboard is wiped. 0 = never. */
    val clipboardClearSeconds: Int = 30,
    val biometricEnabled: Boolean = false,
    val lockOnBackground: Boolean = true,
    val generatorDefaultLength: Int = 20,
    val generatorKeyword: String = "",
    val travelMode: Boolean = false,
    val autofillInline: Boolean = false,
    val generatorExcludeSimilar: Boolean = false,
    val appIcon: AppIconColor = AppIconColor.PURPLE,
    val autoBackupEnabled: Boolean = false,
    val lastAutoBackupAt: Long = 0L
) {
    companion object {
        const val AUTO_LOCK_NEVER = -1
    }
}
