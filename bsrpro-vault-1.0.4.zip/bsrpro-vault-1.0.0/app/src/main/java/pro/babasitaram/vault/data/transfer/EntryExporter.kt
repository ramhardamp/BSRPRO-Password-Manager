package pro.babasitaram.vault.data.transfer

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.model.VaultPayload

/** Keeps standard columns intact and appends app_pin so BSRPRO round-trips native PINs. */
object EntryExporter {
    private val APP_PACKAGE = Regex("^[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+$")

    fun vaultCsv(entries: List<VaultEntry>): String =
        "name,url,username,mobile,password,notes,strength,starred,createdAt,updatedAt,app_pin\n" +
            entries.joinToString("\n") {
                Csv.row(it.title, it.url, it.username, it.mobile, it.password, it.notes, it.strength, if (it.starred) "1" else "0", it.createdAt.toString(), it.updatedAt.toString(), it.appPin)
            }

    fun chromeCsv(entries: List<VaultEntry>): String =
        "name,url,username,password,app_pin\n" + entries.joinToString("\n") { Csv.row(it.title, it.url, it.username, it.password, it.appPin) }

    fun bitwardenCsv(entries: List<VaultEntry>): String =
        "folder,favorite,type,name,notes,fields,reprompt,login_uri,login_username,login_password,login_totp,app_pin\n" +
            entries.joinToString("\n") {
                Csv.row("", if (it.starred) "1" else "0", "login", it.title, it.notes, "", "0", it.url, it.username, it.password, it.totp, it.appPin)
            }

    fun plainJson(entries: List<VaultEntry>, nowMs: Long): String {
        val obj: JsonObject = buildJsonObject {
            put("version", "1.0")
            put("app", "BabaSitaRam Pro")
            put("warning", "UNENCRYPTED EXPORT \u2014 store securely")
            put("exportDate", java.time.Instant.ofEpochMilli(nowMs).toString())
            put("count", entries.size)
            put("entries", JsonArray(entries.map { VaultJson.encodeToJsonElement(VaultEntry.serializer(), it) }))
        }
        return Json { prettyPrint = true }.encodeToString(JsonObject.serializer(), obj)
    }

    /** V3 container with the extension's auto-backup payload; entries are sanitised so the extension's validator accepts them. */
    suspend fun v3(data: VaultData, password: CharArray): String {
        val folderIds = data.folders.map { it.id }.toSet()
        val entries = data.entries.map { e ->
            e.copy(
                folderId = if (e.folderId.isNotBlank() && e.folderId !in folderIds) "" else e.folderId,
                appPackage = if (e.appPackage.isNotBlank() && !APP_PACKAGE.matches(e.appPackage.trim())) "" else e.appPackage
            )
        }
        val json = VaultJson.encodeToString(VaultPayload.serializer(), VaultPayload(entries = entries, folders = data.folders))
        return VaultCrypto.encryptV3(json, password)
    }

    fun fileName(format: ExportFormat, date: String): String = when (format) {
        ExportFormat.V3 -> "BSRPRO_Backup_$date.Vault"
        ExportFormat.VAULT_CSV -> "BSRPRO_Vault_$date.csv"
        ExportFormat.CHROME_CSV -> "BSRPRO_chrome_$date.csv"
        ExportFormat.BITWARDEN_CSV -> "BSRPRO_bitwarden_$date.csv"
        ExportFormat.PLAIN_JSON -> "BSRPRO_plain_$date.json"
    }
}
