package pro.babasitaram.vault.data.backup

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.nio.file.AtomicMoveNotSupportedException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.data.transfer.EntryExporter
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.BuildExportUseCase
import timber.log.Timber

/**
 * V3 backup to Downloads/BSRPRO_Backups/BSRPRO.Vault. Legacy dated backups are removed only after a new backup is safely written.
 *
 * A V3 file is encrypted with the master password, which only exists in memory while the vault is unlocked.
 * So the daily worker backs up when the vault is unlocked and otherwise does nothing; [runIfDue] is also
 * called whenever the vault is unlocked, so a missed day is caught up at the next unlock.
 */
@Singleton
class AutoBackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val buildExport: BuildExportUseCase
) {
    internal var clock: () -> Long = { System.currentTimeMillis() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var debounceJob: Job? = null
    private val pendingPrefs by lazy { context.getSharedPreferences(PENDING_PREFS, Context.MODE_PRIVATE) }

    /** Persist the request first, then coalesce rapid changes into one encrypted V3 write. */
    fun requestBackup() {
        // Persist first, so process death or a lock during the debounce cannot silently drop the request.
        pendingPrefs.edit().putBoolean(KEY_PENDING, true).apply()
        if (!session.isUnlocked.value) return
        debounceJob?.cancel()
        debounceJob = scope.launch {
            delay(DEBOUNCE_MS)
            when (backupNow()) {
                is VaultResult.Success -> pendingPrefs.edit().remove(KEY_PENDING).apply()
                else -> Timber.w("backup remains pending for next unlock/retry")
            }
        }
    }

    suspend fun runPendingOrDue(): Boolean {
        if (!session.isUnlocked.value) return false
        val pending = pendingPrefs.getBoolean(KEY_PENDING, false)
        val done = if (pending) backupNow() is VaultResult.Success else runIfDue()
        if (done) pendingPrefs.edit().remove(KEY_PENDING).apply()
        return done
    }

    fun hasPendingBackup(): Boolean = pendingPrefs.getBoolean(KEY_PENDING, false)

    /** Locate the current automatic backup. On Android 10+ MediaStore content is copied to a
     * private cache file because a content:// row cannot be represented as a filesystem File.
     * On Android 8-9, check the public Downloads folder first, then this app's legacy app-scoped
     * Downloads location. Permission/provider failures are treated as not found. */
    fun findBackupFile(): File? = BackupFileDiscovery.safelyFind {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            findMediaStoreBackup()
        } else {
            val public = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "$FOLDER/$FINAL_NAME")
            val appScoped = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "$FOLDER/$FINAL_NAME")
            BackupFileDiscovery.firstExisting(listOf(public, appScoped))
        }
    }

    private fun findMediaStoreBackup(): File? {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/"
        val projection = arrayOf(MediaStore.MediaColumns._ID)
        val selection = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
        val uri = resolver.query(collection, projection, selection, arrayOf(FINAL_NAME, relative),
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")?.use { cursor ->
            if (!cursor.moveToFirst()) null else android.content.ContentUris.withAppendedId(
                collection, cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)))
        } ?: return null
        val destination = File(context.cacheDir, "discovered-${UUID.randomUUID()}.vault")
        return try {
            resolver.openInputStream(uri)?.use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            if (!destination.isFile || destination.length() == 0L) return null
            destination
        } catch (e: Exception) {
            destination.delete()
            throw e
        }
    }

    fun schedule() {
        val req = PeriodicWorkRequestBuilder<AutoBackupWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiresStorageNotLow(true).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel() {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }

    /** True once a calendar day has passed since the last successful backup. */
    suspend fun isDue(): Boolean {
        val s = settings.current()
        return s.autoBackupEnabled && dayKey(clock()) != dayKey(s.lastAutoBackupAt)
    }

    /** @return true if a backup file was written. */
    suspend fun runIfDue(): Boolean {
        if (!isDue() || !session.isUnlocked.value) return false
        val success = backupNow() is VaultResult.Success
        if (success) pendingPrefs.edit().remove(KEY_PENDING).apply()
        return success
    }

    suspend fun backupNow(): VaultResult<String> {
        if (!session.isUnlocked.value) return VaultResult.Failure(VaultError.VaultLocked)
        val text = when (val r = buildExport(ExportFormat.V3)) {
            is VaultResult.Success -> r.value
            is VaultResult.Failure -> return r
            VaultResult.Loading -> return VaultResult.Loading
        }
        return try {
            val where = withContext(Dispatchers.IO) { write(FINAL_NAME, text) }
            settings.update { it.copy(lastAutoBackupAt = clock()) }
            Timber.i("auto-backup written")
            VaultResult.Success(where)
        } catch (e: Exception) {
            Timber.w("auto-backup failed: %s", e.javaClass.simpleName)
            VaultResult.Failure(VaultError.IOError(e))
        }
    }

    private fun write(name: String, text: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val relative = "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/"
            val stagedName = ".BSRPRO-${UUID.randomUUID()}.pending"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, stagedName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val staged = resolver.insert(collection, values) ?: throw java.io.IOException("MediaStore insert failed")
            try {
                resolver.openOutputStream(staged, "w")?.use { it.write(text.toByteArray(Charsets.UTF_8)); it.flush() }
                    ?: throw java.io.IOException("open failed")
                val published = resolver.update(staged, ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                }, null, null)
                if (published <= 0) throw java.io.IOException("backup publish failed")
            } catch (e: Exception) {
                runCatching { resolver.delete(staged, null, null) }
                throw e
            }
            // New complete backup is visible now. Only then remove prior fixed/legacy files.
            val ids = mutableListOf<android.net.Uri>()
            resolver.query(collection, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.RELATIVE_PATH), null, null, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val pathCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                while (c.moveToNext()) {
                    val rowUri = android.content.ContentUris.withAppendedId(collection, c.getLong(idCol))
                    if (c.getString(pathCol) == relative && rowUri != staged &&
                        (c.getString(nameCol) == FINAL_NAME || AutoBackupNames.isLegacyDated(c.getString(nameCol)))) {
                        ids += rowUri
                    }
                }
            }
            ids.forEach { resolver.delete(it, null, null) }
            return "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER/$name"
        }
        // Android 8/9: use app-scoped external Downloads; no broad storage permission is requested.
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FOLDER).apply { mkdirs() }
        val target = File(dir, name)
        val temp = File(dir, ".$name.pending")
        FileOutputStream(temp).use { out ->
            out.write(text.toByteArray(Charsets.UTF_8))
            out.fd.sync()
        }
        try {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        dir.listFiles()?.filter { it.isFile && AutoBackupNames.isLegacyDated(it.name) }?.forEach { it.delete() }
        return target.absolutePath
    }

    private fun dayKey(ms: Long): String = if (ms <= 0) "" else SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ms))

    companion object {
        const val WORK_NAME = "bsrpro_auto_backup"
        const val FOLDER = "BSRPRO_Backups"
        const val FINAL_NAME = "BSRPRO.Vault"
        const val DEBOUNCE_MS = 2_500L
        private const val PENDING_PREFS = "bsrpro_backup_state"
        private const val KEY_PENDING = "pending_backup_v1"
    }
}

/** Naming/migration rules kept pure so legacy cleanup is unit-testable. */
internal object BackupFileDiscovery {
    fun firstExisting(candidates: List<File>): File? = candidates.firstOrNull { it.isFile && it.name == AutoBackupManager.FINAL_NAME }
    fun safelyFind(block: () -> File?): File? = try { block() } catch (_: SecurityException) { null } catch (_: java.io.IOException) { null }
}

internal object AutoBackupNames {
    private val legacy = Regex("vault_[0-9]{8}\\.Vault", RegexOption.IGNORE_CASE)
    fun isLegacyDated(name: String): Boolean = legacy.matches(name)
}

@EntryPoint
@InstallIn(SingletonComponent::class)
interface AutoBackupEntryPoint {
    fun autoBackupManager(): AutoBackupManager
}

class AutoBackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val manager = EntryPointAccessors.fromApplication(applicationContext, AutoBackupEntryPoint::class.java).autoBackupManager()
        manager.runIfDue()          // no-op while the vault is locked; caught up at the next unlock
        return Result.success()
    }
}
