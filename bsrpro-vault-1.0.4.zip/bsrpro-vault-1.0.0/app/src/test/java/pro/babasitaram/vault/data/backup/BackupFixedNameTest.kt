package pro.babasitaram.vault.data.backup

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class BackupFixedNameTest {
    @Test fun `automatic backup uses one stable canonical filename`() {
        assertEquals("BSRPRO.Vault", AutoBackupManager.FINAL_NAME)
        assertEquals("BSRPRO_Backups", AutoBackupManager.FOLDER)
    }
}
