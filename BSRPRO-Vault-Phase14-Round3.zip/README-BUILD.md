# BSRPRO Vault — GitHub Actions Build

This package contains the Phase 1–8 applied Android source changes plus the native Android CI workflow.

## Important

- The canonical encrypted vault format remains **BSRPRO.Vault V3**.
- `gradlew` and `gradle-wrapper.jar` are intentionally not included.
- GitHub Actions installs **Gradle 8.7** directly with `gradle/actions/setup-gradle`.
- `gradle/wrapper/gradle-wrapper.properties` is retained and still points to Gradle 8.7.
- No production vault/customer data is part of this source package.

## Push to GitHub safely

Use a dedicated branch for the native Android project instead of replacing an unrelated web-app branch.

```bash
git clone https://github.com/ramhardamp/babasitaram-pro-v2.git
cd babasitaram-pro-v2
git checkout -b native-android-phase9
```

Copy the contents of this package into the target branch, then:

```bash
git add .
git status
git commit -m "Prepare BSRPRO Vault native Android Phase 9 build"
git push -u origin native-android-phase9
```

Before committing, confirm that the branch contains the native Android project at repository root (`app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle/`, and `.github/workflows/native-android-build.yml`). Do not overwrite a production/web branch unless that branch is intentionally being converted to the native project.

## Trigger CI

The workflow file is:

`.github/workflows/native-android-build.yml`

It supports both:

- **Manual:** GitHub → Actions → **BSRPRO Vault Native Android Build** → **Run workflow**.
- **Push:** a push that changes `app/**`, Gradle/build files, `gradle/**`, or the workflow itself.

## APK location

After the workflow succeeds:

1. Open the successful GitHub Actions run.
2. Open the **Artifacts** section.
3. Download `BSRPRO-Vault-debug-<run number>`.
4. The artifact contains the generated debug APK.

The workflow also verifies the APK with `apksigner`, checks the manifest with `aapt`, validates the APK ZIP, installs it on an Android 35 emulator, launches `MainActivity`, and checks for fatal Android runtime exceptions.

## APK test checklist

After downloading and installing the APK on a test device, use synthetic test data only.

### Core vault

- [ ] App launches and unlocks.
- [ ] Create a synthetic login entry.
- [ ] Edit username/password/TOTP/notes.
- [ ] Delete entry → it appears in Bin.
- [ ] Restore entry → it returns to active vault.
- [ ] Empty Bin → entry is permanently removed.
- [ ] Existing vault data remains unchanged during testing.

### Import / export

- [ ] Import synthetic `.Vault` V3.
- [ ] Export and re-import the synthetic vault.
- [ ] Test representative CSV imports.
- [ ] Confirm IDs remain stable when valid IDs are supplied.
- [ ] Test a blank-ID fixture and confirm deterministic ID generation.

### Backup / restore

- [ ] Automatic backup uses the single filename `BSRPRO.Vault`.
- [ ] Restore discovers an Android backup automatically.
- [ ] Restore discovers an Extension-created `BSRPRO.Vault` backup.
- [ ] Simulate/inspect interrupted-write recovery using synthetic files only.
- [ ] Confirm the original main vault remains readable after a failed backup operation.

### Autofill

- [ ] Enable BSRPRO as the Autofill service.
- [ ] Open a test login page and confirm real username/password fields are detected.
- [ ] Verify locked-vault authentication appears.
- [ ] Verify the app icon/name in the Autofill picker.
- [ ] Verify light/dark suggestion UI follows the app theme.
- [ ] Verify Travel Mode suppresses automatic Autofill suggestions when enabled.

### UI / security

- [ ] Rotate-device behavior stays portrait.
- [ ] Test LTR and an RTL locale.
- [ ] Test light and dark theme transitions.
- [ ] Test PIN rules (4–6 digits).
- [ ] Test biometric unlock/cancel path.
- [ ] Let the configured session timeout expire and confirm relock.
- [ ] Confirm screenshots are blocked on protected screens.

## Phase 10 handoff

Record the actual device/emulator results, failed cases, screenshots/logcat where useful, and the GitHub Actions run result. Phase 10 should be completed only from those real test results; this README does not pre-assert runtime PASS.
