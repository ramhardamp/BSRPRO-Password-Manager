# BSRPRO Vault — Phase 12 Feature Completion

This package contains the applied Phase 1–12 Android source changes.

## Phase 12 implemented

- System BackHandler/Navigation back behavior on all non-root navigation destinations; root Vault exits normally.
- TOTP Manager: Add TOTP, search, live countdown/progress, copy code, tap detail, long-press/edit/share/move-to-bin.
- Notes: New Note, title/content/category editor, tap full note view, long-press/3-dot Edit/Copy/Share/Delete.
- Vault entries: tap detail, long-press/3-dot copy username/password/TOTP, edit, move to Bin, secure share, favorite.
- History: password/edit filters, view change, restore previous password, copy previous password.
- Files: upload from system picker, entry-editor attachments, persisted content URI metadata, preview/open, export/share, move to Bin.
- Mobiles: add/edit entries, detail view, copy number, move to Bin.
- Bin: restore one, restore all, permanent-delete confirmation, 30-day cleanup information and automatic cleanup.
- Settings: theme, auto-lock, biometric, weak-password blocking, Autofill, Travel Mode, generator settings, app icon, backup/import, emergency access, about/privacy/licensing.
- Help: getting started, import/export, Autofill, backup, security tips, FAQ and support link.
- Support Developer: Totalpay@upi, generated UPI QR, Pay via UPI intent, website and QR.
- Emergency Access: contact setup, 24-character recovery key, encrypted recovery secret, 72-hour timer, unlock/cancel/revoke.

## Build

The Android project uses `gradle/wrapper/gradle-wrapper.properties` with Gradle 8.7. The wrapper executable/JAR are intentionally absent from this package; the native CI workflow installs Gradle 8.7 on GitHub Actions.

Runtime/device verification is performed in Phase 9 CI/device testing, not claimed by this static package audit.
