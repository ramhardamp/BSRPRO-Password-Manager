const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(process.argv[2]||'../../../extension/src/crypto.js','utf8');
let fixed=[];
const realCrypto=globalThis.crypto;
const fake={subtle:realCrypto.subtle,getRandomValues:(a)=>{const f=fixed.shift(); for(let i=0;i<a.length;i++)a[i]=f[i]; return a;}};
const ctx={crypto:fake,TextEncoder,TextDecoder,btoa,atob,Uint8Array,JSON,Error,String,console};
vm.createContext(ctx);
vm.runInContext(src+';this.VaultCrypto=VaultCrypto;',ctx);
const V=ctx.VaultCrypto;
const seq=(start,n)=>Array.from({length:n},(_,i)=>(start+i)&255);
(async()=>{
  const out=[];
  const cases=[
    ['hello','password',1],
    ['__VAULT_CANARY__','correct horse battery staple',20],
    ['{"entries":[{"id":"1","title":"Gmail","password":"p@ss"}]}','Master#Pass123456',40],
    ['पासवर्ड 🔐 ünïcode','पासवर्ड-🔑-Ünï',60],
  ];
  for(const [pt,pw,s] of cases){
    fixed=[seq(s,16),seq(s+100,12)];
    out.push({kind:'legacy',plaintext:pt,password:pw,saltStart:s,ivStart:s+100,ciphertextB64:await V.encrypt(pt,pw)});
  }
  const v3=[
    ['{"schema":"BSRPRO.Vault.Payload","version":3,"entries":[{"id":"a1","title":"Bank","username":"u","password":"p"}]}','V3-Backup-Password!',80],
    ['{"version":"2.0","app":"BABASITARAMPro","count":1,"entries":[{"id":"b2","title":"Mail","appPackage":"com.example.app"}],"folders":[{"id":"f1","name":"Work"}]}','पासवर्ड-V3',120],
  ];
  for(const [pt,pw,s] of v3){
    fixed=[seq(s,16),seq(s+100,12)];
    out.push({kind:'v3',plaintext:pt,password:pw,saltStart:s,ivStart:s+100,container:await V.encryptV3(pt,pw)});
  }
  // sanity: decrypt roundtrip with real code
  for(const o of out){ const r=o.kind==='legacy'?await V.decrypt(o.ciphertextB64,o.password):await V.decryptV3(o.container,o.password); if(r!==o.plaintext) throw new Error('roundtrip fail'); }
  fs.writeFileSync(__dirname+'/vectors.json',JSON.stringify(out,null,1));
  console.log(JSON.stringify(out,null,1));
})();
