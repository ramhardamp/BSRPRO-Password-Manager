# BSRPRO Vault 0.2.5 — Milestone 1 engineering status

## Implemented in this source snapshot
- App version is 0.2.5 / versionCode 7.
- Automatic backup uses the fixed `Downloads/BSRPRO_Backups/BSRPRO.Vault` name on Android 10+ MediaStore; it stages and publishes a complete new file before cleaning previous fixed/legacy dated backups.
- Entry save/edit/delete, starred updates, and reviewed imports request backup after successful vault persistence.
- Settings changes and master-password changes request backup. Requests persist a pending marker before a 2.5-second debounce. If locked, the marker remains; after unlock, pending backup is attempted before daily catch-up.
- V3 backup serialization/encryption format was not changed.
- Settings includes a route to backup tools. The existing import path still requires manual document selection and review/merge; it is not automatic folder discovery or full-vault replacement.

## Not accepted / still pending
- Automatic lookup of `Downloads/BSRPRO_Backups/BSRPRO.Vault`, existing-vault password verification, confirm-before-overwrite, round-trip restore verification, and `.bak` rollback are not implemented as a complete safe restore transaction.
- Pending-backup notification UX is basic (a Toast at next unlock), and backup success/failure notifications for all mutation cases are not yet complete.
- Gradle assembleDebug, all JUnit tests, emulator, and real-device checks were not run in this environment (no Gradle executable/wrapper JAR and no attached Android device).
- Android 8/9 uses app-scoped external Downloads, not public Downloads, due scoped-storage compatibility.

## Release gate
Engineering preview only, not a solid/production release. Do not clear app data or uninstall over a live vault without a verified export. Validate on a disposable test vault before using any restore path. Do not accept this build until build/tests and the restore rollback matrix pass on a real test device.
