# BSRPRO Vault — feature audit and next milestones (0.2.4)

## Scope note
The existing-feature inventory below is based on the project owner's supplied inventory; this package does not claim a complete independent verification of every listed feature.

## Current inventory reported
Encrypted vault; master password and biometric unlock; web/native Autofill; password generator (random/passphrase/manual); strength meter; basic breach monitoring; categories/folders/tags; search/filter/sort; multi-format import/export; auto-backup; TOTP; password/edit history; notes/cards/identity/custom fields; clipboard auto-clear.

## 0.2.4 change
Adds a separate optional `appPin` value to login entries, parser classification, native autofill mapping, detail/editor display, and CSV/JSON/V3 payload persistence. Missing `appPin` decodes as empty. The V3 container envelope remains version 3; no Room schema migration is needed because credential payloads are encrypted JSON blobs and metadata tables do not store secret values.

## Suggested next three additions

1. **Secure sharing — architecture/design milestone first.** Use end-to-end encrypted, recipient-bound payloads; short-lived, revocable links; server-side expiry/rate limits; no plaintext credentials at rest on the sharing service; clear recipient verification and audit trail. Do not ship link sharing until key exchange, revocation, replay handling, and threat model are reviewed.
2. **Vault health report.** A local/offline report showing reused, weak, and aged credentials with explanations and direct entry navigation. Prefer transparent findings over a single opaque score; never upload vault contents for scoring.
3. **Duplicate/reused password detector.** Compare locally using normalized credential groups and secret equality checks; show affected entries without sending secrets off-device. Include weak-password findings in the same report surface.

Password-age reminders can follow as a separate lightweight milestone, based on `updatedAt`/`createdAt`, with snooze/dismiss controls rather than forced arbitrary rotation. Emergency access, travel mode, email aliases, and passkeys require their own threat model/provider/platform work; passkeys remain a later phase.
