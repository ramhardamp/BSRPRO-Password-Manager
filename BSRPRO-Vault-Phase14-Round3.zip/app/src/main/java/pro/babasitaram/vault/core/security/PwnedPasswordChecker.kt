package pro.babasitaram.vault.core.security

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Privacy-preserving compromised-password check using HIBP Pwned Passwords k-anonymity.
 * Only the first five SHA-1 characters are sent; the full hash is compared locally.
 */
class PwnedPasswordChecker {
    suspend fun check(password: CharArray): Result<Int> = withContext(Dispatchers.IO) {
        val bytes = password.concatToString().toByteArray(Charsets.UTF_8)
        try {
            val sha1 = MessageDigest.getInstance("SHA-1").digest(bytes)
            val hex = sha1.joinToString("") { "%02X".format(it) }
            val prefix = hex.substring(0, 5)
            val suffix = hex.substring(5)

            val connection = (URL("https://api.pwnedpasswords.com/range/$prefix").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10_000
                readTimeout = 10_000
                setRequestProperty("User-Agent", "BSRPRO-Vault")
                setRequestProperty("Add-Padding", "true")
            }

            try {
                if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                    return@withContext Result.failure(IllegalStateException("Breach service returned ${connection.responseCode}"))
                }
                val count = BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).useLines { lines ->
                    var found = 0
                    lines.forEach { line ->
                        val sep = line.indexOf(':')
                        if (sep > 0 && line.substring(0, sep).equals(suffix, ignoreCase = true)) {
                            found = line.substring(sep + 1).trim().toIntOrNull() ?: 0
                        }
                    }
                    found
                }
                Result.success(count)
            } finally {
                connection.disconnect()
            }
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            bytes.fill(0)
            password.fill('\u0000')
        }
    }
}
