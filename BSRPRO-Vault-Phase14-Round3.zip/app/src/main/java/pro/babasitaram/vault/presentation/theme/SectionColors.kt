package pro.babasitaram.vault.presentation.theme
import androidx.compose.ui.graphics.Color
object SectionColors { val account=Color(0xFF3B82F6); val security=Color(0xFFA78BFA); val autofill=Color(0xFF10B981); val appearance=Color(0xFFEC4899); val generator=Color(0xFFF59E0B); val data=Color(0xFF6366F1); val support=Color(0xFF06B6D4); val about=Color(0xFF6B7280) }
