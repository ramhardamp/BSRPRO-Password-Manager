package pro.babasitaram.vault.data.transfer

import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.model.CustomField
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.security.MessageDigest
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.util.IdGenerator
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.core.util.VaultError

class ParsedImport(val format: ImportFormat, val entries: List<VaultEntry>, val skippedRows: Int)

/** Parses third-party exports. Limits mirror the browser extension (25 MB, 10 000 entries). */
object ImportParser {
    const val MAX_CHARS = 25 * 1024 * 1024
    const val MAX_ENTRIES = 10_000
    private const val MAX_FIELD_CHARS = 1_000_000

    private val BASE64_BLOB = Regex("^[A-Za-z0-9+/]+={0,2}$")

    fun detectKind(raw: String): SourceKind {
        val t = raw.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        if (t.isBlank()) return SourceKind.UNKNOWN
        return when {
            t.startsWith("{") && t.contains("\"BSRPRO.Vault\"") -> SourceKind.V3_BACKUP
            t.startsWith("{") && t.contains("\"entries\"") -> SourceKind.PLAIN_JSON
            t.take(11).equals("BEGIN:VCARD", ignoreCase = true) -> SourceKind.VCARD
            t.length >= 60 && '\n' !in t.trim() && BASE64_BLOB.matches(t.trim()) -> SourceKind.DEVICE_BACKUP
            else -> SourceKind.CSV
        }
    }

    // ───────────────────────── CSV ─────────────────────────

    fun parseCsv(text: String, now: Long = System.currentTimeMillis()): ParsedImport {
        if (text.length > MAX_CHARS) throw VaultError.Validation("Import file is too large (max 25 MB).")
        val rows = Csv.parse(text)
        if (rows.size < 2) throw VaultError.Validation("The file is empty or has no data rows.")
        val header = rows[0].map { it.trim().lowercase() }
        val cols = Columns(header)
        if (cols.password < 0) throw VaultError.Validation("Password column not found. The CSV must contain a \"password\" header.")
        val format = detectFormat(header)

        val out = ArrayList<VaultEntry>()
        var skipped = 0
        for (r in rows.drop(1)) {
            if (cols.type >= 0) {
                val type = cols.get(r, cols.type).trim().lowercase()
                if (type.isNotEmpty() && type != "login") { skipped++; continue }
            }
            val password = cols.get(r, cols.password)                  // never trimmed
            val rawAppPin = cols.get(r, cols.appPin)
            if (rawAppPin.isNotBlank() && (rawAppPin.length !in 4..6 || rawAppPin.any { it !in '0'..'9' })) {
                throw VaultError.Validation("Imported app PIN must contain 4 to 6 digits.")
            }
            val appPin = rawAppPin
            val username = cols.get(r, cols.username).trim()
            val mobile = cols.get(r, cols.mobile).trim()
            val totp = cols.get(r, cols.totp).trim()
            val url = cols.get(r, cols.url).trim()
            if (password.isEmpty() && appPin.isEmpty() && username.isEmpty() && mobile.isEmpty() && totp.isEmpty()) { skipped++; continue }
            if (listOf(password, appPin, username, url, totp).any { it.length > MAX_FIELD_CHARS }) {
                throw VaultError.Validation("Import contains an oversized field.")
            }
            if (out.size >= MAX_ENTRIES) throw VaultError.Validation("Import contains too many entries (max 10,000).")
            val created = cols.get(r, cols.createdAt).trim().toLongOrNull() ?: now
            val updated = cols.get(r, cols.updatedAt).trim().toLongOrNull() ?: now
            out.add(
                VaultEntry(
                    id = IdGenerator.newId(now),
                    title = cols.get(r, cols.title).trim().ifEmpty { titleFromUrl(url) }.ifEmpty { if (username.isNotEmpty()) "Imported Login" else "Imported Entry" },
                    url = url,
                    username = username,
                    password = password,
                    appPin = appPin,
                    mobile = mobile,
                    notes = cols.get(r, cols.notes).trim(),
                    totp = totp,
                    starred = cols.get(r, cols.starred).trim().let { it == "1" || it.equals("true", true) },
                    category = cols.get(r, cols.category).trim().ifEmpty { "other" },
                    recordType = cols.get(r, cols.recordType).trim().ifEmpty { "login" },
                    folder = cols.get(r, cols.folder).trim(),
                    folderId = cols.get(r, cols.folderId).trim(),
                    tags = cols.get(r, cols.tags).split(Regex("[;,|]")).map { it.trim() }.filter { it.isNotEmpty() },
                    customFields = parseCustomFields(cols.get(r, cols.customFields)) +
                        cols.get(r, cols.reprompt).takeIf { it.isNotBlank() }?.let { listOf(CustomField("reprompt", it)) }.orEmpty(),
                    email = cols.get(r, cols.email).trim(),
                    phone = cols.get(r, cols.phone).trim().ifEmpty { mobile },
                    address = cols.get(r, cols.address).trim(),
                    strength = cols.get(r, cols.strength).trim().ifEmpty { if (password.isEmpty()) "" else PasswordStrength.bucket(password) },
                    createdAt = created,
                    updatedAt = updated,
                    lastUsedAt = cols.get(r, cols.lastUsedAt).trim().toLongOrNull() ?: 0L
                )
            )
        }
        return ParsedImport(format, out, skipped)
    }

    private fun detectFormat(h: List<String>): ImportFormat = when {
        "login_uri" in h && "login_username" in h -> ImportFormat.BITWARDEN
        "grouping" in h && ("extra" in h || "fav" in h) -> ImportFormat.LASTPASS
        "folder" in h && "name" in h && "password" in h && "url" in h -> ImportFormat.NORDPASS
        "httprealm" in h -> ImportFormat.FIREFOX
        "mobile" in h && "name" in h && ("strength" in h || "starred" in h) -> ImportFormat.VAULT_CSV
        "group" in h && "title" in h -> ImportFormat.KEEPASS
        "login name" in h || "web site" in h -> ImportFormat.KEEPASS
        "otpsecret" in h || "username2" in h -> ImportFormat.DASHLANE
        "otpauth" in h || ("title" in h && "type" in h) -> ImportFormat.ONEPASSWORD
        h.take(4) == listOf("name", "url", "username", "password") -> ImportFormat.CHROME
        else -> ImportFormat.GENERIC
    }

    /** Header → column index, with synonyms. Exact header matches win over "contains" matches. */
    private class Columns(private val header: List<String>) {
        val title = find("name", "title", "site", "service", "account")
        val url = find("url", "website", "web site", "origin", "uri", "domain", "hostname", "login_uri")
        val username = find("login_username", "username", "user", "login", "email")
        val password = find("login_password", "password", "pass", "pwd", "secret")
        val appPin = findExact("app_pin", "apppin", "pin")
        val notes = find("notes", "note", "comment", "extra", "description")
        val totp = find("totp", "otpsecret", "otpauth", "otp", "one-time password")
        val mobile = find("mobile", "phone", "contact")
        val type = findExact("type")
        val starred = findExact("starred", "favorite", "fav")
        val createdAt = findExact("createdat")
        val updatedAt = findExact("updatedat", "updated_at", "modified", "modifiedat")
        val category = findExact("category", "item_type")
        val recordType = findExact("recordtype", "record_type", "type")
        val folder = findExact("folder", "grouping", "foldername", "folder_name")
        val folderId = findExact("folderid", "folder_id")
        val tags = findExact("tags", "tag")
        val customFields = findExact("fields", "customfields", "custom_fields", "extra")
        val reprompt = findExact("reprompt")
        val email = findExact("email", "login_email")
        val phone = findExact("phone", "telephone")
        val address = findExact("address", "adr")
        val strength = findExact("strength")
        val lastUsedAt = findExact("lastusedat", "last_used_at")

        fun get(r: List<String>, idx: Int): String = if (idx in r.indices) r[idx] else ""

        private fun findExact(vararg names: String): Int {
            for (n in names) header.indexOf(n).let { if (it >= 0) return it }
            return -1
        }

        private fun find(vararg names: String): Int {
            val exact = findExact(*names)
            if (exact >= 0) return exact
            for (n in names) {
                val i = header.indexOfFirst { it.contains(n) }
                if (i >= 0) return i
            }
            return -1
        }
    }

    private fun parseCustomFields(raw: String): List<CustomField> {
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = VaultJson.parseToJsonElement(raw) as? JsonArray
            arr?.mapNotNull { item ->
                val obj = item as? kotlinx.serialization.json.JsonObject ?: return@mapNotNull null
                val key = (obj["k"] ?: obj["name"] ?: obj["key"])?.jsonPrimitive?.contentOrNull.orEmpty()
                val value = (obj["v"] ?: obj["value"])?.jsonPrimitive?.contentOrNull.orEmpty()
                if (key.isBlank()) null else CustomField(key, value)
            } ?: raw.split(";").mapNotNull { part ->
                val pair = part.split("=", limit = 2)
                if (pair.size == 2) CustomField(pair[0].trim(), pair[1]) else null
            }
        } catch (_: Exception) {
            raw.split(";").mapNotNull { part ->
                val pair = part.split("=", limit = 2)
                if (pair.size == 2) CustomField(pair[0].trim(), pair[1]) else null
            }
        }
    }

    private fun stableLegacyId(value: String, index: Int): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return "legacy-$digest-$index"
    }

    private fun titleFromUrl(url: String): String =
        UrlUtils.domainOf(url).substringBefore('.').replaceFirstChar { it.uppercase() }

    // ───────────────────────── vCard ─────────────────────────

    fun parseVCard(text: String, now: Long = System.currentTimeMillis()): ParsedImport {
        if (text.length > MAX_CHARS) throw VaultError.Validation("Import file is too large (max 25 MB).")
        val cards = Regex("BEGIN:VCARD", RegexOption.IGNORE_CASE).split(text).drop(1)
        val out = ArrayList<VaultEntry>()
        for (card in cards) {
            val fn = vFields(card, "FN").firstOrNull().orEmpty()
            val n = vFields(card, "N").firstOrNull().orEmpty().replace(Regex(";+"), " ").trim()
            val phones = vFields(card, "TEL").map { it.replace(Regex("[\\s\\-().+]"), "") }.filter { it.isNotBlank() }
            val emails = vFields(card, "EMAIL").filter { it.isNotBlank() }
            val urls = vFields(card, "URL").filter { it.isNotBlank() }
            val notes = vFields(card, "NOTE").joinToString("\n")
            val extra = buildList {
                phones.drop(1).forEachIndexed { i, v -> add(CustomField("phone${i + 2}", v)) }
                emails.drop(1).forEachIndexed { i, v -> add(CustomField("email${i + 2}", v)) }
                vFields(card, "ADR").forEachIndexed { i, v -> add(CustomField("address${i + 1}", v)) }
                vFields(card, "ORG").forEachIndexed { i, v -> add(CustomField("organization${i + 1}", v)) }
                vFields(card, "BDAY").forEachIndexed { i, v -> add(CustomField("birthday${i + 1}", v)) }
            }
            val title = fn.ifEmpty { n }
            val phone = phones.firstOrNull().orEmpty()
            val email = emails.firstOrNull().orEmpty()
            if (title.isEmpty() && phone.isEmpty() && email.isEmpty()) continue
            if (out.size >= MAX_ENTRIES) throw VaultError.Validation("Import contains too many entries (max 10,000).")
            val identity = listOf(title, phone, email, urls.firstOrNull().orEmpty(), notes, extra.toString()).joinToString("|")
            out.add(VaultEntry(id = stableLegacyId(identity, out.size), title = title.ifEmpty { phone.ifEmpty { email } },
                url = urls.firstOrNull().orEmpty(), username = email, email = email, mobile = phone, phone = phone,
                notes = notes, customFields = extra, createdAt = now, updatedAt = now))
        }
        if (out.isEmpty()) throw VaultError.Validation("No valid contacts were found in the vCard file.")
        return ParsedImport(ImportFormat.VCARD, out, 0)
    }

    private fun vFields(card: String, key: String): List<String> {
        val unfolded = card.replace(Regex("\\r?\\n[ \t]"), "")
        val re = Regex("^$key(?:;[^:\\r\\n]*)?:(.*)$", setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE))
        return re.findAll(unfolded).map { it.groupValues[1].trim() }.toList()
    }

    // ───────────────────────── plain JSON ─────────────────────────

    fun parsePlainJson(text: String, now: Long = System.currentTimeMillis()): ParsedImport {
        if (text.length > MAX_CHARS) throw VaultError.Validation("Import file is too large (max 25 MB).")
        val root = try {
            VaultJson.parseToJsonElement(text) as? kotlinx.serialization.json.JsonObject
        } catch (e: Exception) {
            null
        } ?: throw VaultError.InvalidFormat("Not a JSON object")
        val arr = root["entries"] as? kotlinx.serialization.json.JsonArray ?: throw VaultError.InvalidFormat("Missing entries array")
        if (arr.size > MAX_ENTRIES) throw VaultError.Validation("Import contains too many entries (max 10,000).")
        val entries = try {
            arr.map { VaultJson.decodeFromJsonElement(VaultEntry.serializer(), it) }
        } catch (e: Exception) {
            throw VaultError.InvalidFormat("Malformed entry")
        }
        val seenIds = HashSet<String>()
        val fixed = entries.mapIndexed { index, e ->
            val canonical = VaultJson.encodeToString(VaultEntry.serializer(), e.copy(id = ""))
            val candidate = e.id.trim()
            val id = if (candidate.isNotEmpty() && seenIds.add(candidate)) candidate else {
                var generated = stableLegacyId(canonical, index)
                var suffix = 1
                while (!seenIds.add(generated)) generated = stableLegacyId(canonical, index + suffix++)
                generated
            }
            e.copy(
                id = id,
                title = e.title.ifBlank { titleFromUrl(e.url).ifEmpty { "Imported Entry" } },
                createdAt = if (e.createdAt > 0) e.createdAt else now,
                updatedAt = if (e.updatedAt > 0) e.updatedAt else now
            )
        }
        return ParsedImport(ImportFormat.JSON, fixed, 0)
    }
}
