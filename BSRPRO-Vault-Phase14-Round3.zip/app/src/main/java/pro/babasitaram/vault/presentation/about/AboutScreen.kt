package pro.babasitaram.vault.presentation.about
import androidx.compose.material.icons.Icons
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.automirrored.filled.ArrowBack

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.*
import androidx.compose.runtime.*

@Composable
fun AboutScreen(onBack: () -> Unit = {}) {
    BackHandler { onBack() }
    Scaffold(topBar = { TopAppBar(title = { Text("About", style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("About", style = MaterialTheme.typography.headlineSmall) }
            item { Text("Your encrypted vault data remains in the existing vault store.", style = MaterialTheme.typography.bodyMedium) }
            item {
                OutlinedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("BSRPRO Vault", style = MaterialTheme.typography.titleMedium)
                        Text("Version 1.0.4", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(6.dp))
                        Text("An encrypted, offline-first password vault with Autofill, TOTP, secure sharing, backup and recovery tools.")
                    }
                }
            }
        }
    }
}
