package pro.babasitaram.vault.core.util

import java.security.SecureRandom

/** Same shape as the extension's genId(): "v_" + time(base36) + random(base36). */
object IdGenerator {
    private val random = SecureRandom()

    fun newId(now: Long = System.currentTimeMillis()): String {
        val a = random.nextInt().toLong() and 0xFFFFFFFFL
        val b = random.nextInt().toLong() and 0xFFFFFFFFL
        return "v_" + now.toString(36) + "_" + a.toString(36) + b.toString(36)
    }
}
