package pro.babasitaram.vault.domain.usecase

import java.security.SecureRandom
import javax.inject.Inject
import pro.babasitaram.vault.core.util.WordList

data class PasswordOptions(
    val length: Int = 20,
    val lower: Boolean = true,
    val upper: Boolean = true,
    val digits: Boolean = true,
    val symbols: Boolean = true,
    val excludeAmbiguous: Boolean = false,
    val keyword: String = ""
)

class GeneratePasswordUseCase @Inject constructor() {
    private val rng = SecureRandom()

    operator fun invoke(o: PasswordOptions): String {
        val length = o.length.coerceIn(MIN_LENGTH, MAX_LENGTH)
        val pools = buildList {
            if (o.lower) add(LOWER)
            if (o.upper) add(UPPER)
            if (o.digits) add(DIGITS)
            if (o.symbols) add(SYMBOLS)
        }.map { pool -> if (o.excludeAmbiguous) pool.filterNot { it in AMBIGUOUS } else pool }
            .filter { it.isNotEmpty() }
        require(pools.isNotEmpty()) { "Select at least one character type" }

        // keyword is a visible prefix; always leave >= 8 random characters after it
        val keyword = o.keyword.trim().take((length - 8).coerceAtLeast(0))
        val randomLength = length - keyword.length
        val all = pools.joinToString("")
        val chars = ArrayList<Char>(randomLength)
        pools.forEach { chars.add(it[rng.nextInt(it.length)]) }           // at least one of each enabled class
        while (chars.size < randomLength) chars.add(all[rng.nextInt(all.length)])
        for (i in chars.indices.reversed()) {                                // Fisher–Yates
            val j = rng.nextInt(i + 1)
            val t = chars[i]; chars[i] = chars[j]; chars[j] = t
        }
        return keyword + chars.take(randomLength).joinToString("")
    }

    fun pin(length: Int = 6): String {
        val n = length.coerceIn(4, 6)
        val digits = CharArray(n) { ('0'.code + rng.nextInt(10)).toChar() }
        // First digit may be zero: this is a PIN, not a decimal integer.
        return String(digits)
    }

    fun passphrase(words: Int = 4, separator: String = "-", capitalize: Boolean = true, includeNumber: Boolean = true): String {
        val n = words.coerceIn(3, 10)
        val parts = MutableList(n) {
            val w = WordList.WORDS[rng.nextInt(WordList.WORDS.size)]
            if (capitalize) w.replaceFirstChar { c -> c.uppercase() } else w
        }
        if (includeNumber) parts[parts.lastIndex] = parts.last() + rng.nextInt(100)
        return parts.joinToString(separator)
    }

    companion object {
        const val MIN_LENGTH = 8
        const val MAX_LENGTH = 256
        private const val LOWER = "abcdefghijklmnopqrstuvwxyz"
        private const val UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        private const val DIGITS = "0123456789"
        private const val SYMBOLS = "!@#\$%^&*()-_=+[]{};:,.<>?"
        private const val AMBIGUOUS = "Il1O0o"
    }
}
