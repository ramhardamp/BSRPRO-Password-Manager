package pro.babasitaram.vault.core.security

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.AppIconColor
import pro.babasitaram.vault.di.ApplicationScope
import pro.babasitaram.vault.domain.repository.SettingsRepository
import timber.log.Timber

/**
 * Switches the launcher <activity-alias>. Doing it while the app is on screen can close the app on
 * some launchers, so the switch is applied when the app goes to the background (and is idempotent).
 */
@Singleton
class AppIconApplier @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settings: SettingsRepository,
    @ApplicationScope private val scope: CoroutineScope
) {
    fun applyWhenBackgrounded() {
        scope.launch {
            val wanted = settings.current().appIcon
            try {
                apply(wanted)
            } catch (e: Exception) {
                Timber.w("icon switch failed: %s", e.javaClass.simpleName)
            }
        }
    }

    private fun apply(wanted: AppIconColor) {
        val pm = context.packageManager
        val needsChange = AppIconColor.values().any { c -> isEnabled(pm, c) != (c == wanted) }
        if (!needsChange) return
        // enable the new alias first so the app never vanishes from the launcher
        AppIconColor.values().sortedBy { it != wanted }.forEach { c ->
            pm.setComponentEnabledSetting(
                component(c),
                if (c == wanted) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
    }

    private fun isEnabled(pm: PackageManager, c: AppIconColor): Boolean =
        when (pm.getComponentEnabledSetting(component(c))) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
            PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> c == AppIconColor.PURPLE   // manifest default
            else -> false
        }

    private fun component(c: AppIconColor) = ComponentName(context.packageName, "pro.babasitaram.vault.${c.aliasName}")
}
