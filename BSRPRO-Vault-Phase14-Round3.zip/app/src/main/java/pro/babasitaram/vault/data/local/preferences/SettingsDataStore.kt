package pro.babasitaram.vault.data.local.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import pro.babasitaram.vault.core.model.AppIconColor
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.domain.repository.SettingsRepository

class SettingsDataStore(private val store: DataStore<Preferences>) : SettingsRepository {

    override val settings: Flow<VaultSettings> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it.toSettings() }

    override suspend fun current(): VaultSettings = settings.first()

    override suspend fun update(transform: (VaultSettings) -> VaultSettings) {
        store.edit { prefs ->
            val n = transform(prefs.toSettings())
            prefs[THEME] = n.theme.name
            prefs[AUTO_LOCK] = n.autoLockSeconds
            prefs[CLIP_CLEAR] = n.clipboardClearSeconds
            prefs[BIOMETRIC] = n.biometricEnabled
            prefs[LOCK_BG] = n.lockOnBackground
            prefs[GEN_LEN] = n.generatorDefaultLength
            prefs[GEN_KEYWORD] = n.generatorKeyword
            prefs[TRAVEL] = n.travelMode
            prefs[AUTOFILL_INLINE] = n.autofillInline
            prefs[AUTOFILL_REGEX] = n.autofillRegexEnabled
            prefs[AUTOFILL_EXCLUDED] = n.autofillExcludedPackages.joinToString("\n")
            prefs[GEN_EXCLUDE_SIMILAR] = n.generatorExcludeSimilar
            prefs[BLOCK_WEAK] = n.blockWeakPasswords
            prefs[APP_ICON] = n.appIcon.name
            prefs[AUTO_BACKUP] = n.autoBackupEnabled
            prefs[LAST_AUTO_BACKUP] = n.lastAutoBackupAt
            prefs[EMERGENCY_ENC_MASTER] = n.emergencyEncryptedMaster
            prefs[EMERGENCY_REQUEST_TIME] = n.emergencyRequestTime
            prefs[EMERGENCY_ACTIVE] = n.emergencyActive
            prefs[EMERGENCY_CONTACT_NAME] = n.emergencyContactName
            prefs[EMERGENCY_CONTACT_PHONE] = n.emergencyContactPhone
            prefs[RECOVERY_ENC_MASTER] = n.recoveryEncryptedMaster
            prefs[RECOVERY_ENC_KEY] = n.recoveryEncryptedKey
            prefs[RECOVERY_CREATED_AT] = n.recoveryCreatedAt
            prefs[FONT_SCALE] = n.fontScalePercent.coerceIn(80, 200)
            prefs[HIDE_RECENTS] = n.hideSensitiveContentInRecents
        }
    }

    private fun Preferences.toSettings(): VaultSettings {
        val d = VaultSettings()
        return VaultSettings(
            theme = this[THEME]?.let { n -> ThemeMode.values().firstOrNull { it.name == n } } ?: d.theme,
            autoLockSeconds = this[AUTO_LOCK] ?: d.autoLockSeconds,
            clipboardClearSeconds = this[CLIP_CLEAR] ?: d.clipboardClearSeconds,
            biometricEnabled = this[BIOMETRIC] ?: d.biometricEnabled,
            lockOnBackground = this[LOCK_BG] ?: d.lockOnBackground,
            generatorDefaultLength = this[GEN_LEN] ?: d.generatorDefaultLength,
            generatorKeyword = this[GEN_KEYWORD] ?: d.generatorKeyword,
            travelMode = this[TRAVEL] ?: d.travelMode,
            autofillInline = this[AUTOFILL_INLINE] ?: d.autofillInline,
            autofillRegexEnabled = this[AUTOFILL_REGEX] ?: d.autofillRegexEnabled,
            autofillExcludedPackages = this[AUTOFILL_EXCLUDED].orEmpty().lines().map(String::trim).filter(String::isNotEmpty).distinct(),
            generatorExcludeSimilar = this[GEN_EXCLUDE_SIMILAR] ?: d.generatorExcludeSimilar,
            blockWeakPasswords = this[BLOCK_WEAK] ?: d.blockWeakPasswords,
            appIcon = this[APP_ICON]?.let { n -> AppIconColor.values().firstOrNull { it.name == n } } ?: d.appIcon,
            autoBackupEnabled = this[AUTO_BACKUP] ?: d.autoBackupEnabled,
            lastAutoBackupAt = this[LAST_AUTO_BACKUP] ?: d.lastAutoBackupAt,
            emergencyEncryptedMaster = this[EMERGENCY_ENC_MASTER] ?: d.emergencyEncryptedMaster,
            emergencyRequestTime = this[EMERGENCY_REQUEST_TIME] ?: d.emergencyRequestTime,
            emergencyActive = this[EMERGENCY_ACTIVE] ?: d.emergencyActive,
            emergencyContactName = this[EMERGENCY_CONTACT_NAME] ?: d.emergencyContactName,
            emergencyContactPhone = this[EMERGENCY_CONTACT_PHONE] ?: d.emergencyContactPhone,
            recoveryEncryptedMaster = this[RECOVERY_ENC_MASTER] ?: d.recoveryEncryptedMaster,
            recoveryEncryptedKey = this[RECOVERY_ENC_KEY] ?: d.recoveryEncryptedKey,
            recoveryCreatedAt = this[RECOVERY_CREATED_AT] ?: d.recoveryCreatedAt,
            fontScalePercent = (this[FONT_SCALE] ?: d.fontScalePercent).coerceIn(80, 200),
            hideSensitiveContentInRecents = this[HIDE_RECENTS] ?: d.hideSensitiveContentInRecents
        )
    }

    private companion object {
        val THEME = stringPreferencesKey("theme")
        val AUTO_LOCK = intPreferencesKey("auto_lock_seconds")
        val CLIP_CLEAR = intPreferencesKey("clipboard_clear_seconds")
        val BIOMETRIC = booleanPreferencesKey("biometric_enabled")
        val LOCK_BG = booleanPreferencesKey("lock_on_background")
        val GEN_LEN = intPreferencesKey("generator_default_length")
        val GEN_KEYWORD = stringPreferencesKey("generator_keyword")
        val TRAVEL = booleanPreferencesKey("travel_mode")
        val AUTOFILL_INLINE = booleanPreferencesKey("autofill_inline")
        val AUTOFILL_REGEX = booleanPreferencesKey("autofill_regex_enabled")
        val AUTOFILL_EXCLUDED = stringPreferencesKey("autofill_excluded_packages")
        val GEN_EXCLUDE_SIMILAR = booleanPreferencesKey("generator_exclude_similar")
        val BLOCK_WEAK = booleanPreferencesKey("block_weak_passwords")
        val APP_ICON = stringPreferencesKey("app_icon")
        val AUTO_BACKUP = booleanPreferencesKey("auto_backup_enabled")
        val LAST_AUTO_BACKUP = longPreferencesKey("last_auto_backup_at")
        val EMERGENCY_ENC_MASTER = stringPreferencesKey("emergency_encrypted_master")
        val EMERGENCY_REQUEST_TIME = longPreferencesKey("emergency_request_time")
        val EMERGENCY_ACTIVE = booleanPreferencesKey("emergency_active")
        val EMERGENCY_CONTACT_NAME = stringPreferencesKey("emergency_contact_name")
        val EMERGENCY_CONTACT_PHONE = stringPreferencesKey("emergency_contact_phone")
        val RECOVERY_ENC_MASTER = stringPreferencesKey("recovery_encrypted_master")
        val RECOVERY_ENC_KEY = stringPreferencesKey("recovery_encrypted_key")
        val RECOVERY_CREATED_AT = longPreferencesKey("recovery_created_at")
        val FONT_SCALE = intPreferencesKey("font_scale_percent")
        val HIDE_RECENTS = booleanPreferencesKey("hide_sensitive_content_in_recents")
    }
}
