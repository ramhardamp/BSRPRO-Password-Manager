package pro.babasitaram.vault.core.model

import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json

/** Lenient on input (extension data is loosely typed), complete on output. */
@OptIn(ExperimentalSerializationApi::class)
val VaultJson: Json = Json {
    ignoreUnknownKeys = true
    isLenient = true
    coerceInputValues = true
    encodeDefaults = true
    explicitNulls = false
}
