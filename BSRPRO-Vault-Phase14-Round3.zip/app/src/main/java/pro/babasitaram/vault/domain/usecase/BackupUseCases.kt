package pro.babasitaram.vault.domain.usecase

import javax.inject.Inject
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.IdGenerator
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.data.transfer.DuplicateAction
import pro.babasitaram.vault.data.transfer.DuplicateDetector
import pro.babasitaram.vault.data.transfer.EntryExporter
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.data.transfer.ImportFormat
import pro.babasitaram.vault.data.transfer.ImportItem
import pro.babasitaram.vault.data.transfer.ImportParser
import pro.babasitaram.vault.data.transfer.SourceKind
import pro.babasitaram.vault.domain.repository.VaultRepository

/** Builds the text of an export file from the unlocked vault. */
class BuildExportUseCase @Inject constructor(
    private val repository: VaultRepository,
    private val session: SessionKeyStore
) {
    suspend operator fun invoke(format: ExportFormat, nowMs: Long = System.currentTimeMillis()): VaultResult<String> = vaultCatching {
        val entries = repository.entries.value
        when (format) {
            ExportFormat.V3 -> {
                val data = VaultData(entries, repository.folders.value)
                session.withPassword { EntryExporter.v3(data, it) }
            }
            ExportFormat.VAULT_CSV -> EntryExporter.vaultCsv(entries)
            ExportFormat.CHROME_CSV -> EntryExporter.chromeCsv(entries)
            ExportFormat.BITWARDEN_CSV -> EntryExporter.bitwardenCsv(entries)
            ExportFormat.PLAIN_JSON -> EntryExporter.plainJson(entries, nowMs)
        }
    }

    /** Manual encrypted export using a separate backup password. The master password is never exposed in the file. */
    suspend fun encryptedV3WithPassword(password: CharArray): VaultResult<String> = vaultCatching {
        val data = VaultData(repository.entries.value, repository.folders.value)
        EntryExporter.v3(data, password)
    }
}

/** A file that has been decoded and is waiting for the user to review it. */
class ImportPreview(
    val format: ImportFormat,
    val items: List<ImportItem>,
    val folders: List<Folder>,
    val skippedRows: Int
) {
    val newCount: Int get() = items.count { it.duplicateOf == null }
    val duplicateCount: Int get() = items.count { it.duplicateOf != null }
}

/** Turns file text into an [ImportPreview] (no vault changes yet). */
class PrepareImportUseCase @Inject constructor(private val repository: VaultRepository) {

    /** [backupPassword] is only needed for encrypted backups ([SourceKind.V3_BACKUP], [SourceKind.DEVICE_BACKUP]). */
    suspend operator fun invoke(text: String, backupPassword: CharArray? = null): VaultResult<ImportPreview> = vaultCatching {
        if (text.length > ImportParser.MAX_CHARS) throw VaultError.Validation("Import file is too large (max 25 MB).")
        val now = System.currentTimeMillis()
        val kind = ImportParser.detectKind(text)
        var folders: List<Folder> = emptyList()
        val parsed = when (kind) {
            SourceKind.V3_BACKUP, SourceKind.DEVICE_BACKUP -> {
                val pw = backupPassword ?: throw VaultError.Validation("Backup password required")
                val plain = if (kind == SourceKind.V3_BACKUP) VaultCrypto.decryptV3(text.trim(), pw) else VaultCrypto.decrypt(text.trim(), pw)
                val p = V3PayloadParser.parse(plain)
                folders = p.folders
                val fmt = if (kind == SourceKind.V3_BACKUP) ImportFormat.BACKUP_V3 else ImportFormat.DEVICE_BACKUP
                pro.babasitaram.vault.data.transfer.ParsedImport(fmt, p.entries.filterNot { it.isFolderMarker }, 0)
            }
            SourceKind.PLAIN_JSON -> ImportParser.parsePlainJson(text, now)
            SourceKind.VCARD -> ImportParser.parseVCard(text, now)
            SourceKind.CSV -> ImportParser.parseCsv(text, now)
            SourceKind.UNKNOWN -> throw VaultError.Validation("The file is empty or unreadable.")
        }
        ImportPreview(parsed.format, DuplicateDetector.plan(parsed.entries, repository.entries.value), folders, parsed.skippedRows)
    }
}

/** Writes the reviewed import into the vault with a single disk write. */
class CommitImportUseCase @Inject constructor(
    private val repository: VaultRepository,
    private val autoBackup: AutoBackupManager
) {

    /** [actions] maps item index → what to do with a duplicate (default [DuplicateAction.SKIP]). Returns the number of entries written. */
    suspend operator fun invoke(preview: ImportPreview, actions: Map<Int, DuplicateAction>, now: Long = System.currentTimeMillis()): VaultResult<Int> = vaultCatching {
        val existingIds = repository.entries.value.map { it.id }.toMutableSet()
        val out = ArrayList<VaultEntry>()
        preview.items.forEachIndexed { i, item ->
            val dup = item.duplicateOf
            val e = item.entry
            if (dup == null) {
                out.add(withFreeId(e, existingIds, now))
            } else when (actions[i] ?: DuplicateAction.SKIP) {
                DuplicateAction.SKIP -> Unit
                DuplicateAction.REPLACE -> out.add(e.copy(id = dup.id, createdAt = dup.createdAt.takeIf { it > 0 } ?: e.createdAt, updatedAt = now, folderId = dup.folderId.ifEmpty { e.folderId }))
                DuplicateAction.KEEP_BOTH -> out.add(withFreeId(e, existingIds, now))
            }
        }
        // folder references that do not exist in the vault would be rejected by the extension's validator
        val knownFolders = (repository.folders.value + preview.folders).map { it.id }.toSet()
        val cleaned = out.map { if (it.folderId.isNotBlank() && it.folderId !in knownFolders) it.copy(folderId = "") else it }
        repository.upsertAll(cleaned, preview.folders)
        if (cleaned.isNotEmpty() || preview.folders.isNotEmpty()) autoBackup.requestBackup()
        cleaned.size
    }

    /** Entries from a backup keep their id unless it is already taken in this vault. */
    private fun withFreeId(e: VaultEntry, taken: MutableSet<String>, now: Long): VaultEntry {
        val id = if (e.id.isBlank() || e.id in taken) IdGenerator.newId(now) else e.id
        taken.add(id)
        return e.copy(id = id)
    }
}
