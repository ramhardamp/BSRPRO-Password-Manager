package pro.babasitaram.vault.core.security

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import org.json.JSONArray
import org.json.JSONObject

/** Local, non-sensitive activity audit. Passwords, secrets and URLs are never recorded. */
@Singleton
class ActivityLogStore @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun record(action: String, detail: String = "") {
        val safeAction = action.take(80)
        val safeDetail = detail.take(160)
        val old = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrElse { JSONArray() }
        val out = JSONArray()
        out.put(JSONObject().apply {
            put("at", System.currentTimeMillis())
            put("action", safeAction)
            put("detail", safeDetail)
        })
        val start = maxOf(0, old.length() - MAX_ITEMS + 1)
        for (i in start until old.length()) out.put(old.opt(i))
        prefs.edit().putString(KEY, out.toString()).apply()
    }

    @Synchronized
    fun snapshot(): List<ActivityLogItem> {
        val array = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrElse { JSONArray() }
        return buildList(array.length()) {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                add(ActivityLogItem(
                    timestamp = o.optLong("at"),
                    action = o.optString("action"),
                    detail = o.optString("detail")
                ))
            }
        }.sortedByDescending { it.timestamp }
    }

    @Synchronized
    fun clear() = prefs.edit().remove(KEY).apply()

    data class ActivityLogItem(
        val timestamp: Long,
        val action: String,
        val detail: String
    )

    private companion object {
        const val PREFS = "bsrpro_activity_log"
        const val KEY = "events"
        const val MAX_ITEMS = 200
    }
}
