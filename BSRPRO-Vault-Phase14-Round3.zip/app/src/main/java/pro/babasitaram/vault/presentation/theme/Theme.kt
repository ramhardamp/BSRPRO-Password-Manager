package pro.babasitaram.vault.presentation.theme

import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = AccentPurple,
    onPrimary = Color.Black,
    secondary = AccentOrange,
    background = DarkBackground,
    surface = DarkSurface
)

private val LightColors = lightColorScheme(
    primary = AccentPurple,
    secondary = AccentOrange,
    background = LightBackground,
    surface = LightSurface
)

@Composable
fun VaultTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val target = if (darkTheme) DarkColors else LightColors
    val primary by animateColorAsState(target.primary, tween(180), label = "themePrimary")
    val secondary by animateColorAsState(target.secondary, tween(180), label = "themeSecondary")
    val background by animateColorAsState(target.background, tween(220), label = "themeBackground")
    val surface by animateColorAsState(target.surface, tween(220), label = "themeSurface")
    val onBackground by animateColorAsState(target.onBackground, tween(180), label = "themeOnBackground")
    val onSurface by animateColorAsState(target.onSurface, tween(180), label = "themeOnSurface")

    val animated = target.copy(
        primary = primary,
        secondary = secondary,
        background = background,
        surface = surface,
        onBackground = onBackground,
        onSurface = onSurface
    )

    MaterialTheme(
        colorScheme = animated,
        typography = VaultTypography,
        content = content
    )
}
