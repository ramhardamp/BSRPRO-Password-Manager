package pro.babasitaram.vault.core.util

enum class StrengthLevel(val label: String) {
    VERY_WEAK("Very weak"), WEAK("Weak"), FAIR("Fair"), GOOD("Good"), VERY_STRONG("Very strong")
}

/** Same scoring as the extension (popup.js / setup.js calcStrength) so labels match across devices. */
object PasswordStrength {
    fun score(pw: CharSequence): Int {
        if (pw.isEmpty()) return 0
        var s = 0
        var upper = false; var lower = false; var digit = false; var other = false
        for (c in pw) {
            when {
                c in 'A'..'Z' -> upper = true
                c in 'a'..'z' -> lower = true
                c in '0'..'9' -> digit = true
                else -> other = true
            }
        }
        if (pw.length >= 8) s++
        if (pw.length >= 14) s++
        if (upper && lower) s++
        if (digit) s++
        if (other) s++
        return s
    }

    fun level(pw: CharSequence): StrengthLevel = when {
        pw.isEmpty() -> StrengthLevel.VERY_WEAK
        score(pw) <= 1 -> StrengthLevel.VERY_WEAK
        score(pw) == 2 -> StrengthLevel.WEAK
        score(pw) == 3 -> StrengthLevel.FAIR
        score(pw) == 4 -> StrengthLevel.GOOD
        else -> StrengthLevel.VERY_STRONG
    }

    /** "weak" | "medium" | "strong" — the value stored in VaultEntry.strength by the extension. */
    fun bucket(pw: CharSequence): String {
        if (pw.isEmpty()) return "weak"
        val s = score(pw)
        return when { s <= 2 -> "weak"; s == 3 -> "medium"; else -> "strong" }
    }

    const val MIN_MASTER_LENGTH = 12

    fun isAcceptableMaster(pw: CharSequence): Boolean = pw.length >= MIN_MASTER_LENGTH && score(pw) >= 3
}
