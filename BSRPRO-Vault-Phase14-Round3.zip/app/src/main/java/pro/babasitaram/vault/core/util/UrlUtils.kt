package pro.babasitaram.vault.core.util

object UrlUtils {
    /** "https://www.Example.com/login?x=1" → "example.com"; "" if it can't be parsed. */
    fun domainOf(url: String): String {
        var s = url.trim().lowercase()
        if (s.isEmpty()) return ""
        s = s.substringAfter("://", s)
        s = s.substringBefore('/').substringBefore('?').substringBefore('#').substringAfterLast('@').substringBefore(':')
        return s.removePrefix("www.")
    }

    fun toOpenable(url: String): String {
        val t = url.trim()
        return if (t.contains("://")) t else "https://$t"
    }
}
