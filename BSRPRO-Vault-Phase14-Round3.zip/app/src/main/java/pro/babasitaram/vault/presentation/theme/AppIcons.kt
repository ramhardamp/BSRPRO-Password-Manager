package pro.babasitaram.vault.presentation.theme
object AppIcons { const val VAULT="🔐"; const val TOTP="🔢"; const val HEALTH="💚"; const val SETTINGS="⚙️"; const val SECURITY="🛡"; const val DATA="💾"; const val SUPPORT="❓" }
