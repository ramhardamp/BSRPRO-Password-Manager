package pro.babasitaram.vault.core.crypto

import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import pro.babasitaram.vault.core.util.VaultError

/** In-memory only. Never persisted; wiped on lock and lost on process death by design. */
@Singleton
class SessionKeyStore @Inject constructor() {
    private val lock = Any()
    private var password: CharArray? = null
    private val _unlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _unlocked.asStateFlow()

    /** Stores a private copy; the caller keeps ownership of [master] and should wipe it. */
    fun unlock(master: CharArray) = synchronized(lock) {
        password?.fill('\u0000')
        password = master.copyOf()
        _unlocked.value = true
    }

    /** Runs [block] with a temporary copy of the password which is wiped afterwards. */
    suspend fun <T> withPassword(block: suspend (CharArray) -> T): T {
        val copy = synchronized(lock) { password?.copyOf() } ?: throw VaultError.VaultLocked
        try {
            return block(copy)
        } finally {
            copy.fill('\u0000')
        }
    }

    fun lock() = synchronized(lock) {
        password?.fill('\u0000')
        password = null
        _unlocked.value = false
    }
}
