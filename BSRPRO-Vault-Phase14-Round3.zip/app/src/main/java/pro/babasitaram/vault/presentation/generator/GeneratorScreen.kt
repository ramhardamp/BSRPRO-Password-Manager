@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.generator

import androidx.activity.compose.BackHandler

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.presentation.components.PasswordField
import pro.babasitaram.vault.presentation.components.StrengthMeter
import pro.babasitaram.vault.presentation.util.CollectMessages
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*

@Composable
fun GeneratorScreen(onBack: () -> Unit, vm: GeneratorViewModel = hiltViewModel()) {
    BackHandler { onBack() }
    val state by vm.state.collectAsStateWithLifecycle()
    CollectMessages(vm.messages)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Password generator", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())) {
            TabRow(selectedTabIndex = state.mode.ordinal) {
                GeneratorMode.values().forEach { m ->
                    Tab(selected = state.mode == m, onClick = { vm.setMode(m) }, text = { Text(m.label) })
                }
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (state.mode) {
                    GeneratorMode.RANDOM -> {
                        Text("Length: ${state.options.length}")
                        Slider(
                            value = state.options.length.toFloat(),
                            onValueChange = { v -> vm.setOptions { it.copy(length = v.toInt()) } },
                            valueRange = 8f..256f
                        )
                        ToggleRow("Lowercase (a-z)", state.options.lower) { v -> vm.setOptions { it.copy(lower = v) } }
                        ToggleRow("Uppercase (A-Z)", state.options.upper) { v -> vm.setOptions { it.copy(upper = v) } }
                        ToggleRow("Digits (0-9)", state.options.digits) { v -> vm.setOptions { it.copy(digits = v) } }
                        ToggleRow("Symbols (!@#…)", state.options.symbols) { v -> vm.setOptions { it.copy(symbols = v) } }
                        ToggleRow("Avoid look-alikes (I l 1 O 0)", state.options.excludeAmbiguous) { v -> vm.setOptions { it.copy(excludeAmbiguous = v) } }
                        OutlinedTextField(
                            value = state.options.keyword,
                            onValueChange = { v -> vm.setOptions { it.copy(keyword = v.take(32)) } },
                            label = { Text("Keyword prefix (optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    GeneratorMode.PASSPHRASE -> {
                        Text("Words: ${state.words}")
                        Slider(
                            value = state.words.toFloat(),
                            onValueChange = { vm.setWords(it.toInt()) },
                            valueRange = 3f..10f,
                            steps = 6
                        )
                        OutlinedTextField(
                            value = state.separator,
                            onValueChange = vm::setSeparator,
                            label = { Text("Separator") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    GeneratorMode.PIN -> {
                        Text("PIN length: ${state.pinLength}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            (4..6).forEach { length ->
                                androidx.compose.material3.FilterChip(
                                    selected = state.pinLength == length,
                                    onClick = { vm.setPinLength(length) },
                                    label = { Text(length.toString()) }
                                )
                            }
                        }
                        Text("Use PINs for local app or account actions. Leading zeroes are allowed.")
                    }
                    GeneratorMode.MANUAL -> {
                        PasswordField(state.manual, vm::setManual, "Type a password to check its strength")
                    }
                }

                if (state.mode != GeneratorMode.MANUAL) {
                    Card(Modifier.fillMaxWidth()) {
                        Text(
                            state.generated,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                StrengthMeter(state.output)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (state.mode != GeneratorMode.MANUAL) {
                        OutlinedButton(onClick = vm::regenerate) { Text("Regenerate") }
                    }
                    Button(onClick = vm::copy, enabled = state.output.isNotEmpty()) { Text("Copy") }
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
