package pro.babasitaram.vault.data.transfer

/** What the picked file looks like (decided from its content, not its extension). */
enum class SourceKind { V3_BACKUP, DEVICE_BACKUP, PLAIN_JSON, VCARD, CSV, UNKNOWN }

enum class ImportFormat(val label: String) {
    BACKUP_V3("BSRPRO .Vault backup"),
    DEVICE_BACKUP("BSRPRO device backup"),
    JSON("BSRPRO plain JSON"),
    VAULT_CSV("BSRPRO Vault CSV"),
    CHROME("Chrome / Edge CSV"),
    BITWARDEN("Bitwarden CSV"),
    LASTPASS("LastPass CSV"),
    ONEPASSWORD("1Password CSV"),
    DASHLANE("Dashlane CSV"),
    NORDPASS("NordPass CSV"),
    KEEPASS("KeePass CSV"),
    FIREFOX("Firefox CSV"),
    GENERIC("Generic CSV"),
    VCARD("vCard contacts")
}

enum class ExportFormat(val label: String, val extension: String, val mime: String, val plaintext: Boolean) {
    V3("Encrypted backup (.Vault)", "Vault", "application/octet-stream", false),
    VAULT_CSV("BSRPRO Vault CSV", "csv", "text/csv", true),
    CHROME_CSV("Chrome CSV", "csv", "text/csv", true),
    BITWARDEN_CSV("Bitwarden CSV", "csv", "text/csv", true),
    PLAIN_JSON("Plain JSON", "json", "application/json", true)
}
