package pro.babasitaram.vault.core.crypto

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.security.keystore.StrongBoxUnavailableException
import java.security.GeneralSecurityException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.util.VaultError

interface MasterKeyManager {
    suspend fun generateOrRetrieveKey(): SecretKey          // AES-256 in Android Keystore
    suspend fun wrapKey(plaintext: ByteArray): ByteArray    // iv(12) || AES-GCM ciphertext
    suspend fun unwrapKey(wrapped: ByteArray): ByteArray
}

/** Abstraction over the key container so the manager logic is testable on the JVM. */
interface KeyBackend {
    fun get(alias: String): SecretKey?
    fun create(alias: String): SecretKey
}

class AndroidKeystoreKeyBackend : KeyBackend {
    private val keyStore: KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    override fun get(alias: String): SecretKey? = keyStore.getKey(alias, null) as? SecretKey

    override fun create(alias: String): SecretKey {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                return generate(alias, strongBox = true)
            } catch (e: StrongBoxUnavailableException) {
                // fall through to the regular TEE-backed key
            }
        }
        return generate(alias, strongBox = false)
    }

    private fun generate(alias: String, strongBox: Boolean): SecretKey {
        val builder = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(false)
        if (strongBox && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) builder.setIsStrongBoxBacked(true)
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
            .apply { init(builder.build()) }
            .generateKey()
    }

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
    }
}

class KeystoreMasterKeyManager(
    private val backend: KeyBackend,
    private val dispatcher: CoroutineDispatcher
) : MasterKeyManager {

    private val mutex = Mutex()

    @Volatile
    private var cached: SecretKey? = null

    override suspend fun generateOrRetrieveKey(): SecretKey = cached ?: mutex.withLock {
        cached ?: withContext(dispatcher) { backend.get(ALIAS) ?: backend.create(ALIAS) }.also { cached = it }
    }

    override suspend fun wrapKey(plaintext: ByteArray): ByteArray {
        val key = generateOrRetrieveKey()
        return withContext(dispatcher) {
            try {
                val cipher = Cipher.getInstance(TRANSFORMATION)
                cipher.init(Cipher.ENCRYPT_MODE, key) // Keystore generates the IV
                val iv = cipher.iv
                iv + cipher.doFinal(plaintext)
            } catch (e: GeneralSecurityException) {
                throw VaultError.CryptoFailure(e)
            }
        }
    }

    override suspend fun unwrapKey(wrapped: ByteArray): ByteArray {
        if (wrapped.size < IV_BYTES + TAG_BYTES) throw VaultError.InvalidFormat("Wrapped key too short")
        val key = generateOrRetrieveKey()
        return withContext(dispatcher) {
            try {
                val cipher = Cipher.getInstance(TRANSFORMATION)
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BYTES * 8, wrapped.copyOfRange(0, IV_BYTES)))
                cipher.doFinal(wrapped, IV_BYTES, wrapped.size - IV_BYTES)
            } catch (e: GeneralSecurityException) {
                throw VaultError.CryptoFailure(e)
            }
        }
    }

    companion object {
        const val ALIAS = "bsrpro_master_wrap_key_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_BYTES = 12
        private const val TAG_BYTES = 16
    }
}
