package pro.babasitaram.vault.di

import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import pro.babasitaram.vault.core.crypto.AndroidKeystoreKeyBackend
import pro.babasitaram.vault.core.crypto.KeyBackend
import pro.babasitaram.vault.core.crypto.KeystoreMasterKeyManager
import pro.babasitaram.vault.core.crypto.MasterKeyManager
import pro.babasitaram.vault.core.security.AndroidBiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.util.DispatcherProvider

@Module
@InstallIn(SingletonComponent::class)
object CryptoModule {
    @Provides
    @Singleton
    fun provideKeyBackend(): KeyBackend = AndroidKeystoreKeyBackend()

    @Provides
    @Singleton
    fun provideMasterKeyManager(backend: KeyBackend, dispatchers: DispatcherProvider): MasterKeyManager =
        KeystoreMasterKeyManager(backend, dispatchers.default)

    @Provides
    @Singleton
    fun provideBiometricAuthenticator(@ApplicationContext context: Context): BiometricAuthenticator =
        AndroidBiometricAuthenticator(context)
}
