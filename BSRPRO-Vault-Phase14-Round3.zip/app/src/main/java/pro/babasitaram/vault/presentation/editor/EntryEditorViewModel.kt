package pro.babasitaram.vault.presentation.editor

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.autofill.PendingSaveStore
import pro.babasitaram.vault.core.model.CustomField
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.GeneratePasswordUseCase
import pro.babasitaram.vault.domain.usecase.PasswordOptions
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage

import androidx.compose.foundation.layout.*

internal const val SAVE_CONFIRMATION_DURATION_MS = 30_000L

/** "https://www.accounts.google.com/x" -> "Google"; "jio.com" -> "Jio". Empty when nothing sensible can be derived. */
internal fun titleFromUrl(url: String): String {
    val host = pro.babasitaram.vault.core.util.UrlUtils.domainOf(url)
    if (host.isEmpty() || !host.contains('.')) return ""
    val labels = host.split('.').filter { it.isNotEmpty() }
    val secondLevel = setOf("co", "com", "org", "net", "gov", "ac", "edu")
    val core = if (labels.size >= 3 && labels[labels.size - 2] in secondLevel) labels[labels.size - 3]
    else labels[(labels.size - 2).coerceAtLeast(0)]
    return core.replaceFirstChar { it.uppercase() }
}

/** Native-app flow: sets appName + appPackage, never touches [EditorForm.url], fills an empty/auto title. */
internal fun EditorForm.withPickedApp(name: String, pkg: String): EditorForm {
    val replaceTitle = title.isBlank() || (appName.isNotBlank() && title.trim() == appName.trim())
    return copy(appName = name, appPackage = pkg, title = if (replaceTitle) name else title)
}

/**
 * Title rules (login / card / identity / note):
 *  1. what the user typed wins
 *  2. else the picked Android app's name
 *  3. else a name derived from the website
 *  4. else (card / identity) the cardholder or full name
 * Returns "" when nothing can be derived — only then is the entry rejected.
 */
internal fun EditorForm.effectiveTitle(): String {
    title.trim().takeIf { it.isNotEmpty() }?.let { return it }
    appName.trim().takeIf { it.isNotEmpty() }?.let { return it }
    titleFromUrl(url).takeIf { it.isNotEmpty() }?.let { return it }
    return when (recordType) {
        "card" -> cardholder.trim()
        "identity" -> fullName.trim()
        else -> ""
    }
}
internal fun saveConfirmationLabel(isEdit: Boolean): String = if (isEdit) "Updated" else "Saved to vault"

data class EditorForm(
    val recordType: String = "login",
    val title: String = "",
    val url: String = "",
    val username: String = "",
    val password: String = "",
    val appPin: String = "",
    val mobile: String = "",
    val totp: String = "",
    val appPackage: String = "",
    val appName: String = "",
    val notes: String = "",
    val category: String = "other",
    val folderId: String = "",
    val tags: String = "",
    val cardNumber: String = "",
    val cardholder: String = "",
    val cardExpiry: String = "",
    val cardCvv: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val address: String = "",
    val idNumber: String = "",
    val idExpiry: String = "",
    val customFields: List<CustomField> = emptyList()
)

data class EditorUiState(
    val form: EditorForm = EditorForm(),
    val isEdit: Boolean = false,
    val folders: List<Folder> = emptyList(),
    val error: String? = null,
    val saving: Boolean = false,
    val duplicate: VaultEntry? = null,
    val saved: Boolean = false
)

internal fun VaultEntry.toForm() = EditorForm(
    recordType = if (isNote) "note" else recordType.ifBlank { "login" },
    title = title, url = url, username = username, password = password, appPin = appPin, mobile = mobile, totp = totp,
    appPackage = appPackage, appName = appName,
    notes = notes, category = category, folderId = folderId, tags = tags.joinToString(", "),
    cardNumber = cardNumber, cardholder = cardholder, cardExpiry = cardExpiry, cardCvv = cardCvv,
    fullName = fullName, email = email, phone = phone, address = address, idNumber = idNumber, idExpiry = idExpiry,
    customFields = customFields
)

internal fun EditorForm.toEntry(base: VaultEntry?): VaultEntry = (base ?: VaultEntry()).copy(
    recordType = recordType,
    isNote = recordType == "note",
    title = title.trim(), url = url.trim(), username = username.trim(), password = password, appPin = appPin.filter { it in '0'..'9' }.take(6),
    mobile = mobile.trim(), totp = totp.trim(), appPackage = appPackage.trim(), appName = appName.trim(), notes = notes, category = category, folderId = folderId,
    tags = tags.split(',').map { it.trim() }.filter { it.isNotEmpty() },
    cardNumber = cardNumber.trim(), cardholder = cardholder.trim(), cardExpiry = cardExpiry.trim(), cardCvv = cardCvv.trim(),
    fullName = fullName.trim(), email = email.trim(), phone = phone.trim(), address = address.trim(),
    idNumber = idNumber.trim(), idExpiry = idExpiry.trim(),
    customFields = customFields.filter { it.k.isNotBlank() }
)

@HiltViewModel
class EntryEditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase,
    private val generator: GeneratePasswordUseCase,
    private val settings: SettingsRepository,
    private val pendingSaves: PendingSaveStore
) : ViewModel() {

    private val existing: VaultEntry? = savedStateHandle.get<String>("id")?.let { repository.entry(it) }

    /** A login captured by the autofill save flow that belongs to this editor session (new entry, or update of [existing]). */
    private val pending = pendingSaves.peek()?.takeIf { p ->
        (existing == null && p.existingId == null) || (existing != null && existing.id == p.existingId)
    }

    /** Base for a brand-new entry created from [pending] (carries appPackage / appName). */
    private val seed: VaultEntry? = if (existing == null) pending?.toCandidate() else null

    private val _state = MutableStateFlow(
        EditorUiState(
            form = when {
                pending == null -> existing?.toForm() ?: EditorForm()
                existing == null -> pending.toCandidate().toForm()
                else -> existing.toForm().copy(password = pending.password.ifEmpty { existing.password }, appPin = pending.appPin.ifEmpty { existing.appPin })
            },
            isEdit = existing != null,
            folders = repository.folders.value
        )
    )
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    init {
        if (pending != null) pendingSaves.clear()   // consumed
    }

    fun update(transform: (EditorForm) -> EditorForm) {
        _state.update { it.copy(form = transform(it.form), error = null) }
    }

    fun generatePassword() {
        viewModelScope.launch {
            val s = settings.current()
            val pw = generator(PasswordOptions(length = s.generatorDefaultLength, keyword = s.generatorKeyword, excludeAmbiguous = s.generatorExcludeSimilar))
            update { it.copy(password = pw) }
        }
    }

    /**
     * Native-app flow: appName + appPackage are set, the website field is never touched, and the title is
     * filled from the app name when it is empty (or still holds the previously picked app's name).
     */
    fun pickApp(name: String, pkg: String) {
        update { it.withPickedApp(name, pkg) }
    }

    fun dismissDuplicate() {
        _state.update { it.copy(duplicate = null) }
    }

    /** [overwrite] replaces the given duplicate; [skipDuplicateCheck] saves as a separate new entry. */
    fun save(overwrite: VaultEntry? = null, skipDuplicateCheck: Boolean = false) {
        val raw = _state.value.form
        val title = raw.effectiveTitle()
        if (title.isEmpty()) {
            _state.update { it.copy(error = "Enter a title, a website, or choose an Android app") }
            return
        }
        val form = raw.copy(title = title)
        if (form.appPin.isNotBlank() && form.appPin.length !in 4..6) {
            _state.update { it.copy(error = "PIN must contain 4 to 6 digits") }
            return
        }
        if (form.totp.isNotBlank() && Totp.current(form.totp, System.currentTimeMillis()) == null) {
            _state.update { it.copy(error = "Authenticator secret is not valid (use the Base32 key or an otpauth:// link)") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(saving = true, error = null, duplicate = null) }
            val candidate = form.toEntry(existing ?: seed)
            if (existing == null && overwrite == null && !skipDuplicateCheck) {
                val dup = repository.findDuplicate(candidate)
                if (dup != null) {
                    _state.update { it.copy(saving = false, duplicate = dup) }
                    return@launch
                }
            }
            val target = if (overwrite != null) candidate.copy(id = overwrite.id) else candidate
            when (val r = saveEntry(target, existing ?: overwrite)) {
                is VaultResult.Failure -> _state.update { it.copy(saving = false, error = r.error.toUserMessage()) }
                else -> _state.update { it.copy(saving = false, saved = true) }
            }
        }
    }
}
