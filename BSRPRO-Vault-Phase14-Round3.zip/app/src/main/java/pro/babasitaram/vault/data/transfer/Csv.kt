package pro.babasitaram.vault.data.transfer

/** RFC 4180 style CSV: quoted cells, escaped quotes, embedded delimiters / newlines, BOM, `,` `;` or tab. */
object Csv {

    fun parse(input: String): List<List<String>> {
        val text = input.removePrefix("\uFEFF")
        val first = text.lineSequence().firstOrNull().orEmpty()
        val delimiter = listOf(',', ';', '\t').maxByOrNull { countUnquoted(first, it) } ?: ','

        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cur = StringBuilder()
        var inQuote = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                ch == '"' -> {
                    if (inQuote && i + 1 < text.length && text[i + 1] == '"') {
                        cur.append('"')
                        i++
                    } else inQuote = !inQuote
                }
                ch == delimiter && !inQuote -> {
                    row.add(cur.toString())
                    cur.setLength(0)
                }
                (ch == '\n' || ch == '\r') && !inQuote -> {
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row.add(cur.toString())
                    cur.setLength(0)
                    if (row.any { it.isNotEmpty() }) rows.add(row)
                    row = ArrayList()
                }
                else -> cur.append(ch)
            }
            i++
        }
        if (cur.isNotEmpty() || row.isNotEmpty()) {
            row.add(cur.toString())
            if (row.any { it.isNotEmpty() }) rows.add(row)
        }
        return rows
    }

    private fun countUnquoted(line: String, delimiter: Char): Int {
        var count = 0
        var quoted = false
        for (ch in line) {
            if (ch == '"') quoted = !quoted else if (ch == delimiter && !quoted) count++
        }
        return count
    }

    fun cell(v: String?): String {
        val s = v ?: return ""
        return if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
    }

    fun row(vararg fields: String?): String = fields.joinToString(",") { cell(it) }
}
