package pro.babasitaram.vault.presentation.navigation

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.ContactEmergency
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.DisposableEffect
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.launch
import pro.babasitaram.vault.presentation.backup.BackupScreen
import pro.babasitaram.vault.presentation.activitylog.ActivityLogScreen
import pro.babasitaram.vault.presentation.bin.BinScreen
import pro.babasitaram.vault.presentation.editor.EntryEditorScreen
import pro.babasitaram.vault.presentation.emergency.EmergencyScreen
import pro.babasitaram.vault.presentation.files.FilesScreen
import pro.babasitaram.vault.presentation.generator.GeneratorScreen
import pro.babasitaram.vault.presentation.help.HelpScreen
import pro.babasitaram.vault.presentation.history.HistoryScreen
import pro.babasitaram.vault.presentation.mobiles.MobilesScreen
import pro.babasitaram.vault.presentation.mobiles.MobileEditorScreen
import pro.babasitaram.vault.presentation.notes.NotesScreen
import pro.babasitaram.vault.presentation.notes.NoteEditorScreen
import pro.babasitaram.vault.presentation.settings.SettingsScreen
import pro.babasitaram.vault.presentation.sharing.SharingScreen
import pro.babasitaram.vault.presentation.supportdeveloper.SupportDeveloperScreen
import pro.babasitaram.vault.presentation.totpmanager.TotpManagerScreen
import pro.babasitaram.vault.presentation.vault.EntryDetailScreen
import pro.babasitaram.vault.presentation.vault.VaultListScreen
import pro.babasitaram.vault.presentation.vaulthealth.VaultHealthScreen

object Routes {
    const val LIST = "list"
    const val DETAIL = "detail/{id}"
    const val EDIT = "edit?id={id}"
    const val NOTE_EDIT = "note-edit?id={id}"
    const val MOBILE_EDIT = "mobile-edit?id={id}"
    const val GENERATOR = "generator"
    const val SETTINGS = "settings"
    const val BACKUP = "backup"
    const val TOTP = "totp"
    const val HEALTH = "health"
    const val BIN = "bin"
    const val NOTES = "notes"
    const val FILES = "files"
    const val MOBILES = "mobiles"
    const val HISTORY = "history"
    const val HELP = "help"
    const val SHARING = "sharing"
    const val SUPPORT = "support"
    const val EMERGENCY = "emergency"
    const val ACTIVITY_LOG = "activity-log"

    fun detail(id: String) = "detail/${Uri.encode(id)}"
    fun edit(id: String? = null) = if (id == null) "edit" else "edit?id=${Uri.encode(id)}"
    fun noteEdit(id: String? = null) = if (id == null) "note-edit" else "note-edit?id=${Uri.encode(id)}"
    fun mobileEdit(id: String? = null) = if (id == null) "mobile-edit" else "mobile-edit?id=${Uri.encode(id)}"
}

private data class DrawerDestination(
    val route: String,
    val label: String,
    val icon: @Composable () -> Unit
)

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun VaultNavHost() {
    val nav = rememberNavController()
    val saveRouter: SaveRouterViewModel = hiltViewModel()
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val current by nav.currentBackStackEntryAsState()
    val route = current?.destination?.route ?: Routes.LIST

    DisposableEffect(nav) {
        onDispose {
            runCatching { nav.popBackStack(Routes.LIST, inclusive = true) }
        }
    }

    LifecycleResumeEffect(Unit) {
        saveRouter.nextRoute()?.let { pendingRoute -> nav.navigate(pendingRoute) }
        onPauseOrDispose { }
    }

    val bottomItems = remember {
        listOf(
            Routes.LIST to "Vault",
            Routes.GENERATOR to "Generator",
            Routes.TOTP to "TOTP",
            Routes.SETTINGS to "Settings"
        )
    }

    val drawerItems = remember {
        listOf(
            DrawerDestination(Routes.LIST, "Vault") { Icon(Icons.Default.Lock, null) },
            DrawerDestination(Routes.TOTP, "TOTP Manager") { Icon(Icons.Default.Security, null) },
            DrawerDestination(Routes.GENERATOR, "Password Generator") { Icon(Icons.Default.AutoAwesome, null) },
            DrawerDestination(Routes.HEALTH, "Vault Health") { Icon(Icons.Default.Shield, null) },
            DrawerDestination(Routes.NOTES, "Notes") { Icon(Icons.Default.Note, null) },
            DrawerDestination(Routes.FILES, "Files") { Icon(Icons.Default.Folder, null) },
            DrawerDestination(Routes.MOBILES, "Mobiles") { Icon(Icons.Default.PhoneAndroid, null) },
            DrawerDestination(Routes.SHARING, "Sharing") { Icon(Icons.Default.Share, null) },
            DrawerDestination(Routes.EMERGENCY, "Emergency Access") { Icon(Icons.Default.ContactEmergency, null) },
            DrawerDestination(Routes.BACKUP, "Backup & Import") { Icon(Icons.Default.Backup, null) },
            DrawerDestination(Routes.BIN, "Bin (Trash)") { Icon(Icons.Default.DeleteOutline, null) },
            DrawerDestination(Routes.HELP, "Help") { Icon(Icons.Default.HelpOutline, null) },
            DrawerDestination(Routes.ACTIVITY_LOG, "Activity Log") { Icon(Icons.Default.Security, null) },
            DrawerDestination(Routes.SUPPORT, "Support Developer") { Icon(Icons.Default.SupportAgent, null) }
        )
    }

    BackHandler(enabled = route != Routes.LIST || drawerState.isOpen) {
        if (drawerState.isOpen) scope.launch { drawerState.close() } else nav.popBackStack()
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "BSRPRO Vault",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(20.dp)
                )
                drawerItems.forEach { destination ->
                    NavigationDrawerItem(
                        icon = destination.icon,
                        label = { Text(destination.label) },
                        selected = route == destination.route,
                        onClick = {
                            scope.launch { drawerState.close() }
                            nav.navigate(destination.route) { launchSingleTop = true }
                        },
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                if (route == Routes.LIST) {
                    TopAppBar(
                        title = {
                            Text(
                                "Vault",
                                style = MaterialTheme.typography.titleLarge
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Open navigation drawer")
                            }
                        }
                    )
                }
            },
            bottomBar = {
                NavigationBar {
                    bottomItems.forEach { (destination, label) ->
                        NavigationBarItem(
                            selected = route == destination,
                            onClick = {
                                nav.navigate(destination) {
                                    popUpTo(Routes.LIST) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                when (destination) {
                                    Routes.LIST -> Icon(Icons.Default.Lock, contentDescription = null)
                                    Routes.GENERATOR -> Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                    Routes.TOTP -> Icon(Icons.Default.Key, contentDescription = null)
                                    Routes.SETTINGS -> Icon(Icons.Default.Settings, contentDescription = null)
                                    else -> Icon(Icons.Default.Lock, contentDescription = null)
                                }
                            },
                            label = { Text(label) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (route == Routes.LIST) {
                    androidx.compose.material3.FloatingActionButton(
                        onClick = { nav.navigate(Routes.edit()) }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add entry")
                    }
                }
            }
        ) { innerPadding ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = nav,
                    startDestination = Routes.LIST
                ) {
                    composable(Routes.LIST) {
                        VaultListScreen(
                            onOpen = { entryId -> nav.navigate(Routes.detail(entryId)) },
                            onAdd = { nav.navigate(Routes.edit()) },
                            onGenerator = { nav.navigate(Routes.GENERATOR) },
                            onSettings = { nav.navigate(Routes.SETTINGS) },
                            onEdit = { id -> nav.navigate(Routes.edit(id)) },
                            onShare = { id -> nav.navigate("${Routes.SHARING}?id=${Uri.encode(id)}") }
                        )
                    }
                    composable(
                        route = Routes.DETAIL,
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) {
                        EntryDetailScreen(
                            onBack = { nav.popBackStack() },
                            onEdit = { entryId -> nav.navigate(Routes.edit(entryId)) }
                        )
                    }
                    composable(
                        route = Routes.EDIT,
                        arguments = listOf(
                            navArgument("id") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            }
                        )
                    ) {
                        EntryEditorScreen(onDone = { nav.popBackStack() })
                    }
                    composable(
                        route = Routes.NOTE_EDIT,
                        arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })
                    ) { NoteEditorScreen(onDone = { nav.popBackStack() }) }
                    composable(
                        route = Routes.MOBILE_EDIT,
                        arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })
                    ) { MobileEditorScreen(onDone = { nav.popBackStack() }) }
                    composable(Routes.GENERATOR) { GeneratorScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.SETTINGS) {
                        SettingsScreen(
                            onBack = { nav.popBackStack() },
                            onOpenBackup = { nav.navigate(Routes.BACKUP) },
                            onOpenActivityLog = { nav.navigate(Routes.ACTIVITY_LOG) }
                        )
                    }
                    composable(Routes.BACKUP) { BackupScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.TOTP) { TotpManagerScreen(onBack = { nav.popBackStack() }, onAdd = { nav.navigate(Routes.edit()) }, onOpen = { id -> nav.navigate(Routes.detail(id)) }, onEdit = { id -> nav.navigate(Routes.edit(id)) }, onShare = { id -> nav.navigate("${Routes.SHARING}?id=${Uri.encode(id)}") }) }
                    composable(Routes.HEALTH) { VaultHealthScreen(onBack = { nav.popBackStack() }, onOpenEntry = { id -> nav.navigate(Routes.detail(id)) }) }
                    composable(Routes.BIN) { BinScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.NOTES) { NotesScreen(onBack = { nav.popBackStack() }, onAdd = { nav.navigate(Routes.noteEdit()) }, onEdit = { id -> nav.navigate(Routes.noteEdit(id)) }, onShare = { id -> nav.navigate("${Routes.SHARING}?id=${Uri.encode(id)}") }) }
                    composable(Routes.FILES) { FilesScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.MOBILES) { MobilesScreen(onBack = { nav.popBackStack() }, onAdd = { nav.navigate(Routes.mobileEdit()) }, onEdit = { id -> nav.navigate(Routes.mobileEdit(id)) }) }
                    composable(Routes.HISTORY) { HistoryScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.HELP) { HelpScreen(onBack = { nav.popBackStack() }) }
                    composable("${Routes.SHARING}?id={id}", arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })) { SharingScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.SUPPORT) { SupportDeveloperScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.EMERGENCY) { EmergencyScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.ACTIVITY_LOG) { ActivityLogScreen(onBack = { nav.popBackStack() }) }
                }
            }
        }
    }
}
