package pro.babasitaram.vault.presentation.vault

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.TotpCode
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase
import pro.babasitaram.vault.domain.usecase.GenerateTotpCodeUseCase
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions

@HiltViewModel
class EntryDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase,
    private val deleteEntry: DeleteEntryUseCase,
    private val totpUseCase: GenerateTotpCodeUseCase,
    private val clipboard: ClipboardActions
) : ViewModel() {

    val id: String = savedStateHandle.get<String>("id").orEmpty()

    val entry: StateFlow<VaultEntry?> = repository.entries
        .map { list -> list.firstOrNull { it.id == id } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), repository.entry(id))

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    fun totp(secret: String, nowMs: Long): TotpCode? = totpUseCase(secret, nowMs)

    fun copy(label: String, text: String) {
        viewModelScope.launch { _messages.send(clipboard.copy(text, label)) }
    }

    fun toggleStar() {
        val e = entry.value ?: return
        viewModelScope.launch { saveEntry(e.copy(starred = !e.starred), existing = e) }
    }

    fun delete() {
        viewModelScope.launch { deleteEntry(id) }
    }
}
