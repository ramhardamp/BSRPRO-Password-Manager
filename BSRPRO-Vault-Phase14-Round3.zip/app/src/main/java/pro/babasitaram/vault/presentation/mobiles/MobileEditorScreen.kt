@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.mobiles

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun MobileEditorScreen(
    onDone: () -> Unit,
    vm: MobileEditorViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    BackHandler(enabled = !state.saving) { onDone() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.existing == null) "Add Mobile Entry" else "Edit Mobile Entry", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onDone, enabled = !state.saving) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = { Button(onClick = vm::save, enabled = !state.saving && !state.saved) { Text("Save") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            OutlinedTextField(state.title, vm::setTitle, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(state.number, vm::setNumber, label = { Text("Mobile number") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(state.notes, vm::setNotes, label = { Text("Notes") }, minLines = 5, modifier = Modifier.fillMaxWidth())
        }
    }
}
