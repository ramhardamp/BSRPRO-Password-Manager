package pro.babasitaram.vault.autofill

import javax.inject.Inject
import javax.inject.Singleton
import pro.babasitaram.vault.core.model.VaultEntry

/** A credential captured by the autofill save flow, waiting for the user to review it in the editor. */
data class PendingSave(
    val packageName: String,
    val webDomain: String?,
    val username: String,
    val password: String,
    val createdAt: Long,
    val existingId: String? = null,
    val appPin: String = ""
) {
    val displayName: String
        get() = webDomain?.removePrefix("www.")?.ifEmpty { null } ?: packageName.substringAfterLast('.')

    fun toCandidate(): VaultEntry {
        val host = webDomain?.removePrefix("www.")?.takeIf { it.isNotEmpty() }
        val pretty = (host?.substringBefore('.') ?: packageName.substringAfterLast('.'))
            .replaceFirstChar { it.uppercase() }
        return VaultEntry(
            title = pretty,
            url = host?.let { "https://$it" } ?: "",
            username = username,
            password = password,
            appPin = appPin,
            appPackage = if (host == null) packageName else "",
            appName = if (host == null) pretty else ""
        )
    }
}

/** In-memory only (never written to disk), single slot, expires after [TTL_MS]. */
@Singleton
class PendingSaveStore @Inject constructor() {
    internal var clock: () -> Long = { System.currentTimeMillis() }
    private var current: PendingSave? = null

    @Synchronized
    fun put(p: PendingSave) {
        current = p
    }

    @Synchronized
    fun peek(): PendingSave? {
        val c = current ?: return null
        if (clock() - c.createdAt > TTL_MS) {
            current = null
            return null
        }
        return c
    }

    @Synchronized
    fun attach(existingId: String?) {
        current = current?.copy(existingId = existingId)
    }

    @Synchronized
    fun clear() {
        current = null
    }

    companion object {
        const val TTL_MS = 30 * 1000L
    }
}
