@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.mobiles

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages

@Composable
fun MobilesScreen(
    onBack: () -> Unit = {},
    onAdd: () -> Unit = {},
    onEdit: (String) -> Unit = {},
    vm: MobilesViewModel = hiltViewModel()
) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    Scaffold(
        topBar = { TopAppBar(title = { Text("Mobiles", style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Default.Add, null) }, text = { Text("Add Mobile Entry") }) }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState("No mobile entries", "Create a mobile entry to store a number, notes and history.", Modifier.padding(padding).fillMaxWidth())
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(entries, key = { it.id }) { entry ->
                    MobileItem(entry, onEdit = { onEdit(entry.id) }, onCopy = { vm.copy(entry.mobile.ifBlank { entry.phone }) }, onDelete = { vm.delete(entry.id) })
                }
            }
        }
    }
}

@Composable
private fun MobileItem(entry: VaultEntry, onEdit: () -> Unit, onCopy: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val number = entry.mobile.ifBlank { entry.phone }
    Card(Modifier.fillMaxWidth().combinedClickable(onClick = { detail = true }, onLongClick = { menu = true })) {
        Row(Modifier.padding(16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(entry.title.ifBlank { "Mobile entry" }, style = MaterialTheme.typography.titleMedium)
                Text(number)
            }
            IconButton(onClick = onCopy) { Icon(Icons.Default.ContentCopy, "Copy number") }
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
        }
    }
    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
        DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
        DropdownMenuItem(text = { Text("Copy number") }, onClick = { menu = false; onCopy() })
        DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; confirmDelete = true })
    }
    if (detail) {
        AlertDialog(
            onDismissRequest = { detail = false },
            title = { Text(entry.title.ifBlank { "Mobile entry" }) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(number); if (entry.notes.isNotBlank()) Text(entry.notes) } },
            confirmButton = { TextButton(onClick = { detail = false; onEdit() }) { Text("Edit") } },
            dismissButton = { TextButton(onClick = { detail = false; onCopy() }) { Text("Copy number") } }
        )
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("Move to Bin?") }, text = { Text("This mobile entry can be restored from Bin.") }, confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Move to Bin") } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } })
}
