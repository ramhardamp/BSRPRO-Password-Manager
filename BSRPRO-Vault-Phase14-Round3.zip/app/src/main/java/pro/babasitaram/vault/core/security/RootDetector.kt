package pro.babasitaram.vault.core.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.File

enum class RootStatus { NotRooted, Rooted, Suspicious }

interface RootEnvironment {
    val buildTags: String?
    fun fileExists(path: String): Boolean
    fun isPackageInstalled(packageName: String): Boolean
}

/** Non-blocking heuristic: the UI only shows a warning banner, it never blocks the user. */
class RootDetector(private val env: RootEnvironment) {

    fun check(): RootStatus {
        val rooted = SU_PATHS.any { env.fileExists(it) } ||
            MAGISK_PATHS.any { env.fileExists(it) } ||
            ROOT_MANAGER_PACKAGES.any { env.isPackageInstalled(it) }
        if (rooted) return RootStatus.Rooted

        val suspicious = env.buildTags?.contains("test-keys") == true ||
            BUSYBOX_PATHS.any { env.fileExists(it) } ||
            XPOSED_PACKAGES.any { env.isPackageInstalled(it) }
        return if (suspicious) RootStatus.Suspicious else RootStatus.NotRooted
    }

    private companion object {
        val SU_PATHS = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su",
            "/system/sd/xbin/su", "/data/local/xbin/su", "/data/local/bin/su", "/data/local/su"
        )
        val MAGISK_PATHS = listOf("/sbin/.magisk", "/data/adb/magisk", "/data/adb/modules")
        val BUSYBOX_PATHS = listOf("/system/xbin/busybox", "/system/bin/busybox", "/sbin/busybox")
        val ROOT_MANAGER_PACKAGES = listOf("com.topjohnwu.magisk", "eu.chainfire.supersu")
        val XPOSED_PACKAGES = listOf("de.robv.android.xposed.installer", "org.lsposed.manager")
    }
}

class AndroidRootEnvironment(private val context: Context) : RootEnvironment {
    override val buildTags: String? get() = Build.TAGS

    override fun fileExists(path: String): Boolean = runCatching { File(path).exists() }.getOrDefault(false)

    override fun isPackageInstalled(packageName: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(packageName, 0)
        }
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }
}
