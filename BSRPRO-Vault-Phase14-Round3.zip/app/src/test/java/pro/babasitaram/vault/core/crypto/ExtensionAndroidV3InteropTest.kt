package pro.babasitaram.vault.core.crypto

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

class ExtensionAndroidV3InteropTest {
    @Test
    fun `extension style V3 backup decrypts with Android crypto contract`() {
        val resource = javaClass.classLoader?.getResource("golden/extension_android_v3_fixture.json")
            ?: error("cross-platform fixture missing")
        val container = resource.readText()
        val plaintext = kotlinx.coroutines.runBlocking {
            VaultCrypto.decryptV3(container, "CrossPlatform#V3!".toCharArray())
        }
        val root = VaultJson.parseToJsonElement(plaintext).jsonObject
        assertEquals("BSRPRO.Vault.Payload", root["schema"]?.jsonPrimitive?.content)
        assertEquals("3", root["version"]?.jsonPrimitive?.content)
        assertTrue(root["entries"]?.toString()?.contains("ext-1") == true)
    }
}
