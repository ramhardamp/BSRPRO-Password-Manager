package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test

class PendingSaveStoreTest {
    private fun p(t: Long, domain: String? = "www.example.com", pkg: String = "com.android.chrome") =
        PendingSave(pkg, domain, "me", "pw", t)

    @Test fun `expires after the ttl and is single slot`() {
        var now = 0L
        val s = PendingSaveStore().also { it.clock = { now } }
        s.put(p(0))
        now = PendingSaveStore.TTL_MS
        assertEquals("pw", s.peek()?.password)
        now = PendingSaveStore.TTL_MS + 1
        assertNull(s.peek())
    }

    @Test fun `attach and clear`() {
        val s = PendingSaveStore().also { it.clock = { 0L } }
        s.put(p(0))
        s.attach("id-1")
        assertEquals("id-1", s.peek()?.existingId)
        s.clear()
        assertNull(s.peek())
    }

    @Test fun `web candidate gets https url and title from the domain`() {
        val c = p(0).toCandidate()
        assertEquals("Example", c.title)
        assertEquals("https://example.com", c.url)
        assertEquals("", c.appPackage)
        assertEquals("me", c.username)
    }

    @Test fun `app candidate preserves captured PIN separately from password`() {
        val captured = p(0, domain = null, pkg = "com.example.bank").copy(password = "web-pass", appPin = "0420")
        val candidate = captured.toCandidate()
        assertEquals("web-pass", candidate.password)
        assertEquals("0420", candidate.appPin)
    }

    @Test fun `app candidate is keyed by package`() {
        val c = p(0, domain = null, pkg = "com.example.bank").toCandidate()
        assertEquals("Bank", c.title)
        assertEquals("com.example.bank", c.appPackage)
        assertEquals("", c.url)
    }
}
