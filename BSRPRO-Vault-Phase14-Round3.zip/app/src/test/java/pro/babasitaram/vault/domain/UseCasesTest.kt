package pro.babasitaram.vault.domain

import io.mockk.mockk
import io.mockk.verify
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.crypto.GoldenVectors
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.RateLimiter
import pro.babasitaram.vault.core.security.VaultClipboardManager
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.data.repository.AuthRepositoryImpl
import pro.babasitaram.vault.data.repository.VaultRepositoryImpl
import pro.babasitaram.vault.domain.usecase.CreateVaultUseCase
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase
import pro.babasitaram.vault.domain.usecase.RestoreBackupUseCase
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.domain.usecase.UnlockVaultUseCase
import pro.babasitaram.vault.testing.FakeCredentialStore
import pro.babasitaram.vault.testing.FakeLockoutStore

class UseCasesTest {
    @TempDir
    lateinit var dir: File

    private var now = 1_000_000L
    private val good = "Str0ng!Passw0rd"

    private inner class Env {
        val blob = FileVaultBlobStore(dir, Dispatchers.IO)
        val session = SessionKeyStore()
        val repo = VaultRepositoryImpl(blob, session, mockk<VaultDao>(relaxed = true))
        val auth = AuthRepositoryImpl(blob, RateLimiter(FakeLockoutStore(), clock = { now }), FakeCredentialStore())
        val create = CreateVaultUseCase(blob, session, repo, auth)
        val unlock = UnlockVaultUseCase(blob, session, repo, auth)
        val clipboard = mockk<VaultClipboardManager>(relaxed = true)
        val lock = LockVaultUseCase(session, blob, repo, clipboard)
        val save = SaveEntryUseCase(repo)
        suspend fun createVault() = create(good.toCharArray(), good.toCharArray())
    }

    private fun failure(r: VaultResult<*>): VaultError = (r as VaultResult.Failure).error

    // ── create ──
    @Test
    fun `create rejects mismatching passwords`() = runTest {
        val e = Env()
        assertTrue(failure(e.create(good.toCharArray(), "other".toCharArray())) is VaultError.Validation)
    }

    @Test
    fun `create rejects weak master password`() = runTest {
        val e = Env()
        val weak = "abcdefghijkl".toCharArray()
        assertTrue(failure(e.create(weak, weak.copyOf())) is VaultError.Validation)
        val short = "Ab1!".toCharArray()
        assertTrue(failure(e.create(short, short.copyOf())) is VaultError.Validation)
    }

    @Test
    fun `create makes an unlocked vault`() = runTest {
        val e = Env()
        assertTrue(e.createVault() is VaultResult.Success)
        assertTrue(e.session.isUnlocked.value)
        assertTrue(e.blob.exists())
    }

    @Test
    fun `create refuses when a vault already exists`() = runTest {
        val e = Env()
        e.createVault()
        assertTrue(failure(e.createVault()) is VaultError.Validation)
    }

    // ── unlock / lock ──
    @Test
    fun `lock then unlock restores entries`() = runTest {
        val e = Env()
        e.createVault()
        e.save(VaultEntry(title = "Mail", password = "pw"))
        e.lock()
        assertFalse(e.session.isUnlocked.value)
        assertTrue(e.repo.entries.value.isEmpty())
        assertTrue(e.unlock(good.toCharArray()) is VaultResult.Success)
        assertEquals(listOf("Mail"), e.repo.entries.value.map { it.title })
    }

    @Test
    fun `lock clears the clipboard`() = runTest {
        val e = Env()
        e.createVault()
        e.lock()
        verify { e.clipboard.clearNow() }
    }

    @Test
    fun `unlock without a vault reports VaultNotFound`() = runTest {
        assertEquals(VaultError.VaultNotFound, failure(Env().unlock(good.toCharArray())))
    }

    @Test
    fun `wrong password fails and five failures lock out`() = runTest {
        val e = Env()
        e.createVault()
        e.lock()
        repeat(5) { assertEquals(VaultError.InvalidMasterPassword, failure(e.unlock("wrong-password".toCharArray()))) }
        assertTrue(failure(e.unlock(good.toCharArray())) is VaultError.RateLimited)
        now += 31_000
        assertTrue(e.unlock(good.toCharArray()) is VaultResult.Success)
    }

    // ── restore from the extension's backup ──
    @Test
    fun `restore from a real extension V3 container (unicode password)`() = runTest {
        val v = GoldenVectors.V3[1]
        val e = Env()
        val r = e.create.let { RestoreBackupUseCase(it) }(v.encoded, v.password.toCharArray())
        assertEquals(VaultResult.Success(1), r)
        assertEquals("com.example.app", e.repo.entries.value.single().appPackage)
        e.lock()
        assertTrue(e.unlock(v.password.toCharArray()) is VaultResult.Success)
    }

    @Test
    fun `restore with wrong password or foreign file fails cleanly`() = runTest {
        val v = GoldenVectors.V3[0]
        val e = Env()
        val restore = RestoreBackupUseCase(e.create)
        assertEquals(VaultError.InvalidMasterPassword, failure(restore(v.encoded, "nope-nope-nope".toCharArray())))
        assertTrue(failure(restore(v.encoded.replace("BSRPRO.Vault", "Other.Vault"), v.password.toCharArray())) is VaultError.InvalidFormat)
        assertFalse(e.blob.exists())
    }

    // ── save entry ──
    @Test
    fun `new entry gets id, timestamps and strength`() = runTest {
        val e = Env()
        e.createVault()
        val saved = (e.save(VaultEntry(title = "Bank", password = "Abcdefg1!xyzabc"), now = 5_000) as VaultResult.Success).value
        assertTrue(saved.id.startsWith("v_"))
        assertEquals(5_000, saved.createdAt)
        assertEquals("strong", saved.strength)
        assertEquals(1, e.repo.entries.value.size)
    }

    @Test
    fun `editing a password pushes the old one into history and records the edit`() = runTest {
        val e = Env()
        e.createVault()
        val first = (e.save(VaultEntry(title = "T", password = "old-pass"), now = 1) as VaultResult.Success).value
        val second = (e.save(first.copy(password = "new-pass"), existing = first, now = 2) as VaultResult.Success).value
        assertEquals("old-pass", second.passwordHistory.first().pw)
        assertEquals(1, second.createdAt)
        assertEquals(2, second.updatedAt)
        assertTrue(second.editHistory.first().fields.contains("password"))
    }

    @Test
    fun `changing app PIN is recorded without treating it as website password history`() = runTest {
        val e = Env()
        e.createVault()
        val first = (e.save(VaultEntry(title = "Bank", appPin = "0123"), now = 1) as VaultResult.Success).value
        val updated = (e.save(first.copy(appPin = "0456"), existing = first, now = 2) as VaultResult.Success).value
        assertEquals("0456", updated.appPin)
        assertTrue(updated.editHistory.first().fields.contains("appPin"))
        assertTrue(updated.passwordHistory.isEmpty())
    }

    @Test
    fun `password history is capped at 20`() = runTest {
        val e = Env()
        e.createVault()
        var cur = (e.save(VaultEntry(title = "T", password = "p0"), now = 1) as VaultResult.Success).value
        repeat(25) { i -> cur = (e.save(cur.copy(password = "p${i + 1}"), existing = cur, now = 2L + i) as VaultResult.Success).value }
        assertEquals(20, cur.passwordHistory.size)
        assertNotEquals("p0", cur.passwordHistory.first().pw)
    }
}
