package pro.babasitaram.vault.core.model

import kotlinx.serialization.decodeFromString
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class VaultEntryBackwardCompatibilityTest {
    @Test fun `legacy entry without appPin decodes with empty default`() {
        val entry = VaultJson.decodeFromString<VaultEntry>("""{"id":"legacy-1","title":"Old entry","password":"kept"}""")
        assertEquals("kept", entry.password)
        assertEquals("", entry.appPin)
    }
}
