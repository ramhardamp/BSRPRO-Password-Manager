package pro.babasitaram.vault.core.util

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class TotpRoadmapVectorTest {
    /**
     * ROADMAP.md lists "JBSWY3DPEHPK3PXP @ 1600000000 → 282760". Recomputing it independently
     * (RFC 4226 HOTP over counter 53333333, HMAC-SHA1) gives 368941; the RFC 6238 vectors in TotpTest pass,
     * so the roadmap number is a typo. This pins the correct value.
     */
    @Test fun `roadmap secret at 1600000000`() {
        assertEquals("368941", Totp.current("JBSWY3DPEHPK3PXP", 1_600_000_000_000L)?.code)
    }

    @Test fun `code flips exactly on the 30 second boundary`() {
        // 1_600_000_020_000 ms = 30 * 53_333_334 s, the start of the next period
        val before = Totp.current("JBSWY3DPEHPK3PXP", 1_600_000_019_999L)!!
        val at = Totp.current("JBSWY3DPEHPK3PXP", 1_600_000_020_000L)!!
        assertEquals(1, before.secondsRemaining)
        assertEquals(30, at.secondsRemaining)
        assert(before.code != at.code)
    }
}
