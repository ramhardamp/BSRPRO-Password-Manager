package pro.babasitaram.vault.data

import java.io.File
import java.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertArrayEquals
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore

class FileVaultBlobStoreTest {
    @TempDir
    lateinit var dir: File

    private val pw = "Master#Pass123456".toCharArray()
    private fun store() = FileVaultBlobStore(dir, Dispatchers.IO)
    private fun data(n: Int) = VaultData(
        listOf(VaultEntry(id = "id$n", title = "Entry $n", password = "pw$n", appPackage = "com.app$n")),
        listOf(Folder(id = "f", name = "Work"))
    )
    private fun salt(f: File) = Base64.getDecoder().decode(f.readText().trim()).copyOfRange(0, 16)

    @Test
    fun `no vault until first write`() = runTest {
        val s = store()
        assertFalse(s.exists())
        s.write(data(1), pw)
        assertTrue(s.exists())
    }

    @Test
    fun `write then read round trips entries and folders`() = runTest {
        val s = store()
        s.write(data(1), pw)
        val back = s.read(pw)
        assertEquals(data(1), back)
    }

    @Test
    fun `wrong password is rejected`() = runTest {
        val s = store()
        s.write(data(1), pw)
        assertThrows<VaultError.InvalidMasterPassword> { s.read("wrong-password".toCharArray()) }
    }

    @Test
    fun `read without a vault fails with VaultNotFound`() = runTest {
        assertThrows<VaultError.VaultNotFound> { store().read(pw) }
    }

    @Test
    fun `saves reuse the derived key but still produce fresh ciphertext`() = runTest {
        val s = store()
        s.write(data(1), pw)
        val first = File(dir, "vault.blob").readText()
        val salt1 = salt(File(dir, "vault.blob"))
        s.write(data(2), pw)
        assertArrayEquals(salt1, salt(File(dir, "vault.blob")))
        assertTrue(first != File(dir, "vault.blob").readText())
        assertEquals(data(2), s.read(pw))
    }

    @Test
    fun `writing with a new password re-derives and invalidates the old one`() = runTest {
        val s = store()
        s.write(data(1), pw)
        val salt1 = salt(File(dir, "vault.blob"))
        val other = "Another#Pass987654".toCharArray()
        s.write(data(1), other)
        assertFalse(salt1.contentEquals(salt(File(dir, "vault.blob"))))
        assertThrows<VaultError.InvalidMasterPassword> { s.read(pw) }
        assertEquals(data(1), s.read(other))
    }

    @Test
    fun `previous two versions are kept as backups`() = runTest {
        val s = store()
        s.write(data(1), pw)
        s.write(data(2), pw)
        s.write(data(3), pw)
        assertTrue(VaultCrypto.decryptBlocking(File(dir, "vault.blob").readText().trim(), pw).contains("Entry 3"))
        assertTrue(VaultCrypto.decryptBlocking(File(dir, "vault.blob.bak").readText().trim(), pw).contains("Entry 2"))
        assertTrue(VaultCrypto.decryptBlocking(File(dir, "vault.blob.bak2").readText().trim(), pw).contains("Entry 1"))
    }

    @Test
    fun `corrupted main file falls back to the previous version`() = runTest {
        val s = store()
        s.write(data(1), pw)
        s.write(data(2), pw)
        File(dir, "vault.blob").writeText("###not-a-vault###")
        assertEquals(data(1), store().read(pw))
    }

    @Test
    fun `leftover tmp file from a crash is ignored and the next write succeeds`() = runTest {
        val s = store()
        s.write(data(1), pw)
        File(dir, "vault.blob.tmp").writeText("half written garbage")
        assertEquals(data(1), store().read(pw))
        s.write(data(2), pw)
        assertEquals(data(2), s.read(pw))
        assertFalse(File(dir, "vault.blob.tmp").exists())
    }

    @Test
    fun `raw read and write move the blob unchanged`() = runTest {
        val s = store()
        s.write(data(1), pw)
        val raw = s.readRaw()!!
        val other = FileVaultBlobStore(File(dir, "copy").also { it.mkdirs() }, Dispatchers.IO)
        other.writeRaw(raw)
        assertEquals(data(1), other.read(pw))
    }

    @Test
    fun `deleteAll removes everything`() = runTest {
        val s = store()
        s.write(data(1), pw)
        s.write(data(2), pw)
        s.deleteAll()
        assertFalse(s.exists())
        assertEquals(0, dir.listFiles()!!.size)
    }
}
