package pro.babasitaram.vault.testing

import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import pro.babasitaram.vault.core.crypto.KeyBackend
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.core.security.LockoutState
import pro.babasitaram.vault.core.security.LockoutStore
import pro.babasitaram.vault.data.local.preferences.BiometricCredentialStore
import pro.babasitaram.vault.domain.repository.SettingsRepository

class SoftwareKeyBackend : KeyBackend {
    val keys = mutableMapOf<String, SecretKey>()
    override fun get(alias: String) = keys[alias]
    override fun create(alias: String): SecretKey =
        KeyGenerator.getInstance("AES").apply { init(256) }.generateKey().also { keys[alias] = it }
}

class FakeLockoutStore : LockoutStore {
    var state = LockoutState()
    override suspend fun load() = state
    override suspend fun save(state: LockoutState) { this.state = state }
}

class FakeCredentialStore : BiometricCredentialStore {
    private var saved: CharArray? = null
    override suspend fun exists() = saved != null
    override suspend fun save(password: CharArray) { saved = password.copyOf() }
    override suspend fun load() = saved?.copyOf()
    override suspend fun clear() { saved = null }
}

class FakeSettings(initial: VaultSettings = VaultSettings()) : SettingsRepository {
    private val flow = MutableStateFlow(initial)
    override val settings: Flow<VaultSettings> = flow
    override suspend fun current() = flow.value
    override suspend fun update(transform: (VaultSettings) -> VaultSettings) { flow.value = transform(flow.value) }
}
