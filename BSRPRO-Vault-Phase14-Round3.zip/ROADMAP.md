ये मेरा एक्सटेंशन है, इसके लिए बैकअप की हुई एक्सटेंशन में चलनी चाहिए, अन्य ऐप में नहीं चलनी चाहिए। ऐसा लॉजिक लगा हुआ है, बाकी रोडमैप दिया है मोबाइल एप्लिकेशन का बना के दो.

markdown
# BSRPRO Password Manager — Android Native Roadmap

**Target:** Production-grade password manager for Android 8.0+ (API 26+)
**Language:** Kotlin (100%)
**UI:** Jetpack Compose
**Architecture:** MVVM + Clean Architecture (3-layer)
**Package:** `pro.babasitaram.vault`
**Compatibility:** Must interoperate with existing browser extension vault format (AES-256-GCM, PBKDF2 600k, V3 backup)

---

## 🎯 Non-Negotiable Requirements

1. **Zero plaintext persistence** — Master password never touches disk
2. **Hardware-backed crypto** — Android Keystore for key wrapping
3. **Autofill service** — Full Android Autofill Framework integration
4. **Biometric unlock** — Fingerprint + Face via `BiometricPrompt`
5. **Screenshot blocking** — `FLAG_SECURE` on all vault screens
6. **Clipboard auto-clear** — 30s default, user configurable
7. **Vault format compatibility** — Must decrypt backups from the web extension
8. **No network by default** — Offline-first, sync optional (Phase 12+)
9. **Root detection warning** — Non-blocking but visible
10. **Accessibility** — TalkBack fully supported

---

## 🛠️ Tech Stack (Locked Versions)
Kotlin: 2.0.20
Gradle: 8.7
AGP: 8.5.2
Min SDK: 26 (Android 8.0)
Target SDK: 35 (Android 15)
Compile SDK: 35

Jetpack Compose BOM: 2024.09.02
Compose Compiler: 2.0.20

AndroidX Core: 1.13.1
Lifecycle: 2.8.6
Navigation Compose: 2.8.1
Room: 2.6.1
DataStore: 1.1.1
Biometric: 1.2.0-alpha05
Security-Crypto: 1.1.0-alpha06
WorkManager: 2.9.1
Hilt (DI): 2.52
Kotlinx Serialization: 1.7.3
Kotlinx Coroutines: 1.9.0
Timber (logging): 5.0.1
Tink (crypto): 1.15.0 ← Google's crypto library, use for AEAD helpers
ZXing (QR): 3.5.3
Coil (images): 2.7.0

text

**Testing:**
JUnit 5: 5.11.0
Mockk: 1.13.12
Turbine: 1.2.0
Compose UI Test: via BOM
AndroidX Test: 1.6.1
Robolectric: 4.13

text

---

## 📁 Package Structure
pro.babasitaram.vault/
├── BsrApplication.kt # @HiltAndroidApp
├── MainActivity.kt # Single activity, Compose host
│
├── core/
│ ├── crypto/
│ │ ├── VaultCrypto.kt # PBKDF2, AES-GCM, V3 backup
│ │ ├── MasterKeyManager.kt # Android Keystore wrapper
│ │ ├── SessionKeyStore.kt # In-memory session key
│ │ └── SecureRandomExt.kt
│ ├── security/
│ │ ├── BiometricAuthenticator.kt
│ │ ├── RootDetector.kt
│ │ ├── ScreenshotGuard.kt # FLAG_SECURE helper
│ │ └── ClipboardManager.kt # Auto-clear
│ ├── model/
│ │ ├── VaultEntry.kt
│ │ ├── Folder.kt
│ │ ├── Attachment.kt
│ │ └── VaultSettings.kt
│ ├── util/
│ │ ├── Result.kt # Sealed result type
│ │ ├── DispatcherProvider.kt
│ │ └── FlowExt.kt
│ └── constants/
│ └── VaultConstants.kt
│
├── data/
│ ├── local/
│ │ ├── db/
│ │ │ ├── VaultDatabase.kt # Room DB (encrypted blobs only)
│ │ │ ├── VaultDao.kt
│ │ │ └── entities/VaultEntity.kt
│ │ ├── preferences/
│ │ │ └── SettingsDataStore.kt
│ │ └── blob/
│ │ └── VaultBlobStore.kt # Encrypted blob on disk
│ ├── repository/
│ │ ├── VaultRepository.kt
│ │ ├── AuthRepository.kt
│ │ └── BackupRepository.kt
│ └── import/
│ ├── CsvImporter.kt
│ ├── VaultCsvImporter.kt
│ └── CsvExporter.kt
│
├── domain/
│ ├── usecase/
│ │ ├── CreateVaultUseCase.kt
│ │ ├── UnlockVaultUseCase.kt
│ │ ├── LockVaultUseCase.kt
│ │ ├── GetEntriesUseCase.kt
│ │ ├── SaveEntryUseCase.kt
│ │ ├── DeleteEntryUseCase.kt
│ │ ├── GeneratePasswordUseCase.kt
│ │ ├── GenerateTotpCodeUseCase.kt
│ │ └── BackupVaultUseCase.kt
│ └── repository/
│ └── (interfaces for data layer)
│
├── presentation/
│ ├── theme/
│ │ ├── Color.kt
│ │ ├── Type.kt
│ │ └── Theme.kt
│ ├── navigation/
│ │ └── VaultNavHost.kt
│ ├── setup/
│ │ ├── SetupScreen.kt
│ │ └── SetupViewModel.kt
│ ├── lock/
│ │ ├── LockScreen.kt
│ │ ├── PinPad.kt
│ │ └── LockViewModel.kt
│ ├── vault/
│ │ ├── VaultListScreen.kt
│ │ ├── VaultListViewModel.kt
│ │ ├── EntryDetailScreen.kt
│ │ └── EntryDetailViewModel.kt
│ ├── editor/
│ │ ├── EntryEditorScreen.kt
│ │ └── EntryEditorViewModel.kt
│ ├── settings/
│ │ ├── SettingsScreen.kt
│ │ └── SettingsViewModel.kt
│ ├── generator/
│ │ ├── GeneratorScreen.kt
│ │ └── GeneratorViewModel.kt
│ ├── backup/
│ │ ├── BackupScreen.kt
│ │ └── BackupViewModel.kt
│ └── components/
│ ├── PasswordField.kt
│ ├── StrengthMeter.kt
│ ├── SearchBar.kt
│ └── EmptyState.kt
│
├── autofill/
│ ├── VaultAutofillService.kt # Extends AutofillService
│ ├── AutofillParser.kt # AssistStructure → fields
│ ├── AutofillDatasetFactory.kt
│ ├── AutofillAuthActivity.kt # Biometric gate for autofill
│ └── model/AutofillField.kt
│
├── backup/
│ ├── AutoBackupWorker.kt # WorkManager
│ └── RestoreManager.kt
│
└── di/
├── AppModule.kt
├── CryptoModule.kt
├── DataModule.kt
└── DomainModule.kt

text

---

## 🗓️ PHASES

---

### **PHASE 0 — Project Scaffolding** ⏱️ 1 day

**Goal:** Empty Android project that compiles, runs on emulator, and has all dependencies wired.

**Deliverables:**
- [ ] `build.gradle.kts` (root + app module) with all dependencies above
- [ ] `settings.gradle.kts` with repositories
- [ ] `gradle/libs.versions.toml` (version catalog)
- [ ] `AndroidManifest.xml` with permissions declared
- [ ] `BsrApplication.kt` with `@HiltAndroidApp`
- [ ] `MainActivity.kt` with basic Compose "Hello Vault" screen
- [ ] Hilt module skeletons (`AppModule`, `CryptoModule`, `DataModule`, `DomainModule`) — empty `@Provides`
- [ ] `.gitignore`, `README.md`
- [ ] Gradle wrapper 8.7

**Permissions to declare (AndroidManifest.xml):**
```xml
<uses-permission android:name="android.permission.USE_BIOMETRIC" />
<uses-permission android:name="android.permission.USE_FINGERPRINT" />
<uses-permission android:name="android.permission.VIBRATE" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<!-- NO INTERNET PERMISSION in Phase 0-10. Added only in Phase 12 for sync. -->
Acceptance Criteria:

./gradlew assembleDebug succeeds with 0 warnings

App installs and shows "Hello Vault" on Pixel 6 emulator (API 34)

Hilt dependency injection works (@Inject in a test class)

Test: None required at this phase.

PHASE 1 — Security Foundation ⏱️ 3 days
Goal: All platform-security plumbing in place. Nothing app-specific yet.

Deliverables:

1.1 core/security/ScreenshotGuard.kt
kotlin
object ScreenshotGuard {
    fun enable(activity: Activity) {
        activity.window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }
    fun disable(activity: Activity) {
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
}
1.2 core/security/BiometricAuthenticator.kt
Wraps androidx.biometric.BiometricPrompt

Supports BIOMETRIC_STRONG or DEVICE_CREDENTIAL

Callback flow: Flow<AuthResult> where AuthResult ∈ {Success, Failed, Error, Cancelled}

Must set setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)

Crypto-based variant for key unlock (Android 9+)

1.3 core/security/RootDetector.kt
Checks su binary in common paths

Checks test-keys in Build.TAGS

Checks for BusyBox, Xposed, Magisk

Returns RootStatus { NotRooted, Rooted, Suspicious }

Non-blocking: only show warning banner

1.4 core/security/ClipboardManager.kt
copySensitive(context, text, clearAfterMs = 30_000)

Uses ClipDescription.EXTRA_IS_SENSITIVE = true (Android 13+)

Schedules auto-clear via coroutine

Cancels previous clear job if new copy

1.5 core/crypto/MasterKeyManager.kt
kotlin
interface MasterKeyManager {
    suspend fun generateOrRetrieveKey(): SecretKey  // AES-256 in Android Keystore
    suspend fun wrapKey(plaintext: ByteArray): ByteArray  // AES-GCM
    suspend fun unwrapKey(wrapped: ByteArray): ByteArray
}
Uses KeyGenParameterSpec with:

setUserAuthenticationRequired(false) (session-key wrap)

setBlockModes(BLOCK_MODE_GCM)

setEncryptionPaddings(ENCRYPTION_PADDING_NONE)

setKeySize(256)

Alias: bsrpro_master_wrap_key_v1

1.6 core/util/Result.kt
kotlin
sealed interface VaultResult<out T> {
    data class Success<T>(val value: T) : VaultResult<T>
    data class Failure(val error: VaultError) : VaultResult<Nothing>
    object Loading : VaultResult<Nothing>
}
sealed class VaultError(message: String) : Exception(message) {
    object VaultLocked : VaultError("Vault is locked")
    object InvalidMasterPassword : VaultError("Invalid master password")
    object BiometricUnavailable : VaultError("Biometric unavailable")
    class IOError(cause: Throwable) : VaultError("IO error: ${cause.message}")
    // ...
}
Acceptance Criteria:

Unit test: ScreenshotGuard.enable() → WindowManager.LayoutParams.FLAG_SECURE set

Unit test: BiometricAuthenticator returns Cancelled when user dismisses

Unit test: MasterKeyManager.generateOrRetrieveKey() returns same key on second call

Unit test: ClipboardManager.copySensitive("test", 1000) clears clipboard after 1s (Robolectric)

Time: 3 working days

PHASE 2 — Crypto & Vault Core ⏱️ 5 days
Goal: Bit-for-bit compatible crypto with the browser extension. This is the most critical phase.

Deliverables:

2.1 core/crypto/VaultCrypto.kt
kotlin
object VaultCrypto {
    // Must match browser extension exactly
    private const val PBKDF2_ITERATIONS = 600_000
    private const val PBKDF2_HASH = "SHA-256"
    private const val AES_KEY_SIZE = 256
    private const val AES_GCM_IV_SIZE = 12
    private const val SALT_SIZE = 16
    private const val TAG_SIZE_BITS = 128

    suspend fun deriveKey(password: CharArray, salt: ByteArray): SecretKey
    suspend fun encrypt(plaintext: String, password: CharArray): String  // base64 of salt||iv||ct
    suspend fun decrypt(ciphertextB64: String, password: CharArray): String
    suspend fun hashMaster(password: CharArray): String  // encrypt("__VAULT_CANARY__")
    suspend fun verifyMaster(hashB64: String, password: CharArray): Boolean
    suspend fun encryptV3(plaintext: String, password: CharArray): String  // V3 backup
    suspend fun decryptV3(container: String, password: CharArray): String
    fun wipeChars(chars: CharArray)  // zero-fill
}
Reference implementation:

kotlin
suspend fun deriveKey(password: CharArray, salt: ByteArray): SecretKey {
    require(salt.size == SALT_SIZE)
    val passwordBytes = password.concatToString().toByteArray(Charsets.UTF_8)
    try {
        val spec = PBEKeySpec(password, salt, PBKDF2_ITERATIONS, AES_KEY_SIZE)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = factory.generateSecret(spec).encoded
        val secretKey = SecretKeySpec(keyBytes, "AES")
        keyBytes.fill(0)
        return secretKey
    } finally {
        passwordBytes.fill(0)
    }
}

suspend fun encrypt(plaintext: String, password: CharArray): String {
    val salt = ByteArray(SALT_SIZE).also { SecureRandom().nextBytes(it) }
    val iv = ByteArray(AES_GCM_IV_SIZE).also { SecureRandom().nextBytes(it) }
    val key = deriveKey(password, salt)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_SIZE_BITS, iv))
    val ct = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
    val packed = salt + iv + ct
    return Base64.getEncoder().encodeToString(packed)
}
2.2 core/model/VaultEntry.kt
Must match browser extension's JSON schema:

kotlin
@Serializable
data class VaultEntry(
    val id: String,
    val title: String = "",
    val url: String = "",
    val username: String = "",
    val password: String = "",
    val mobile: String = "",
    val notes: String = "",
    val totp: String = "",
    val category: String = "other",
    val isNote: Boolean = false,
    val recordType: String = "login",
    val folderId: String = "",
    val starred: Boolean = false,
    val tags: List<String> = emptyList(),
    val customFields: List<CustomField> = emptyList(),
    val cardNumber: String = "",
    val cardholder: String = "",
    val cardExpiry: String = "",
    val cardCvv: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val address: String = "",
    val idNumber: String = "",
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    val passwordHistory: List<PasswordHistoryItem> = emptyList(),
    val editHistory: List<EditHistoryItem> = emptyList()
)

@Serializable
data class CustomField(val k: String, val v: String)

@Serializable
data class PasswordHistoryItem(val pw: String, val changedAt: Long)

@Serializable
data class EditHistoryItem(
    val changedAt: Long,
    val fields: List<String>,
    val source: String
)
2.3 core/model/Folder.kt
kotlin
@Serializable
data class Folder(
    val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long
)
2.4 core/crypto/SessionKeyStore.kt
In-memory only (no persistence)

Holds CharArray master password (not String)

Auto-wipe on lock

Uses SecureRandom for any ephemeral keys

Acceptance Criteria:

Golden vector tests:

Test that encrypt("hello", "password") produces base64 that decrypts with the same password

Test that a known ciphertext from the browser extension decrypts correctly

Test V3 backup round-trip

hashMaster compatibility test: Generate hash in Kotlin, verify in a Node.js script using the web extension's crypto.js

Performance: deriveKey() completes in <2s on Pixel 6

Test file: VaultCryptoTest.kt with at least 20 test cases.

Time: 5 working days (this is the highest-risk phase — take the time)

PHASE 3 — Data Persistence ⏱️ 3 days
Goal: Encrypted vault blob on disk + encrypted settings.

Deliverables:

3.1 data/local/blob/VaultBlobStore.kt
Storage: context.filesDir/vault.blob (encrypted)

Uses VaultCrypto.encrypt(entriesJson, masterPassword)

Atomic writes: write to .tmp → fsync → rename

Backup: keep .blob.bak for last 2 versions

kotlin
interface VaultBlobStore {
    suspend fun exists(): Boolean
    suspend fun read(password: CharArray): List<VaultEntry>
    suspend fun write(entries: List<VaultEntry>, password: CharArray)
    suspend fun readRaw(): ByteArray?
    suspend fun writeRaw(blob: String)
    suspend fun deleteAll()
}
3.2 data/local/db/VaultDatabase.kt (Room)
Purpose: Metadata only (for fast search), NOT actual entries

Tables:

entry_metadata(id, title, url, username, category, starred, updated_at) — refilled on unlock

folders(id, name, created_at, updated_at)

recent_searches(query, searched_at)

Encrypted at rest using SQLCipher (add net.zetetic:android-database-sqlcipher:4.5.4)

Actually — simpler approach: use plain Room for metadata (no SQLCipher). Metadata leaks "how many entries" and "titles" but not passwords. If we want full encryption, apply SQLCipher. For Phase 3, use SQLCipher to be safe.

3.3 data/local/preferences/SettingsDataStore.kt
Uses androidx.datastore:datastore-preferences

Settings: theme, autoLockTimeout, clipboardClear, biometricEnabled, lockOnBackground, etc.

NOT encrypted (settings are not sensitive)

kotlin
data class VaultSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val autoLockSeconds: Int = 60,
    val clipboardClearSeconds: Int = 30,
    val biometricEnabled: Boolean = false,
    val lockOnBackground: Boolean = true,
    val generatorDefaultLength: Int = 16,
    val generatorKeyword: String = "",
    val travelMode: Boolean = false
)
Acceptance Criteria:

Test: VaultBlobStore.write(entries, pw) then .read(pw) returns equal list

Test: .read(wrongPw) throws VaultError.InvalidMasterPassword

Test: Atomic write survives simulated crash (kill process mid-write, verify old blob intact)

Test: Room database queries return correct metadata

Time: 3 working days

PHASE 4 — Authentication & Lock ⏱️ 4 days
Goal: Users can create vault, unlock with master password or biometric, and lock.

Deliverables:

4.1 presentation/setup/SetupScreen.kt
Welcome card with logo (from existing web asset)

"Create Vault" → password input + strength meter + confirm

"Import from existing backup" → file picker (.Vault file)

Validate: min 12 chars, calcStrength >= "medium"

4.2 presentation/lock/LockScreen.kt
Two modes (toggle): Master password / Biometric

If biometric enabled: auto-prompt on screen entry

Error display: "Incorrect password. X attempts remaining."

Rate limiting: 5 attempts → 30s lockout (persist across app restarts in encrypted prefs)

4.3 domain/usecase/UnlockVaultUseCase.kt
kotlin
class UnlockVaultUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val sessionKeyStore: SessionKeyStore
) {
    suspend operator fun invoke(password: CharArray): VaultResult<List<VaultEntry>> {
        // 1. Check rate limit
        // 2. Read blob
        // 3. Verify hash
        // 4. Decrypt entries
        // 5. Store password in SessionKeyStore
        // 6. Return entries
    }
}
4.4 domain/usecase/LockVaultUseCase.kt
Clears SessionKeyStore

Wipes clipboard

Navigates to LockScreen

4.5 di/CryptoModule.kt
Wire all dependencies via Hilt.

Acceptance Criteria:

User can create vault with 12+ char password

User can unlock with correct password

Wrong password → error + attempt decrement

5 wrong attempts → 30s lockout

Biometric prompt appears if enabled and vault exists

Vault locks automatically after 60s background (configurable)

Vault locks on manual "Lock" button

Session survives screen rotation but not process death

Time: 4 working days

PHASE 5 — Core UI ⏱️ 7 days
Goal: Full CRUD for entries + search + categories.

Deliverables:

5.1 presentation/vault/VaultListScreen.kt
Search bar (top)

Category chips: All / Work / Personal / Banking / Social / Other

Filter pills: All / Strong / Weak / Breached / Starred

Grouped by domain (like web extension) with expandable groups

Flat view toggle

FAB: "+ Add Entry"

Entry row shows: title, username, strength badge

5.2 presentation/editor/EntryEditorScreen.kt
Dynamic form based on recordType: Login / Card / Identity / Note

Fields per type (same as web extension)

Password field with show/hide + generate button

TOTP secret field (optional)

Category dropdown, folder dropdown

Tags input

Notes (multiline)

Save / Cancel / Delete buttons

5.3 presentation/vault/EntryDetailScreen.kt
Shows all fields

Copy buttons for username/password/url/mobile

"Open website" button (opens in browser)

Edit / Delete actions

Password history section (if any)

TOTP live code display (if secret present)

5.4 presentation/generator/GeneratorScreen.kt
Random / Passphrase / Manual tabs (matching web)

Length slider (8–256)

Character class toggles

Custom keyword/prefix input

Copy button

5.5 presentation/components/PasswordField.kt
Reusable Compose component with:

Visibility toggle

Copy button

Generate icon

Strength indicator

5.6 Search & filter logic
Debounced search (200ms)

Search across: title, username, url, notes, tags

Fuzzy matching (trigram similarity, port from web extension)

Design system:

Follow existing web extension's dark/light theme

Colors: #a78bfa (accent purple), #f59e0b (accent orange)

Typography: use Material 3 defaults

Rounded corners: 12-16dp

Elevation: subtle shadows

Acceptance Criteria:

Add new login → appears in list immediately

Edit existing → updates propagate

Delete → confirmation dialog → entry removed

Search filters list in real-time

Category chips filter correctly

Copy password → toast + auto-clear after 30s

Duplicate detection on save (same domain + username → prompt to overwrite)

Time: 7 working days

PHASE 6 — Autofill Service ⏱️ 5 days ⚠️ CRITICAL
Goal: Autofill passwords into other apps and browsers.

Deliverables:

6.1 autofill/VaultAutofillService.kt
kotlin
class VaultAutofillService : AutofillService() {
    override fun onFillRequest(
        request: FillRequest,
        cancellationSignal: CancellationSignal,
        callback: FillCallback
    ) {
        // 1. Parse AssistStructure
        // 2. Check vault is unlocked
        // 3. If locked → show auth activity dataset
        // 4. If unlocked → match entries by domain
        // 5. Build Dataset with Authentication + InlinePresentation
        // 6. Return via callback
    }

    override fun onSaveRequest(
        request: SaveRequest,
        callback: SaveCallback
    ) {
        // Trigger save prompt after login form submit
    }
}
6.2 autofill/AutofillParser.kt
Extract from AssistStructure:

Package name

Web domain (if WebView)

Input fields with autofillHints, hint, idEntry

Classify fields:

USERNAME_FIELD: AUTOFILL_HINT_USERNAME, AUTOFILL_HINT_EMAIL_ADDRESS

PASSWORD_FIELD: inputType == TYPE_TEXT_VARIATION_PASSWORD, AUTOFILL_HINT_PASSWORD

NEW_PASSWORD_FIELD: AUTOFILL_HINT_NEW_PASSWORD

OTP_FIELD: AUTOFILL_HINT_SMS_OTP

6.3 autofill/AutofillDatasetFactory.kt
Build Dataset with:

InlinePresentation (Android 11+) — shows suggestions above keyboard

RemoteViews fallback for older Android

Filter entries by:

Domain match (from assistStructure.webDomain)

Package name match (stored in entry's url field if custom)

Sort by: last used → most recent → alphabetic

6.4 autofill/AutofillAuthActivity.kt
Shown when user taps autofill suggestion but vault is locked

Biometric prompt

On success → decrypt entry → fill fields

Transparent activity (no UI), just biometric overlay

6.5 Save flow
Detect when a login form is submitted

Show notification or inline prompt: "Save password?"

On confirm → open EntryEditor with prefilled values

AndroidManifest.xml:

xml
<service
    android:name=".autofill.VaultAutofillService"
    android:exported="true"
    android:label="@string/autofill_service_label"
    android:permission="android.permission.BIND_AUTOFILL_SERVICE">
    <intent-filter>
        <action android:name="android.service.autofill.AutofillService" />
    </intent-filter>
    <meta-data
        android:name="android.autofill"
        android:resource="@xml/autofill_service" />
</service>
Acceptance Criteria:

User enables service in Settings → Autofill → BSRPRO

Chrome: focus on login field → "BSRPRO" appears in autofill suggestions

Gmail app login → suggestions appear

Tap suggestion → if locked, biometric prompt → password filled

Wrong domain → no suggestions

After typing a new password and submitting login → save prompt appears

Bank app (WebView) → suggestions work via webDomain

Test on:

Chrome, Firefox, Samsung Internet

Gmail, Instagram, WhatsApp login screens

Bank app with WebView login (e.g., HDFC)

Time: 5 working days (this is where most time is spent on real-device testing)

PHASE 7 — Settings ⏱️ 2 days
Goal: User-configurable behavior.

Deliverables:

7.1 presentation/settings/SettingsScreen.kt
Sections:

Security

Change master password

Biometric unlock toggle

Auto-lock timeout (Never / 30s / 1m / 5m / 15m)

Lock on background toggle

Clipboard auto-clear (Never / 15s / 30s / 60s)

Autofill

Enable/disable service (link to system settings)

Show suggestions inline toggle

Generator

Default length (8–256)

Custom keyword/prefix

Exclude similar characters toggle

Appearance

Theme (System / Light / Dark)

App icon color

Data

Export encrypted backup

Import from backup

Import from CSV

Clear recent searches

Reset vault (danger, requires password)

About

Version

Changelog

Privacy policy link

Open source licenses

Acceptance Criteria:

All toggles persist across app restarts

Changing auto-lock timeout applies immediately

Change password → old password no longer works

Time: 2 working days

PHASE 8 — Backup & Import/Export ⏱️ 4 days
Goal: Users can move data in/out.

Deliverables:

8.1 Export formats
.Vault (V3 encrypted backup, compatible with web extension)

.csv Vault format

.csv Chrome format

.csv Bitwarden format

.json Plain JSON (with warning)

8.2 Import formats
.Vault (V3)

.csv Vault

.csv Chrome / Edge

.csv Bitwarden

.csv LastPass

.csv 1Password

.csv Dashlane

.csv KeePass

.csv Generic

.vcf vCard

8.3 Auto-backup
AutoBackupWorker (WorkManager)

Runs daily if enabled

Writes to Downloads/BSRPRO_Backups/vault_YYYYMMDD.Vault

Uses MediaStore (Android 10+)

8.4 data/import/CsvImporter.kt
Robust CSV parser (handle quoted fields, embedded commas/newlines)

Column auto-detection (header mapping)

Duplicate detection (same URL + username)

Preview screen before commit

Acceptance Criteria:

Export backup → file appears in Downloads

Import that backup on a clean install → same entries

Import Chrome CSV → all rows appear

Import with duplicate entries → user prompted for each

Auto-backup runs daily (verify via WorkManager logs)

Time: 4 working days

PHASE 9 — TOTP Support ⏱️ 2 days
Goal: 2FA codes generated offline.

Deliverables:

9.1 domain/usecase/GenerateTotpCodeUseCase.kt
Port from totp.js:

Base32 decode

HMAC-SHA1

Dynamic truncation

6-digit code, 30s window

kotlin
class GenerateTotpCodeUseCase {
    operator fun invoke(secret: String, timestamp: Long = System.currentTimeMillis()): TotpCode {
        val secretBytes = base32Decode(secret)
        val counter = timestamp / 1000 / 30
        val hash = hmacSha1(secretBytes, counterToBytes(counter))
        val offset = hash[19].toInt() and 0xF
        val code = ((hash[offset].toInt() and 0x7F) shl 24) or
                   ((hash[offset + 1].toInt() and 0xFF) shl 16) or
                   ((hash[offset + 2].toInt() and 0xFF) shl 8) or
                   (hash[offset + 3].toInt() and 0xFF)
        return TotpCode(
            code = (code % 1_000_000).toString().padStart(6, '0'),
            remaining = 30 - ((timestamp / 1000) % 30),
            period = 30
        )
    }
}
9.2 Autofill integration
When OTP_FIELD detected → show TOTP from matching entry

Update code every second in autofill dataset (Android 11+ inline suggestion supports dynamic updates)

9.3 Detail screen TOTP widget
Live countdown ring

Tap to copy

Works offline

Acceptance Criteria:

Add entry with TOTP secret → code appears in detail screen

Code matches Google Authenticator (verify with same secret)

Autofill inserts OTP code correctly in banking app

Code refreshes at exact 30s boundary

Test vectors (RFC 6238):

Secret JBSWY3DPEHPK3PXP, timestamp 1600000000 → code 282760

Time: 2 working days

PHASE 10 — Polish & Security Hardening ⏱️ 5 days
Goal: Production-ready quality.

Deliverables:

10.1 Security hardening
□ Enable android:allowBackup="false" in manifest
□ Add networkSecurityConfig (block cleartext)
□ Enable R8 full mode + ProGuard rules for Hilt/Room/kotlinx.serialization
□ Obfuscate crypto library names
□ Root detection UI (warning banner in Settings)
□ Debugger detection (optional, non-blocking)
□ Screen recording block: FLAG_SECURE on all vault screens
□ Memory wipes: zero CharArrays after use
□ No passwords in logs: Timber tree that redacts password, totp, key
□ Rate limiting: persistent lockout across app restarts
10.2 Accessibility
□ All screens work with TalkBack
□ Content descriptions on all icons
□ Focus order logical
□ Support system font scale up to 200%
□ High-contrast mode
10.3 Internationalization
□ English (values/strings.xml)
□ Hindi (values-hi/strings.xml)
□ All user-facing strings externalized
10.4 Performance
□ Cold start <800ms on Pixel 6
□ Unlock <1.5s
□ List scrolls at 60fps with 500+ entries
□ Memory <150MB while unlocked
□ APK size <30MB
10.5 Crash reporting
□ Local-only crash log (no network by default)
□ Optional opt-in crash reporting
Acceptance Criteria:

TalkBack navigates entire app without getting stuck

500-entry list scrolls smoothly (no jank)

Cold start benchmarked and documented

./gradlew lint passes with 0 errors

./gradlew ktlintCheck passes

Time: 5 working days

PHASE 11 — Testing ⏱️ 6 days
Goal: Ship with confidence.

Deliverables:

11.1 Unit tests (target 70% coverage)
VaultCryptoTest — 20+ cases including golden vectors

VaultBlobStoreTest — write/read/atomic

VaultRepositoryTest — CRUD

CsvImporterTest — 10 formats with real sample files

GenerateTotpCodeUseCaseTest — RFC 6238 vectors

RootDetectorTest — mocked environment

BiometricAuthenticatorTest — success/fail/cancel

11.2 Integration tests
End-to-end: create vault → add entry → lock → unlock → verify entry

Autofill service test via AutofillServiceTest (test framework)

Backup/restore round-trip

Migration test (old version → new version)

11.3 UI tests (Compose Test)
Setup screen: enter password → create vault

Lock screen: wrong password → error, correct → navigate

Editor: add entry → appears in list

Detail screen: copy password → clipboard changes

11.4 Manual test matrix
Pixel 6 (API 34) — primary target

Samsung Galaxy S21 (API 30) — common One UI variant

Pixel 4a (API 29) — older device with biometric

Redmi Note 10 (API 26) — minimum supported, low-end

Chrome + Firefox + Samsung Internet autofill

Bank apps: HDFC, ICICI, SBI, Paytm

Acceptance Criteria:

All unit tests pass

All integration tests pass

Manual test matrix completed with screenshots

No known P0 bugs

Zero crashes in 1-hour stress test

Time: 6 working days

PHASE 12 — Release Prep ⏱️ 3 days
Goal: Play Store submission ready.

Deliverables:

12.1 Play Console setup
□ App name: BSRPRO Password Manager
□ Package: pro.babasitaram.vault
□ Category: Tools
□ Content rating: Everyone
□ Privacy policy URL (required)
□ Data safety form filled
□ Target audience: 18+
12.2 Assets
□ App icon (512x512 + adaptive)
□ Feature graphic (1024x500)
□ 8 phone screenshots (1080x1920)
□ Promo video (optional)
□ Store listing (English + Hindi)
12.3 Signing
□ Generate release keystore (save securely offline)
□ Configure signingConfigs in gradle
□ Enable Play App Signing
□ Build AAB (not APK)
12.4 Rollout plan
Internal testing (10 users, 1 week)

Closed beta (100 users, 2 weeks)

Open beta (1000 users, 1 week)

Staged rollout: 5% → 20% → 50% → 100%

12.5 Post-launch
□ Monitoring dashboard (crashes, ANRs)
□ Support email
□ Update cadence: monthly bug fixes, quarterly features
Acceptance Criteria:

AAB uploaded to Internal Testing

All Play Console policy warnings resolved

Store listing approved

Time: 3 working days

🚫 NOT in Scope (Future Phases)
Cloud sync (Phase 13+): Firebase/Supabase with E2E encryption

iOS app (Phase 14+): Swift/SwiftUI port

Wear OS companion (Phase 15+)

Shared vaults (Phase 16+)

Passkey support (Phase 17+): FIDO2 credential provider

Browser extension bridge (Phase 18+): companion Chrome extension

🎯 Milestone Summary
Phase	Days	Cumulative	Deliverable
0	1	1	Empty app boots
1	3	4	Security plumbing
2	5	9	Crypto compatible with web ext
3	3	12	Encrypted storage
4	4	16	Unlock works
5	7	23	CRUD + search works
6	5	28	Autofill works
7	2	30	Settings
8	4	34	Backup/import works
9	2	36	TOTP works
10	5	41	Hardened
11	6	47	Tested
12	3	50	Shipped
Total: ~50 working days (10 weeks solo) → realistic 3-4 months with buffer

📋 Build Instructions for Claude Sonnet
Prompt to use:

text
I have a ROADMAP.md for a password manager Android app. 
Please build it phase by phase.

For each phase:
1. Read the phase requirements carefully
2. Create ALL files listed in "Deliverables"
3. Ensure code compiles (no missing imports, no TODOs left)
4. Include all specified dependencies
5. Add unit tests for the phase's acceptance criteria
6. Show me the complete file list at the end of each phase

Rules:
- Use Kotlin, not Java
- Use Jetpack Compose, not XML layouts
- Use Coroutines/Flow for async, not RxJava
- Use Hilt for DI
- Never store master password as String — use CharArray
- Always wipe CharArrays after use
- Follow Android security best practices

Start with Phase 0. Do not skip ahead. When I say "next", 
proceed to the next phase.

Also: check the browser extension code I've provided separately 
for compatibility requirements in Phase 2 (VaultCrypto).
⚠️ Critical Warnings for the Developer
Never use String for master password — always CharArray and wipe after

Never log the master password or decrypted entries

Never pass decrypted passwords through Intent extras (use in-memory singleton)

Never commit keystore to git

Always test on a real device before calling a phase "done"

Always run ./gradlew lint before each commit

Always verify Phase 2 crypto against actual web extension before moving to Phase 3

📚 Reference Material
Android Autofill: https://developer.android.com/guide/topics/text/autofill-services

Android Keystore: https://developer.android.com/training/articles/keystore

BiometricPrompt: https://developer.android.com/training/sign-in/biometric-auth

Jetpack Compose: https://developer.android.com/jetpack/compose

Room: https://developer.android.com/training/data-storage/room

Hilt: https://developer.android.com/training/dependency-injection/hilt-android

V3 Backup Format: (from existing extension crypto.js)

TOTP RFC 6238: https://datatracker.ietf.org/doc/html/rfc6238

End of ROADMAP.md

text

---

## 🎯 कैसे Use करो

1. **ये पूरा text copy करो** → `ROADMAP.md` नाम से save करो
2. **Sonnet को भेजो:**
मेरे पास ROADMAP.md है — इसे follow करके Android app बनाओ।
Phase 0 से शुरू करो। हर phase पूरा करके रुको, मैं "next" बोलूँगा।

text
3. **Sonnet हर phase में files बनाएगा** — verify करते रहो, चलाते रहो
4. **Phase 2 (crypto) सबसे ज़रूरी है** — उसको extra carefully review करो
5. **Phase 6 (autofill) दूसरा critical है** — real device पर test करो

---

## ⚡ Quick Tips

- **Phase 2 skip मत करना** — compatibility बाद में fix करना बहुत painful होगा
- **Har phase के बाद Android Studio में build करो** — compile error तुरंत पकड़ो
- **Sonnet को real sample files दो** — जैसे Chrome CSV, V3 backup file
- **Phase 6 के लिए** Sonnet को बताओ कि existing extension में `content.js` कैसे काम करता है
- **Emulator autofill test मत करना** — real device पर ही proper test होता है

---

**Ready to go!** 🚀

अगर किसी specific phase का detailed code चाहिए या Sonnet कहीं stuck हो जाए, बताओ — मैं उस phase का exact code दे दूँगा।