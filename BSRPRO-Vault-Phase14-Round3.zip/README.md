# BSRPRO Vault — Android

Native Android companion for the BSRPRO Password Manager browser extension.
Kotlin · Jetpack Compose · Hilt · MVVM + Clean Architecture · min SDK 26.

## Build
1. Open in Android Studio (Koala+ / JDK 17).
2. If `gradlew` is missing: `gradle wrapper --gradle-version 8.7` (or let Android Studio sync).
3. `./gradlew assembleDebug`

## Status
Phases 0–9 written (scaffold, security, crypto, persistence, auth & lock, core UI, autofill, settings, backup/import/export, TOTP).
Phases 0–5 are build-verified on device; **Phases 6–9 have not been compiled yet** — run `./gradlew testDebugUnitTest assembleDebug` and test autofill on a real device (Chrome, Gmail, a banking app). Phase 10+ next. See ROADMAP.md.

### Notes on Phases 6–9
- Autofill: enable under Android Settings → Passwords & autofill → Autofill service → BSRPRO Vault. Pages served over plain `http` never get suggestions.
- OTP fields get the TOTP code of the matching entry (the next period's code if < 3 s are left). Android does not refresh an already shown suggestion, so the code is computed when the list is built.
- Auto-backup writes a V3 `.Vault` file, which is encrypted with the master password; it therefore runs while the vault is unlocked (daily worker + catch-up on unlock).
- The ROADMAP TOTP vector `JBSWY3DPEHPK3PXP @ 1600000000 → 282760` is wrong; the correct code is `368941` (see TotpRoadmapVectorTest).

## Security rules
- Master password is always `CharArray`, wiped after use.
- No INTERNET permission until the optional sync phase.
- Keystore / signing files are git-ignored. Never commit them.
